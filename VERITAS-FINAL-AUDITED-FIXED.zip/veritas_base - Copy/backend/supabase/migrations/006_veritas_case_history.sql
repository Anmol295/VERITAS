-- VERITAS Phase 6D: permanent player case archive and replay reward protection.
-- Run after migrations 001–005 using the Supabase SQL editor.

create table if not exists public.player_case_seen (
  player_id uuid not null references public.players(id) on delete cascade,
  case_fingerprint text not null,
  first_seen_at timestamptz not null default now(),
  primary key (player_id, case_fingerprint)
);

create table if not exists public.player_case_history (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.players(id) on delete cascade,
  room_id text not null references public.game_rooms(id) on delete cascade,
  case_external_id text not null,
  case_title text not null,
  case_fingerprint text not null,
  status text not null check (status in ('solved','failed')),
  won boolean not null default false,
  solved boolean not null default false,
  turns integer not null default 0 check (turns >= 0),
  duration_seconds integer not null default 0 check (duration_seconds >= 0),
  honour_delta integer not null default 0,
  first_attempt boolean not null default true,
  created_at timestamptz not null default now(),
  unique (room_id, player_id)
);

create index if not exists player_case_history_player_created_idx
  on public.player_case_history(player_id, created_at desc);
create index if not exists player_case_history_player_status_idx
  on public.player_case_history(player_id, status, created_at desc);

alter table public.player_case_seen enable row level security;
alter table public.player_case_history enable row level security;

-- The backend uses the service role. No direct anonymous/authenticated writes are allowed.
revoke all on public.player_case_seen from public, anon, authenticated;
revoke all on public.player_case_history from public, anon, authenticated;

create or replace function public.record_player_case_history(
  p_player_id uuid,
  p_room_id text,
  p_case_external_id text,
  p_case_title text,
  p_case_fingerprint text,
  p_status text,
  p_won boolean,
  p_solved boolean,
  p_turns integer,
  p_duration integer,
  p_honour_delta integer
) returns boolean language plpgsql security definer set search_path=public as $$
declare
  v_first_attempt boolean := false;
  v_inserted uuid;
begin
  if p_status not in ('solved','failed') then raise exception 'INVALID_CASE_STATUS'; end if;

  -- Idempotent retry for the same match returns its original eligibility result.
  select first_attempt into v_first_attempt from player_case_history
    where room_id=p_room_id and player_id=p_player_id;
  if found then return v_first_attempt; end if;

  -- The unique key makes first-attempt detection safe under simultaneous requests.
  insert into player_case_seen(player_id, case_fingerprint)
  values (p_player_id, p_case_fingerprint)
  on conflict (player_id, case_fingerprint) do nothing
  returning player_id into v_inserted;
  v_first_attempt := found;

  insert into player_case_history(
    player_id, room_id, case_external_id, case_title, case_fingerprint, status,
    won, solved, turns, duration_seconds, honour_delta, first_attempt
  ) values (
    p_player_id, p_room_id, p_case_external_id, p_case_title, p_case_fingerprint, p_status,
    coalesce(p_won,false), coalesce(p_solved,false), greatest(coalesce(p_turns,0),0),
    greatest(coalesce(p_duration,0),0), case when v_first_attempt then coalesce(p_honour_delta,0) else 0 end,
    v_first_attempt
  ) on conflict (room_id, player_id) do nothing;

  return v_first_attempt;
end;
$$;

revoke all on function public.record_player_case_history(uuid,text,text,text,text,text,boolean,boolean,integer,integer,integer) from public, anon, authenticated;
grant execute on function public.record_player_case_history(uuid,text,text,text,text,text,boolean,boolean,integer,integer,integer) to service_role;
