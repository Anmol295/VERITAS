-- VERITAS Phase 5 fixes. Run AFTER 001 and 002 (safe to re-run).
--
-- 1. Matchmaking: no deadlock between two players claiming each other, only fresh
--    (recently polled) players are matched, a finished match no longer blocks re-queueing,
--    and a poll can no longer reset a player who was just matched but has no room yet.
-- 2. Lock the SECURITY DEFINER functions down to the service role. By default Supabase makes
--    functions in `public` callable through the public API with the anon key, which would let
--    anyone bump room versions, inflate stats or claim queue slots.

alter table public.matchmaking_queue add column if not exists matched_at timestamptz;

-- Claim an opponent. Lock order: caller's own row first, then the candidate (SKIP LOCKED).
-- Two players claiming each other simultaneously can therefore never deadlock; one of them
-- simply gets NULL and matches on the next poll.
create or replace function public.claim_matchmaking_player(p_player_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_self uuid; v uuid;
begin
  select player_id into v_self from matchmaking_queue
    where player_id = p_player_id and status = 'waiting'
    for update;
  if v_self is null then return null; end if;

  select player_id into v from matchmaking_queue
    where status = 'waiting'
      and player_id <> p_player_id
      and queued_at > now() - interval '10 seconds'
    order by queued_at asc
    for update skip locked
    limit 1;
  if v is null then return null; end if;

  update matchmaking_queue
    set status = 'matched', matched_at = now(), room_id = null
    where player_id in (p_player_id, v);
  return v;
end;
$$;

-- Enter (or heartbeat) the queue. Returns 'queued' | 'pending' | 'matched'.
--   matched : player already has a live (waiting/active) room
--   pending : player was just claimed by an opponent and the room is being created
--   queued  : player is now waiting (a previous finished/stale match is cleared)
create or replace function public.enqueue_matchmaking(p_player_id uuid)
returns text language plpgsql security definer set search_path=public as $$
declare q matchmaking_queue%rowtype; r_status text;
begin
  select * into q from matchmaking_queue where player_id = p_player_id for update;
  if not found then
    insert into matchmaking_queue(player_id, status, queued_at) values (p_player_id, 'waiting', now());
    return 'queued';
  end if;

  if q.status = 'matched' then
    if q.room_id is not null then
      select status into r_status from game_rooms where id = q.room_id;
      if r_status in ('waiting', 'active') then return 'matched'; end if;
    elsif q.matched_at is not null and q.matched_at > now() - interval '60 seconds' then
      return 'pending';
    end if;
  end if;

  update matchmaking_queue
    set status = 'waiting', queued_at = now(), room_id = null, matched_at = null
    where player_id = p_player_id;
  return 'queued';
end;
$$;

-- Only the backend (service role) may call these.
revoke all on function public.claim_room_version(text, bigint)                      from public, anon, authenticated;
revoke all on function public.claim_matchmaking_player(uuid)                        from public, anon, authenticated;
revoke all on function public.enqueue_matchmaking(uuid)                             from public, anon, authenticated;
revoke all on function public.record_match_stat(uuid, boolean, boolean, integer, integer) from public, anon, authenticated;
revoke all on function public.join_room_atomic(text, uuid, text, text)              from public, anon, authenticated;

grant execute on function public.claim_room_version(text, bigint)                      to service_role;
grant execute on function public.claim_matchmaking_player(uuid)                        to service_role;
grant execute on function public.enqueue_matchmaking(uuid)                             to service_role;
grant execute on function public.record_match_stat(uuid, boolean, boolean, integer, integer) to service_role;
grant execute on function public.join_room_atomic(text, uuid, text, text)              to service_role;
