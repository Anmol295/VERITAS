-- VERITAS Phase 5: concurrency, sessions, matchmaking, statistics
alter table public.game_rooms add column if not exists state_version bigint not null default 0;
alter table public.players add column if not exists last_seen_at timestamptz not null default now();

create table if not exists public.player_sessions (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.players(id) on delete cascade,
  token_hash text not null unique,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 days')
);
create index if not exists player_sessions_player_idx on public.player_sessions(player_id);
create index if not exists player_sessions_expiry_idx on public.player_sessions(expires_at);

create table if not exists public.matchmaking_queue (
  player_id uuid primary key references public.players(id) on delete cascade,
  queued_at timestamptz not null default now(),
  status text not null default 'waiting' check (status in ('waiting','matched','cancelled'))
);
create index if not exists matchmaking_queue_waiting_idx on public.matchmaking_queue(status, queued_at);

create table if not exists public.player_stats (
  player_id uuid primary key references public.players(id) on delete cascade,
  matches_played integer not null default 0,
  wins integer not null default 0,
  losses integer not null default 0,
  cases_solved integer not null default 0,
  cases_failed integer not null default 0,
  total_turns integer not null default 0,
  total_duration_seconds bigint not null default 0,
  updated_at timestamptz not null default now()
);

alter table public.player_sessions enable row level security;
alter table public.matchmaking_queue enable row level security;
alter table public.player_stats enable row level security;

-- Optimistic concurrency: exactly one writer may advance a room version.
create or replace function public.claim_room_version(p_room_id text, p_expected bigint)
returns bigint language plpgsql security definer set search_path=public as $$
declare v bigint;
begin
  update game_rooms
  set state_version = state_version + 1, updated_at = now()
  where id = p_room_id and state_version = p_expected
  returning state_version into v;
  if v is null then raise exception 'ROOM_VERSION_CONFLICT'; end if;
  return v;
end;
$$;

-- Atomic queue claim: locks the oldest waiting player and returns them.
create or replace function public.claim_matchmaking_player(p_player_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare v uuid;
begin
  select player_id into v from matchmaking_queue
  where status='waiting' and player_id <> p_player_id
  order by queued_at asc for update skip locked limit 1;
  if v is null then return null; end if;
  update matchmaking_queue set status='matched' where player_id in (p_player_id, v);
  return v;
end;
$$;

-- Stats are updated through the trusted backend, not browser policies.
create or replace function public.record_match_stat(
  p_player_id uuid, p_win boolean, p_solved boolean, p_turns integer, p_duration integer
) returns void language plpgsql security definer set search_path=public as $$
begin
  insert into player_stats(player_id,matches_played,wins,losses,cases_solved,cases_failed,total_turns,total_duration_seconds)
  values(p_player_id,1,case when p_win then 1 else 0 end,case when p_win then 0 else 1 end,
         case when p_solved then 1 else 0 end,case when p_solved then 0 else 1 end,p_turns,coalesce(p_duration,0))
  on conflict(player_id) do update set
    matches_played=player_stats.matches_played+1,
    wins=player_stats.wins+excluded.wins,
    losses=player_stats.losses+excluded.losses,
    cases_solved=player_stats.cases_solved+excluded.cases_solved,
    cases_failed=player_stats.cases_failed+excluded.cases_failed,
    total_turns=player_stats.total_turns+excluded.total_turns,
    total_duration_seconds=player_stats.total_duration_seconds+excluded.total_duration_seconds,
    updated_at=now();
end;
$$;

create or replace function public.join_room_atomic(
  p_room_id text, p_player_id uuid, p_display_name text, p_location_id text
) returns boolean language plpgsql security definer set search_path=public as $$
declare v_case uuid;
begin
  select case_id into v_case from game_rooms where id=p_room_id and status='waiting' for update;
  if v_case is null then return false; end if;
  if exists(select 1 from room_players where room_id=p_room_id and seat=1) then return false; end if;
  insert into players(id,display_name) values(p_player_id,p_display_name)
    on conflict(id) do update set display_name=excluded.display_name;
  insert into room_players(room_id,player_id,display_name,seat,location_id,action_points)
    values(p_room_id,p_player_id,p_display_name,1,p_location_id,3);
  update game_rooms set status='active', updated_at=now(), state_version=state_version+1 where id=p_room_id;
  insert into room_events(room_id,player_id,text,event_type) values(p_room_id,p_player_id,p_display_name || ' joined the investigation.','public_event');
  return true;
end;
$$;

alter table public.matchmaking_queue add column if not exists room_id text references public.game_rooms(id) on delete set null;

create or replace function public.claim_matchmaking_player(p_player_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare v uuid;
begin
  select player_id into v from matchmaking_queue
  where status='waiting' and player_id <> p_player_id
  order by queued_at asc for update skip locked limit 1;
  if v is null then return null; end if;
  update matchmaking_queue set status='matched' where player_id in (p_player_id, v);
  return v;
end;
$$;
