-- VERITAS Phase 6A — account identity and profile foundation
-- Run AFTER migrations 001, 002 and 003.

create table if not exists public.player_accounts (
  player_id uuid primary key references public.players(id) on delete cascade,
  email text not null unique,
  username text not null unique check (char_length(username) between 3 and 24),
  password_hash text not null,
  account_type text not null default 'registered' check (account_type in ('registered','guest')),
  avatar_url text,
  bio text not null default '' check (char_length(bio) <= 160),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists player_accounts_email_lower_idx on public.player_accounts(lower(email));
create unique index if not exists player_accounts_username_lower_idx on public.player_accounts(lower(username));

alter table public.player_accounts enable row level security;

create or replace function public.set_player_account_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists player_accounts_updated_at on public.player_accounts;
create trigger player_accounts_updated_at
before update on public.player_accounts
for each row execute function public.set_player_account_updated_at();

comment on table public.player_accounts is 'Server-only VERITAS account credentials and public profile fields. Never expose password_hash to clients.';
comment on column public.player_accounts.password_hash is 'Server-only scrypt password hash. Never return this column to clients.';
