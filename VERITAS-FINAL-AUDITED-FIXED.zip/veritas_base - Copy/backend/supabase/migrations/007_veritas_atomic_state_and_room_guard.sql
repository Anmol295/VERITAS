-- VERITAS Phase 7 hardening: atomic room state writes + one unfinished room per player.
-- Run AFTER migrations 001-006.

-- Prevent a player from being inserted into two unfinished rooms concurrently.
-- The advisory transaction lock serializes competing inserts for the same player.
create or replace function public.prevent_multiple_unfinished_rooms()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  perform pg_advisory_xact_lock(hashtextextended(NEW.player_id::text, 0));
  if exists (
    select 1
    from public.room_players rp
    join public.game_rooms gr on gr.id = rp.room_id
    where rp.player_id = NEW.player_id
      and rp.room_id <> NEW.room_id
      and gr.status in ('waiting','active')
  ) then
    raise exception 'PLAYER_ALREADY_IN_UNFINISHED_ROOM';
  end if;
  return NEW;
end;
$$;

drop trigger if exists room_players_single_unfinished_room on public.room_players;
create trigger room_players_single_unfinished_room
before insert or update of player_id, room_id on public.room_players
for each row execute function public.prevent_multiple_unfinished_rooms();

-- Atomic replacement for the old read/claim/update/upsert sequence used by save().
-- The entire room mutation is one transaction: if any player/event/chat write fails,
-- the state_version is not consumed and no partial game state is committed.
create or replace function public.save_room_state(p_room jsonb, p_expected bigint)
returns bigint language plpgsql security definer set search_path=public as $$
declare
  v_room_id text := p_room->>'id';
  v_case_id uuid;
  v_new_version bigint;
  v_player jsonb;
  v_event jsonb;
  v_chat jsonb;
begin
  update public.game_rooms
  set state_version = state_version + 1,
      status = p_room->>'status',
      turn = greatest(coalesce((p_room->>'turn')::integer, 0), 0),
      active_player = (p_room->>'activePlayer')::smallint,
      winner_player_id = nullif(p_room->>'winner', '')::uuid,
      result = p_room->'result',
      updated_at = now()
  where id = v_room_id and state_version = p_expected
  returning state_version, case_id into v_new_version, v_case_id;

  if v_new_version is null then raise exception 'ROOM_VERSION_CONFLICT'; end if;

  for v_player in select value from jsonb_array_elements(coalesce(p_room->'players', '[]'::jsonb)) loop
    insert into public.players(id, display_name, last_seen_at)
    values ((v_player->>'id')::uuid, left(coalesce(v_player->>'name','Detective'),40), now())
    on conflict(id) do update set display_name = excluded.display_name, last_seen_at = now();

    insert into public.room_players(
      room_id, player_id, display_name, seat, location_id, action_points,
      evidence_ids, notes, deductions, private_findings, updated_at
    ) values (
      v_room_id, (v_player->>'id')::uuid, left(coalesce(v_player->>'name','Detective'),40),
      (v_player->>'index')::smallint, v_player->>'locationId',
      least(greatest(coalesce((v_player->>'actionPoints')::integer,0),0),3),
      coalesce(v_player->'evidence','[]'::jsonb), coalesce(v_player->'notes','[]'::jsonb),
      coalesce(v_player->'deductions','[]'::jsonb), coalesce(v_player->'privateFindings','[]'::jsonb), now()
    )
    on conflict(room_id, player_id) do update set
      display_name=excluded.display_name, seat=excluded.seat, location_id=excluded.location_id,
      action_points=excluded.action_points, evidence_ids=excluded.evidence_ids,
      notes=excluded.notes, deductions=excluded.deductions,
      private_findings=excluded.private_findings, updated_at=now();
  end loop;

  for v_event in select value from jsonb_array_elements(coalesce(p_room->'publicEvents', '[]'::jsonb)) loop
    insert into public.room_events(id, room_id, text, created_at)
    values ((v_event->>'id')::uuid, v_room_id, left(coalesce(v_event->>'text',''),2000),
            to_timestamp(greatest(coalesce((v_event->>'at')::numeric, extract(epoch from now())*1000),0)/1000.0))
    on conflict(id) do nothing;
  end loop;

  for v_chat in select value from jsonb_array_elements(coalesce(p_room->'chat', '[]'::jsonb)) loop
    insert into public.chat_messages(id, room_id, player_id, player_name, text, created_at)
    values ((v_chat->>'id')::uuid, v_room_id, (v_chat->>'playerId')::uuid,
            left(coalesce(v_chat->>'playerName','Detective'),40), left(coalesce(v_chat->>'text',''),500),
            to_timestamp(greatest(coalesce((v_chat->>'at')::numeric, extract(epoch from now())*1000),0)/1000.0))
    on conflict(id) do nothing;
  end loop;

  if (p_room->>'status') = 'finished' then
    insert into public.match_results(room_id, case_id, winner_player_id, solved, turns, duration_seconds)
    values (v_room_id, v_case_id, nullif(p_room->>'winner','')::uuid,
            coalesce((p_room->'result'->>'correct')::boolean,false),
            greatest(coalesce((p_room->>'turn')::integer,0),0),
            greatest(floor(extract(epoch from (now() - (select created_at from public.game_rooms where id=v_room_id)))::numeric),0)::integer)
    on conflict(room_id) do update set
      winner_player_id=excluded.winner_player_id, solved=excluded.solved,
      turns=excluded.turns, duration_seconds=excluded.duration_seconds;
  end if;

  return v_new_version;
end;
$$;

revoke all on function public.save_room_state(jsonb,bigint) from public, anon, authenticated;
grant execute on function public.save_room_state(jsonb,bigint) to service_role;

-- The queue should not accept a player who already has a manual or matchmade game.
create or replace function public.enqueue_matchmaking(p_player_id uuid)
returns text language plpgsql security definer set search_path=public as $$
declare q matchmaking_queue%rowtype; r_status text;
begin
  if exists (
    select 1 from public.room_players rp
    join public.game_rooms gr on gr.id = rp.room_id
    where rp.player_id = p_player_id and gr.status in ('waiting','active')
  ) then
    raise exception 'PLAYER_ALREADY_IN_UNFINISHED_ROOM';
  end if;

  select * into q from public.matchmaking_queue where player_id = p_player_id for update;
  if not found then
    insert into matchmaking_queue(player_id, status, queued_at) values (p_player_id, 'waiting', now());
    return 'queued';
  end if;

  if q.status = 'matched' then
    if q.room_id is not null then
      select status into r_status from game_rooms where id = q.room_id;
      if r_status in ('waiting', 'active') then return 'matched'; end if;
    elsif q.matched_at is not null and q.matched_at > now() - interval '60 seconds' then
      return 'pending';
    end if;
  end if;

  update matchmaking_queue set status='waiting', queued_at=now(), room_id=null, matched_at=null
  where player_id=p_player_id;
  return 'queued';
end;
$$;

revoke all on function public.enqueue_matchmaking(uuid) from public, anon, authenticated;
grant execute on function public.enqueue_matchmaking(uuid) to service_role;
