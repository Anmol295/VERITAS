-- VERITAS Phase 4 — persistence schema
-- Run this in the Supabase SQL editor.
-- The Node backend uses the service-role key; the service role bypasses RLS.

create extension if not exists pgcrypto;

create table if not exists public.cases (
  id uuid primary key default gen_random_uuid(),
  external_id text not null,
  title text not null,
  difficulty smallint not null check (difficulty between 1 and 5),
  public_data jsonb not null,
  secret_solution jsonb not null,
  verification jsonb,
  status text not null default 'approved' check (status in ('draft','approved','rejected','retired')),
  created_at timestamptz not null default now(),
  approved_at timestamptz,
  unique(external_id)
);

create index if not exists cases_status_idx on public.cases(status, created_at desc);

create table if not exists public.players (
  id uuid primary key,
  display_name text not null check (char_length(display_name) between 1 and 40),
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists public.game_rooms (
  id text primary key check (id ~ '^[A-Z0-9]{6}$'),
  case_id uuid not null references public.cases(id),
  status text not null check (status in ('waiting','active','finished','abandoned')),
  turn integer not null default 0 check (turn >= 0),
  active_player smallint not null default 0 check (active_player in (0,1)),
  winner_player_id uuid references public.players(id),
  result jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists rooms_status_idx on public.game_rooms(status, updated_at desc);
create index if not exists rooms_case_idx on public.game_rooms(case_id);

create table if not exists public.room_players (
  room_id text not null references public.game_rooms(id) on delete cascade,
  player_id uuid not null references public.players(id),
  display_name text not null,
  seat smallint not null check (seat in (0,1)),
  location_id text not null,
  action_points smallint not null default 3 check (action_points between 0 and 3),
  evidence_ids jsonb not null default '[]'::jsonb,
  notes jsonb not null default '[]'::jsonb,
  deductions jsonb not null default '[]'::jsonb,
  private_findings jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now(),
  primary key(room_id, player_id),
  unique(room_id, seat)
);

create index if not exists room_players_player_idx on public.room_players(player_id);

create table if not exists public.room_events (
  id uuid primary key default gen_random_uuid(),
  room_id text not null references public.game_rooms(id) on delete cascade,
  player_id uuid references public.players(id),
  event_type text not null default 'public_event',
  text text not null,
  created_at timestamptz not null default now()
);

create index if not exists room_events_room_idx on public.room_events(room_id, created_at);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  room_id text not null references public.game_rooms(id) on delete cascade,
  player_id uuid not null references public.players(id),
  player_name text not null,
  text text not null check (char_length(text) between 1 and 500),
  created_at timestamptz not null default now()
);

create index if not exists chat_room_idx on public.chat_messages(room_id, created_at);

-- Match-level analytics/history without exposing the secret solution.
create table if not exists public.match_results (
  id uuid primary key default gen_random_uuid(),
  room_id text not null unique references public.game_rooms(id) on delete cascade,
  case_id uuid not null references public.cases(id),
  winner_player_id uuid references public.players(id),
  solved boolean not null,
  turns integer not null,
  duration_seconds integer,
  created_at timestamptz not null default now()
);

-- Automatic updated timestamp.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists game_rooms_updated_at on public.game_rooms;
create trigger game_rooms_updated_at
before update on public.game_rooms
for each row execute function public.set_updated_at();

create or replace function public.touch_player_last_seen()
returns trigger language plpgsql as $$
begin
  new.last_seen_at = now();
  return new;
end;
$$;

drop trigger if exists players_last_seen on public.players;
create trigger players_last_seen
before update on public.players
for each row execute function public.touch_player_last_seen();

-- RLS: browser clients must NOT read these tables directly.
-- The backend uses the service role and performs authorization itself.
alter table public.cases enable row level security;
alter table public.players enable row level security;
alter table public.game_rooms enable row level security;
alter table public.room_players enable row level security;
alter table public.room_events enable row level security;
alter table public.chat_messages enable row level security;
alter table public.match_results enable row level security;

-- No anon/authenticated policies are intentionally created in Phase 4.
-- This prevents a browser from querying secret_solution directly.

comment on column public.cases.secret_solution is 'SERVER ONLY. Never expose to browser clients before legitimate case resolution.';
comment on table public.room_players is 'Contains private player evidence/findings. Server-only in Phase 4.';
