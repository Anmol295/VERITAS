-- VERITAS Phase 6C — server-authoritative Honour + achievements
-- Run AFTER migrations 001–004.

create table if not exists public.player_progression (
  player_id uuid primary key references public.players(id) on delete cascade,
  honour integer not null default 0 check (honour >= 0),
  false_accusations integer not null default 0 check (false_accusations >= 0),
  current_win_streak integer not null default 0 check (current_win_streak >= 0),
  longest_win_streak integer not null default 0 check (longest_win_streak >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.player_achievements (
  player_id uuid not null references public.players(id) on delete cascade,
  achievement_id text not null,
  earned_at timestamptz not null default now(),
  primary key (player_id, achievement_id)
);

create table if not exists public.match_progression_events (
  room_id text not null references public.game_rooms(id) on delete cascade,
  player_id uuid not null references public.players(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (room_id, player_id)
);

alter table public.player_progression enable row level security;
alter table public.player_achievements enable row level security;
alter table public.match_progression_events enable row level security;

create or replace function public.record_match_progression(
  p_room_id text,
  p_player_id uuid,
  p_win boolean,
  p_solved boolean,
  p_false_accusation boolean,
  p_turns integer,
  p_duration integer,
  p_honour_delta integer
) returns void language plpgsql security definer set search_path=public as $$
declare
  v_matches integer;
  v_solved integer;
  v_false integer;
  v_current_streak integer;
  v_longest_streak integer;
  v_achievement text;
begin
  insert into match_progression_events(room_id, player_id)
  values (p_room_id, p_player_id)
  on conflict (room_id, player_id) do nothing;

  if not found then return; end if;

  insert into player_stats(player_id,matches_played,wins,losses,cases_solved,cases_failed,total_turns,total_duration_seconds)
  values(p_player_id,1,case when p_win then 1 else 0 end,case when p_win then 0 else 1 end,
         case when p_solved then 1 else 0 end,case when p_solved then 0 else 1 end,p_turns,coalesce(p_duration,0))
  on conflict(player_id) do update set
    matches_played=player_stats.matches_played+1,
    wins=player_stats.wins+excluded.wins,
    losses=player_stats.losses+excluded.losses,
    cases_solved=player_stats.cases_solved+excluded.cases_solved,
    cases_failed=player_stats.cases_failed+excluded.cases_failed,
    total_turns=player_stats.total_turns+excluded.total_turns,
    total_duration_seconds=player_stats.total_duration_seconds+excluded.total_duration_seconds,
    updated_at=now();

  insert into player_progression(player_id, honour, false_accusations, current_win_streak, longest_win_streak)
  values(p_player_id, greatest(0, p_honour_delta), case when p_false_accusation then 1 else 0 end,
         case when p_win then 1 else 0 end, case when p_win then 1 else 0 end)
  on conflict(player_id) do update set
    honour=greatest(0, player_progression.honour + p_honour_delta),
    false_accusations=player_progression.false_accusations + case when p_false_accusation then 1 else 0 end,
    current_win_streak=case when p_win then player_progression.current_win_streak + 1 else 0 end,
    longest_win_streak=greatest(player_progression.longest_win_streak,
      case when p_win then player_progression.current_win_streak + 1 else 0 end),
    updated_at=now();

  select matches_played, cases_solved into v_matches, v_solved from player_stats where player_id=p_player_id;
  select false_accusations, current_win_streak, longest_win_streak
    into v_false, v_current_streak, v_longest_streak from player_progression where player_id=p_player_id;

  if v_solved >= 1 then insert into player_achievements(player_id,achievement_id) values(p_player_id,'first-blood') on conflict do nothing; end if;
  if v_solved >= 10 then insert into player_achievements(player_id,achievement_id) values(p_player_id,'the-detective') on conflict do nothing; end if;
  if v_matches >= 25 then insert into player_achievements(player_id,achievement_id) values(p_player_id,'veteran-investigator') on conflict do nothing; end if;
  if v_solved >= 5 and v_false = 0 then insert into player_achievements(player_id,achievement_id) values(p_player_id,'clean-record') on conflict do nothing; end if;
  if v_longest_streak >= 5 then insert into player_achievements(player_id,achievement_id) values(p_player_id,'unstoppable') on conflict do nothing; end if;
end;
$$;

revoke all on function public.record_match_progression(text,uuid,boolean,boolean,boolean,integer,integer,integer) from public, anon, authenticated;
grant execute on function public.record_match_progression(text,uuid,boolean,boolean,boolean,integer,integer,integer) to service_role;
