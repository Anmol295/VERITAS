import { MemoryRepository } from '../game/repository.js';
import { SupabaseRepository } from './supabaseRepository.js';
import { isSupabaseConfigured } from './supabase.js';

export function createRepository() {
  const mode = (process.env.PERSISTENCE || '').toLowerCase();
  if (mode === 'memory') return new MemoryRepository();
  if (isSupabaseConfigured()) return new SupabaseRepository();
  if (mode === 'supabase') {
    // Do not silently fall back to memory: that would lose every game on restart.
    throw new Error('PERSISTENCE=supabase but SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY are missing.');
  }
  console.warn('[veritas] Supabase not configured - using in-memory storage (data is lost on restart).');
  return new MemoryRepository();
}
