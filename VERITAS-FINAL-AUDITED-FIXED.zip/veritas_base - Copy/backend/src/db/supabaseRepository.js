import crypto from 'node:crypto';
import { createSupabaseAdmin } from './supabase.js';

function publicCaseFromFull(gameCase) {
  const { solution, ...publicCase } = gameCase;
  return publicCase;
}

function splitCase(gameCase) {
  return {
    publicData: publicCaseFromFull(gameCase),
    secretSolution: gameCase.solution
  };
}

export class SupabaseRepository {
  constructor(client = createSupabaseAdmin()) {
    this.db = client;
  }

  async create(room) {
    const { publicData, secretSolution } = splitCase(room.case);
    const caseRow = {
      external_id: room.case.id,
      title: room.case.title,
      difficulty: room.case.difficulty,
      public_data: publicData,
      secret_solution: secretSolution,
      verification: room.case.verification || null,
      status: 'approved'
    };

    const { data: existing, error: existingError } = await this.db.from('cases')
      .select('id,public_data,secret_solution').eq('external_id', room.case.id).maybeSingle();
    if (existingError) throw existingError;

    let caseId;
    if (existing) {
      const samePublic = JSON.stringify(existing.public_data) === JSON.stringify(publicData);
      const sameSecret = JSON.stringify(existing.secret_solution) === JSON.stringify(secretSolution);
      if (!samePublic || !sameSecret) throw new Error('CASE_ID_COLLISION');
      caseId = existing.id;
    } else {
      const { data: c, error: ce } = await this.db.from('cases').insert(caseRow).select('id').single();
      if (ce) {
        // A concurrent creator may have inserted the same external ID between our read and insert.
        if (ce.code === '23505') {
          const { data: concurrent, error: re } = await this.db.from('cases')
            .select('id,public_data,secret_solution').eq('external_id', room.case.id).maybeSingle();
          if (re || !concurrent) throw (re || ce);
          if (JSON.stringify(concurrent.public_data) !== JSON.stringify(publicData) || JSON.stringify(concurrent.secret_solution) !== JSON.stringify(secretSolution)) throw new Error('CASE_ID_COLLISION');
          caseId = concurrent.id;
        } else throw ce;
      } else caseId = c.id;
    }

    try {
      await this.upsertRoom(room, caseId);
      return room;
    } catch (error) {
      // create() is composed of several REST calls; remove a partially-created room
      // if a later insert (for example the unfinished-room guard) fails.
      try { await this.db.from('game_rooms').delete().eq('id', room.id); } catch {}
      throw error;
    }
  }

  async get(id) {
    const { data: roomRow, error: re } = await this.db.from('game_rooms').select('*').eq('id', id).maybeSingle();
    if (re) throw re;
    if (!roomRow) return null;

    const { data: caseRow, error: ce } = await this.db.from('cases').select('*').eq('id', roomRow.case_id).single();
    if (ce) throw ce;

    const { data: players, error: pe } = await this.db.from('room_players').select('*').eq('room_id', id).order('seat');
    if (pe) throw pe;

    // Newest 100 (descending), then flipped to chronological. Ascending+limit would freeze the log at the OLDEST 100.
    const { data: eventsDesc, error: ee } = await this.db.from('room_events').select('*').eq('room_id', id).order('created_at', { ascending: false }).limit(100);
    if (ee) throw ee;
    const events = (eventsDesc || []).reverse();

    const { data: chatDesc, error: che } = await this.db.from('chat_messages').select('*').eq('room_id', id).order('created_at', { ascending: false }).limit(100);
    if (che) throw che;
    const chat = (chatDesc || []).reverse();

    return {
      stateVersion: roomRow.state_version || 0,
      id,
      status: roomRow.status,
      createdAt: new Date(roomRow.created_at).getTime(),
      turn: roomRow.turn,
      activePlayer: roomRow.active_player,
      winner: roomRow.winner_player_id,
      result: roomRow.result,
      case: { ...caseRow.public_data, solution: caseRow.secret_solution },
      players: players.map(p => ({
        id: p.player_id,
        name: p.display_name,
        index: p.seat,
        locationId: p.location_id,
        actionPoints: p.action_points,
        evidence: p.evidence_ids || [],
        notes: p.notes || [],
        deductions: p.deductions || [],
        privateFindings: p.private_findings || []
      })),
      publicEvents: events.map(e => ({ id: e.id, text: e.text, at: new Date(e.created_at).getTime() })),
      chat: chat.map(m => ({ id: m.id, playerId: m.player_id, playerName: m.player_name, text: m.text, at: new Date(m.created_at).getTime() }))
    };
  }

  async save(room, expectedVersion = room.stateVersion || 0) {
    const { data, error } = await this.db.rpc('save_room_state', {
      p_room: {
        id: room.id,
        status: room.status,
        turn: room.turn,
        activePlayer: room.activePlayer,
        winner: room.winner,
        result: room.result,
        players: room.players,
        publicEvents: room.publicEvents,
        chat: room.chat
      },
      p_expected: expectedVersion
    });
    if (error) {
      if (String(error.message || '').includes('ROOM_VERSION_CONFLICT')) throw new Error('ROOM_VERSION_CONFLICT');
      if (String(error.message || '').includes('PLAYER_ALREADY_IN_UNFINISHED_ROOM')) throw new Error('You are already in another unfinished match.');
      throw error;
    }
    if (data === null || data === undefined) throw new Error('ROOM_VERSION_CONFLICT');
    room.stateVersion = Number(data);
    return room;
  }


  async upsertRoom(room, caseId, skipRoomWrite = false) {
    if (!skipRoomWrite) {
    const { error } = await this.db.from('game_rooms').upsert({
      id: room.id,
      case_id: caseId,
      status: room.status,
      turn: room.turn,
      active_player: room.activePlayer,
      winner_player_id: room.winner,
      result: room.result,
      updated_at: new Date().toISOString(),
      state_version: room.stateVersion || 0
    });
    if (error) throw error;
    }

    for (const p of room.players) {
      const { error: ple } = await this.db.from('players').upsert({
        id: p.id, display_name: p.name, last_seen_at: new Date().toISOString()
      });
      if (ple) throw ple;

      const { error: pe } = await this.db.from('room_players').upsert({
        room_id: room.id,
        player_id: p.id,
        display_name: p.name,
        seat: p.index,
        location_id: p.locationId,
        action_points: p.actionPoints,
        evidence_ids: p.evidence,
        notes: p.notes,
        deductions: p.deductions,
        private_findings: p.privateFindings || [],
        updated_at: new Date().toISOString()
      }, { onConflict: 'room_id,player_id' });
      if (pe) throw pe;
    }

    // Events and chat are append-only; insert only records not already persisted.
    const persistedEventIds = new Set((await this.db.from('room_events').select('id').eq('room_id', room.id)).data?.map(x => x.id) || []);
    const newEvents = (room.publicEvents || []).filter(e => !persistedEventIds.has(e.id)).map(e => ({
      id: e.id || crypto.randomUUID(), room_id: room.id, text: e.text, created_at: new Date(e.at || Date.now()).toISOString()
    }));
    if (newEvents.length) {
      const { error: ee } = await this.db.from('room_events').insert(newEvents);
      if (ee) throw ee;
    }

    const persistedChatIds = new Set((await this.db.from('chat_messages').select('id').eq('room_id', room.id)).data?.map(x => x.id) || []);
    const newChat = (room.chat || []).filter(m => !persistedChatIds.has(m.id)).map(m => ({
      id: m.id || crypto.randomUUID(), room_id: room.id, player_id: m.playerId, player_name: m.playerName, text: m.text, created_at: new Date(m.at || Date.now()).toISOString()
    }));
    if (newChat.length) {
      const { error: ch } = await this.db.from('chat_messages').insert(newChat);
      if (ch) throw ch;
    }

    if (room.status === 'finished') {
      const durationSeconds = Math.max(0, Math.floor((Date.now() - room.createdAt) / 1000));
      const { error: mr } = await this.db.from('match_results').upsert({
        room_id: room.id, case_id: caseId, winner_player_id: room.winner,
        solved: Boolean(room.result?.correct), turns: room.turn, duration_seconds: durationSeconds
      }, { onConflict: 'room_id' });
      if (mr) throw mr;
    }
  }

  async joinRoomAtomic(roomId, player) {
    const { data, error } = await this.db.rpc('join_room_atomic', {
      p_room_id: roomId, p_player_id: player.id, p_display_name: player.name, p_location_id: player.locationId
    });
    if (error) throw error;
    return Boolean(data);
  }

  async createGuestPlayer(playerId, name) {
    const { error } = await this.db.from('players').upsert({id:playerId,display_name:name,last_seen_at:new Date().toISOString()});
    if(error) throw error; return await this.createSession(playerId);
  }

  async findPlayerRoom(playerId) {
    const { data: memberships, error: me } = await this.db.from('room_players')
      .select('room_id')
      .eq('player_id', playerId);
    if (me) throw me;
    const ids = (memberships || []).map(row => row.room_id);
    if (!ids.length) return null;
    const { data: rooms, error: re } = await this.db.from('game_rooms')
      .select('id')
      .in('id', ids)
      .in('status', ['waiting', 'active'])
      .limit(1);
    if (re) throw re;
    return rooms?.[0]?.id || null;
  }

  async getPlayer(playerId) {
    const {data,error}=await this.db.from('players').select('id,display_name').eq('id',playerId).maybeSingle();
    if(error) throw error; return data ? {id:data.id,name:data.display_name} : null;
  }

  async registerAccount({ playerId, name, email, username, passwordHash }) {
    const { error: pe } = await this.db.from('players').upsert({ id: playerId, display_name: name, last_seen_at: new Date().toISOString() });
    if (pe) throw pe;
    const { data, error } = await this.db.from('player_accounts').insert({
      player_id: playerId, email: email.toLowerCase(), username: username.toLowerCase(), password_hash: passwordHash, account_type: 'registered'
    }).select('player_id,email,username,account_type,avatar_url,bio,created_at').single();
    if (error) {
      if (error.code === '23505') throw new Error('ACCOUNT_ALREADY_EXISTS');
      throw error;
    }
    return { playerId: data.player_id, email: data.email, username: data.username, accountType: data.account_type, avatarUrl: data.avatar_url, bio: data.bio, createdAt: data.created_at };
  }

  async getAccountByLogin(login) {
    const key = String(login || '').trim().toLowerCase();
    const columns = 'player_id,email,username,password_hash,account_type,avatar_url,bio,created_at';
    const byEmail = await this.db.from('player_accounts').select(columns).eq('email', key).maybeSingle();
    if (byEmail.error) throw byEmail.error;
    const data = byEmail.data || (await this.db.from('player_accounts').select(columns).eq('username', key).maybeSingle()).data;
    return data ? { playerId: data.player_id, email: data.email, username: data.username, passwordHash: data.password_hash, accountType: data.account_type, avatarUrl: data.avatar_url, bio: data.bio, createdAt: data.created_at } : null;
  }

  async getAccount(playerId) {
    const { data, error } = await this.db.from('player_accounts').select('player_id,email,username,account_type,avatar_url,bio,created_at').eq('player_id', playerId).maybeSingle();
    if (error) throw error;
    return data ? { playerId: data.player_id, email: data.email, username: data.username, accountType: data.account_type, avatarUrl: data.avatar_url, bio: data.bio, createdAt: data.created_at } : null;
  }

  async updateAccount(playerId, patch) {
    const update = {};
    if (patch.username) update.username = patch.username.toLowerCase();
    if (patch.avatarUrl !== undefined) update.avatar_url = patch.avatarUrl || null;
    if (patch.bio !== undefined) update.bio = patch.bio;
    if (patch.displayName) {
      const { error: pe } = await this.db.from('players').update({ display_name: patch.displayName }).eq('id', playerId);
      if (pe) throw pe;
    }
    if (!Object.keys(update).length) return await this.getAccount(playerId);
    const { data, error } = await this.db.from('player_accounts').update(update).eq('player_id', playerId).select('player_id,email,username,account_type,avatar_url,bio,created_at').single();
    if (error) { if (error.code === '23505') throw new Error('USERNAME_ALREADY_EXISTS'); throw error; }
    return { playerId: data.player_id, email: data.email, username: data.username, accountType: data.account_type, avatarUrl: data.avatar_url, bio: data.bio, createdAt: data.created_at };
  }

  async createSession(playerId) {
    const crypto = await import('node:crypto');
    const token = crypto.randomBytes(32).toString('base64url');
    const hash = crypto.createHash('sha256').update(token).digest('hex');
    const { error } = await this.db.from('player_sessions').insert({ player_id: playerId, token_hash: hash });
    if (error) throw error;
    return token;
  }

  async resolveSession(token) {
    if (!token) return null;
    const crypto = await import('node:crypto');
    const hash = crypto.createHash('sha256').update(token).digest('hex');
    const { data, error } = await this.db.from('player_sessions').select('player_id,expires_at').eq('token_hash', hash).maybeSingle();
    if (error) throw error;
    if (!data || new Date(data.expires_at).getTime() < Date.now()) return null;
    await this.db.from('player_sessions').update({last_seen_at:new Date().toISOString()}).eq('token_hash', hash);
    return data.player_id;
  }

  async destroySession(token) {
    if (!token) return;
    const crypto = await import('node:crypto');
    const hash = crypto.createHash('sha256').update(token).digest('hex');
    const { error } = await this.db.from('player_sessions').delete().eq('token_hash', hash);
    if (error) throw error;
  }

  /** Returns 'queued' | 'pending' | 'matched'. Atomic in SQL (see migration 003). */
  async enqueue(playerId) {
    const { data, error } = await this.db.rpc('enqueue_matchmaking', { p_player_id: playerId });
    if (error) throw error;
    return data;
  }

  async claimOpponent(playerId) {
    const { data, error } = await this.db.rpc('claim_matchmaking_player', { p_player_id: playerId });
    if (error) throw error;
    return data || null;
  }

  async setMatchForPlayers(playerA, playerB, roomId) {
    const { error } = await this.db.from('matchmaking_queue').update({ room_id: roomId }).in('player_id', [playerA, playerB]);
    if (error) throw error;
  }

  /** Room id of the player's unfinished matchmade game, if any. */
  async findMatch(playerId) {
    const { data, error } = await this.db.from('matchmaking_queue').select('room_id').eq('player_id', playerId).eq('status', 'matched').not('room_id', 'is', null).maybeSingle();
    if (error) throw error;
    if (!data?.room_id) return null;
    const { data: room, error: re } = await this.db.from('game_rooms').select('status').eq('id', data.room_id).maybeSingle();
    if (re) throw re;
    return room && room.status !== 'finished' && room.status !== 'abandoned' ? data.room_id : null;
  }

  async releaseMatch(playerIds) {
    const { error } = await this.db.from('matchmaking_queue')
      .update({ status: 'waiting', queued_at: new Date().toISOString(), matched_at: null })
      .in('player_id', playerIds).eq('status', 'matched').is('room_id', null);
    if (error) throw error;
  }

  async recordStats(playerId, win, solved, turns, duration) {
    return this.recordMatchProgression({ roomId: `legacy-${crypto.randomUUID()}`, playerId, win, solved, falseAccusation: false, turns, duration, honourDelta: win && solved ? 50 : 5 });
  }

  async recordMatchProgression({ roomId, playerId, win, solved, falseAccusation, turns, duration, honourDelta }) {
    const { error } = await this.db.rpc('record_match_progression', {
      p_room_id: roomId, p_player_id: playerId, p_win: Boolean(win), p_solved: Boolean(solved),
      p_false_accusation: Boolean(falseAccusation), p_turns: Number(turns || 0),
      p_duration: Number(duration || 0), p_honour_delta: Number(honourDelta || 0)
    });
    if (error) throw error;
    return this.getProgression(playerId);
  }

  async hasSeenCaseFingerprint(playerId, fingerprint) {
    const { data, error } = await this.db.from('player_case_seen').select('case_fingerprint').eq('player_id', playerId).eq('case_fingerprint', fingerprint).maybeSingle();
    if (error) throw error;
    return Boolean(data);
  }

  async recordCaseHistory(entry) {
    const { data, error } = await this.db.rpc('record_player_case_history', {
      p_player_id: entry.playerId,
      p_room_id: entry.roomId,
      p_case_external_id: entry.caseId,
      p_case_title: entry.caseTitle,
      p_case_fingerprint: entry.caseFingerprint,
      p_status: entry.status,
      p_won: Boolean(entry.won),
      p_solved: Boolean(entry.solved),
      p_turns: Number(entry.turns || 0),
      p_duration: Number(entry.duration || 0),
      p_honour_delta: Number(entry.honourDelta || 0)
    });
    if (error) throw error;
    return { firstAttempt: Boolean(data) };
  }

  async getCaseHistory(playerId, { limit = 25, offset = 0, status = null } = {}) {
    let query = this.db.from('player_case_history').select('id,room_id,case_external_id,case_title,status,won,solved,turns,duration_seconds,honour_delta,first_attempt,created_at', { count: 'exact' })
      .eq('player_id', playerId).order('created_at', { ascending: false }).range(offset, offset + limit - 1);
    if (status && ['solved','failed'].includes(status)) query = query.eq('status', status);
    const { data, error, count } = await query;
    if (error) throw error;
    return { items: (data || []).map(r => ({ id:r.id, roomId:r.room_id, caseId:r.case_external_id, caseTitle:r.case_title, status:r.status, won:r.won, solved:r.solved, turns:r.turns, durationSeconds:r.duration_seconds, honourDelta:r.honour_delta, firstAttempt:r.first_attempt, createdAt:r.created_at })), total: count || 0, limit, offset };
  }

  async getStats(playerId) {
    const { data, error } = await this.db.from('player_stats').select('*').eq('player_id',playerId).maybeSingle();
    if (error) throw error;
    return {
      matchesPlayed: data?.matches_played ?? 0,
      wins: data?.wins ?? 0,
      losses: data?.losses ?? 0,
      casesSolved: data?.cases_solved ?? 0,
      casesFailed: data?.cases_failed ?? 0,
      totalTurns: data?.total_turns ?? 0,
      totalDurationSeconds: Number(data?.total_duration_seconds ?? 0)
    };
  }

  async getProgression(playerId) {
    const { data, error } = await this.db.from('player_progression').select('*').eq('player_id', playerId).maybeSingle();
    if (error) throw error;
    const { data: achievements, error: ae } = await this.db.from('player_achievements').select('achievement_id,earned_at').eq('player_id', playerId).order('earned_at', { ascending: true });
    if (ae) throw ae;
    return {
      honour: Number(data?.honour ?? 0),
      falseAccusations: Number(data?.false_accusations ?? 0),
      currentWinStreak: Number(data?.current_win_streak ?? 0),
      longestWinStreak: Number(data?.longest_win_streak ?? 0),
      achievements: (achievements || []).map(a => a.achievement_id),
      achievementDetails: achievements || []
    };
  }

  async delete(id) {
    const { error } = await this.db.from('game_rooms').delete().eq('id', id);
    if (error) throw error;
  }
}
