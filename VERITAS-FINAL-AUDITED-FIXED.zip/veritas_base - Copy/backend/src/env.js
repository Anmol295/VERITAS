// Loads backend/.env relative to THIS file (not the current working directory) so the
// server starts correctly no matter where `node` is launched from. Import this FIRST.
import dotenv from "dotenv";
import { fileURLToPath } from "node:url";

dotenv.config({ path: fileURLToPath(new URL("../.env", import.meta.url)) });
