export const demoCase = {
  schemaVersion: "3.0",
  id: "CASE-918273",
  title: "The Midnight Archive",
  subtitle: "A prototype vanished from a locked research archive.",
  difficulty: 5,
  estimatedMinutes: 18,
  intro:
    "At 21:17 the vault opened. At 21:29 security noticed an anomaly. Nobody is admitting to using the cloned access card.",
  suspects: [
    { id: "sarah", name: "Sarah Vale", role: "Researcher", description: "Worked late on the prototype.", statement: "I stayed in the library until after 21:20. I never opened the vault." },
    { id: "daniel", name: "Daniel Cross", role: "Security Officer", description: "Had legitimate access to the security systems.", statement: "My credential was in my locker. I was in security checking the access console around 21:17." },
    { id: "maria", name: "Maria Chen", role: "Operations Manager", description: "Controlled visitor and staff access.", statement: "I left reception before the vault opened and went toward the office." },
    { id: "hayes", name: "Dr. Hayes", role: "Scientist", description: "Designed the missing prototype.", statement: "The prototype was definitely present before the vault opened at 21:17." },
    { id: "elena", name: "Elena Ward", role: "Guest", description: "Was visiting the research wing.", statement: "I noticed Daniel near security, but I could not see the vault from there." },
    { id: "james", name: "James Cole", role: "Intern", description: "Was assigned to archive inventory.", statement: "I signed the inventory sheet, then returned to the staff area." }
  ],
  locations: [
    { id: "library", name: "Library" },
    { id: "security", name: "Security Room" },
    { id: "office", name: "Office" },
    { id: "hall", name: "Hall" },
    { id: "vault", name: "Vault" },
    { id: "staff", name: "Staff Quarters" },
    { id: "entrance", name: "Main Entrance" },
    { id: "parking", name: "Parking" }
  ],
  map: {
    nodes: [
      ["library", "hall"], ["security", "hall"], ["office", "hall"],
      ["staff", "entrance"], ["hall", "entrance"], ["vault", "hall"],
      ["parking", "entrance"]
    ]
  },
  timeline: [
    { id: "e1", time: "20:43", text: "Sarah is seen in the library.", source: "CCTV" },
    { id: "e2", time: "20:51", text: "Daniel enters the office.", source: "CCTV" },
    { id: "e3", time: "21:03", text: "Maria leaves reception.", source: "Witness statement" },
    { id: "e4", time: "21:11", text: "Sarah enters the corridor.", source: "CCTV" },
    { id: "e5", time: "21:17", text: "The vault door opens.", source: "Security log" },
    { id: "e6", time: "21:22", text: "Daniel leaves the office.", source: "CCTV" },
    { id: "e7", time: "21:24", text: "The corridor camera records a person leaving toward the staff area.", source: "CCTV" },
    { id: "e8", time: "21:26", text: "James returns the inventory clipboard to the staff area.", source: "Inventory log" },
    { id: "e9", time: "21:28", text: "The security console reports a credential mismatch.", source: "Security log" },
    { id: "e10", time: "21:29", text: "Security notices an access anomaly.", source: "Security log" }
  ],
  evidence: [
    {
      id: "ev-cctv",
      title: "Corridor CCTV",
      type: "CCTV",
      description: "The corridor camera shows Sarah entering at 21:11. Its clock is known to drift by four minutes.",
      reliability: 0.92,
      locationId: "hall",
      cctv: {
        cameraId: "CAM-02", cameraName: "North Corridor", recordedAt: "21:11:00",
        durationSeconds: 36, clockOffsetSeconds: 240,
        sceneNotes: ["Sarah enters the corridor", "Face remains visible for several seconds", "Camera clock runs four minutes fast"]
      },
      reveals: ["Sarah was in corridor", "camera timestamp requires correction"]
    },
    {
      id: "ev-card",
      title: "Access Card Report",
      type: "Access Card",
      description: "The vault accepted a credential that belonged to Daniel, but the credential was used without the physical card being present.",
      reliability: 0.99,
      locationId: "security",
      reveals: ["Daniel's credential was cloned"]
    },
    {
      id: "ev-phone",
      title: "Phone Records",
      type: "Phone",
      description: "Daniel's phone connected to the security room network at 21:14 and remained there until 21:24.",
      reliability: 0.96,
      locationId: "security",
      reveals: ["Daniel's phone was near security"]
    },
    {
      id: "ev-statement",
      title: "Witness Statement",
      type: "Statement",
      description: "A witness says Sarah was in the library at 21:20, but cannot explain how they know the exact time.",
      reliability: 0.62,
      locationId: "library",
      reveals: ["Sarah's claimed timeline is uncertain"]
    },
    {
      id: "ev-inventory",
      title: "Inventory Sheet",
      type: "Document",
      description: "The prototype was last physically counted before the vault opened. James signed the inventory check.",
      reliability: 0.85,
      locationId: "staff",
      reveals: ["James had recent inventory access"]
    },
    {
      id: "ev-ledger",
      title: "Access Ledger",
      type: "Security Log",
      description: "The access system recorded the credential, not the person holding it. The record cannot identify who cloned it.",
      reliability: 0.99,
      locationId: "security",
      reveals: ["credential use does not prove Daniel used it"]
    },
    {
      id: "ev-cam-entry", title: "Entrance CCTV", type: "CCTV",
      description: "The entrance camera shows Sarah entering the research wing before the vault opened.", reliability: 0.91, locationId: "entrance",
      cctv: { cameraId: "CAM-01", cameraName: "Main Entrance", recordedAt: "21:04:00", durationSeconds: 24, clockOffsetSeconds: 0, sceneNotes: ["Sarah enters the research wing", "No other suspect enters immediately after her"] },
      reveals: ["Sarah entered before the incident"]
    },
    { id: "ev-security-log", title: "Security Console Log", type: "Security Log",
      description: "The security console shows Daniel's terminal remained active during the vault opening window.", reliability: 0.94, locationId: "security",
      reveals: ["Daniel's terminal remained active near 21:17"]
    },
    { id: "ev-locker", title: "Credential Locker Record", type: "Document",
      description: "Daniel's access card was recorded in the security locker shortly before the vault opened.", reliability: 0.9, locationId: "security",
      reveals: ["Daniel's physical card was stored in the locker"]
    },
    { id: "ev-vault", title: "Vault Door Sensor", type: "Physical Evidence",
      description: "The vault sensor confirms the door opened at 21:17 and closed shortly afterward.", reliability: 0.98, locationId: "vault",
      reveals: ["The vault opened at 21:17"]
    },
    { id: "ev-inventory-log", title: "Inventory Log", type: "Document",
      description: "The inventory log shows James signed the count before the vault opened and returned the clipboard later.", reliability: 0.87, locationId: "staff",
      reveals: ["James handled inventory before the incident"]
    },
    { id: "ev-phone-call", title: "Security Phone Call", type: "Audio",
      description: "A short security-room call places Daniel at the console during the opening window.", reliability: 0.89, locationId: "security",
      reveals: ["Daniel was occupied in security around the critical time"]
    }
  ],
  actions: [
    { id: "move", label: "Move", cost: 1, public: true },
    { id: "investigate", label: "Investigate", cost: 1, public: true },
    { id: "question", label: "Question", cost: 1, public: true },
    { id: "observe", label: "Observe", cost: 2, public: true },
    { id: "analyze", label: "Analyze", cost: 1, public: true },
    { id: "bluff", label: "Bluff", cost: 1, public: true }
  ],
  solution: {
    suspectId: "sarah",
    locationId: "vault",
    method: "Cloned Daniel access credential",
    time: "21:17",
    explanation:
      "Sarah's corrected corridor time places her near the vault shortly before it opened. Daniel's credential was cloned, and Daniel's phone places him in security rather than at the vault. The witness statement's exact timing is unreliable.",
    criticalEvidenceIds: ["ev-cctv", "ev-card", "ev-phone", "ev-statement"]
  },
  logic: {
    premises: [
      "The vault opened at 21:17.",
      "The credential recorded by the vault belonged to Daniel.",
      "Daniel's phone remained near security from 21:14 to 21:24.",
      "The corridor camera is four minutes slow."
    ],
    inferences: [
      "Credential ownership does not prove physical use.",
      "Daniel had an alibi around the opening time.",
      "Sarah was near the vault immediately before it opened.",
      "The witness timing is weaker than independent records."
    ],
    redHerrings: [
      "Daniel's credential appears to implicate him.",
      "James signed the inventory and therefore had access."
    ],
    alternativeHypotheses: [
      "Daniel physically opened the vault.",
      "James stole the prototype during inventory."
    ]
  }
};
