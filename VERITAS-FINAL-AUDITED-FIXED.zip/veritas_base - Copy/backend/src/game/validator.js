export function validateCase(gameCase) {
  const errors = [];
  const suspectIds = new Set((gameCase.suspects || []).map(s => s.id));
  const locationIds = new Set((gameCase.locations || []).map(l => l.id));
  const evidenceIds = new Set((gameCase.evidence || []).map(e => e.id));

  if (!gameCase.id) errors.push("Case id is required.");
  if (!gameCase.title) errors.push("Case title is required.");
  if (!gameCase.suspects?.length) errors.push("At least one suspect is required.");
  if (!gameCase.locations?.length) errors.push("At least one location is required.");
  if (!gameCase.evidence?.length) errors.push("At least one evidence item is required.");
  if (!gameCase.timeline?.length) errors.push("Timeline is required.");

  const s = gameCase.solution;
  if (!s) errors.push("Solution is required.");
  if (s && !suspectIds.has(s.suspectId)) errors.push("Solution suspect does not exist.");
  if (s && !locationIds.has(s.locationId)) errors.push("Solution location does not exist.");
  if (s && (!s.method || !s.time)) errors.push("Solution method/time are required.");

  for (const e of gameCase.evidence || []) {
    if (!e.id || !e.title || !e.description) errors.push(`Malformed evidence item: ${e.id || "unknown"}`);
    if (e.reveals && !Array.isArray(e.reveals)) errors.push(`Evidence reveals must be an array: ${e.id}`);
  }

  return { valid: errors.length === 0, errors };
}
