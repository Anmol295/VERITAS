import crypto from 'node:crypto';

const clone = x => structuredClone(x);
const QUEUE_FRESH_MS = 10_000;   // a queued player must have polled within this window to be matched
const PENDING_MS = 60_000;       // a claimed-but-roomless match is abandoned after this long
const emptyStats = () => ({ matchesPlayed: 0, wins: 0, losses: 0, casesSolved: 0, casesFailed: 0, totalTurns: 0, totalDurationSeconds: 0 });
const emptyProgression = () => ({ honour: 0, falseAccusations: 0, currentWinStreak: 0, longestWinStreak: 0, achievements: [] });

/**
 * In-memory repository. It deliberately behaves like the database one:
 * get() returns a COPY and save() compares versions against the stored copy,
 * so optimistic-concurrency conflicts and partial-mutation bugs show up in local
 * development exactly as they would with Supabase.
 */
export class MemoryRepository {
  constructor() {
    this.rooms = new Map();
    this.sessions = new Map();
    this.stats = new Map();
    this.progression = new Map();
    this.progressionEvents = new Set();
    this.caseHistory = new Map(); // playerId -> attempts, retained in memory mode for local testing
    this.seenCaseFingerprints = new Map(); // playerId -> Set(fingerprint)
    this.players = new Map();
    this.queue = new Map(); // playerId -> { status, at, matchedAt, roomId }
    this.accounts = new Map(); // playerId -> account
    this.caseCatalog = new Map(); // external case id -> immutable case content
  }

  create(room) {
    const caseKey = String(room.case?.id || "");
    const caseJson = JSON.stringify(room.case);
    const existingCase = this.caseCatalog.get(caseKey);
    if (existingCase && existingCase !== caseJson) throw new Error("CASE_ID_COLLISION");
    this.caseCatalog.set(caseKey, caseJson);
    room.stateVersion = 0;
    this.rooms.set(room.id, clone(room));
    return room;
  }

  get(id) {
    const r = this.rooms.get(id);
    return r ? clone(r) : null;
  }

  save(room, expectedVersion = room.stateVersion) {
    const current = this.rooms.get(room.id);
    if (!current || current.stateVersion !== expectedVersion) throw new Error('ROOM_VERSION_CONFLICT');
    const next = clone(room);
    next.stateVersion = expectedVersion + 1;
    this.rooms.set(room.id, next);
    room.stateVersion = next.stateVersion;
    return room;
  }

  delete(id) { this.rooms.delete(id); }

  joinRoomAtomic(roomId, player) {
    const room = this.rooms.get(roomId);
    if (!room || room.status !== 'waiting' || room.players.length >= 2) return false;
    room.players.push(clone(player));
    room.status = 'active';
    room.publicEvents.push({ id: crypto.randomUUID(), text: `${player.name} joined the investigation.`, at: Date.now() });
    room.stateVersion += 1;
    return true;
  }

  async findPlayerRoom(playerId) {
    for (const room of this.rooms.values()) {
      if ((room.status === "waiting" || room.status === "active") && room.players.some(p => p.id === playerId)) {
        return room.id;
      }
    }
    return null;
  }

  // ---- guests / sessions
  createGuestPlayer(playerId, name) {
    this.players.set(playerId, { id: playerId, name });
    return this.createSession(playerId);
  }
  getPlayer(playerId) { return this.players.get(playerId) || null; }

  async registerAccount({ playerId, name, email, username, passwordHash }) {
    const emailKey = String(email).toLowerCase();
    const usernameKey = String(username).toLowerCase();
    for (const account of this.accounts.values()) {
      if (account.email === emailKey) throw new Error('EMAIL_ALREADY_EXISTS');
      if (account.username === usernameKey) throw new Error('USERNAME_ALREADY_EXISTS');
    }
    this.players.set(playerId, { id: playerId, name });
    this.accounts.set(playerId, { playerId, email: emailKey, username: usernameKey, passwordHash, accountType: 'registered', avatarUrl: null, bio: '', createdAt: Date.now() });
    return this.accounts.get(playerId);
  }

  async getAccountByLogin(login) {
    const key = String(login || '').trim().toLowerCase();
    return [...this.accounts.values()].find(a => a.email === key || a.username === key) || null;
  }

  async getAccount(playerId) { return this.accounts.get(playerId) || null; }

  async updateAccount(playerId, patch) {
    const account = this.accounts.get(playerId);
    if (!account) return null;
    const next = { ...account, ...patch };
    for (const other of this.accounts.values()) {
      if (other.playerId !== playerId && patch.username && other.username === patch.username.toLowerCase()) throw new Error('USERNAME_ALREADY_EXISTS');
    }
    this.accounts.set(playerId, next);
    if (patch.displayName) this.players.set(playerId, { id: playerId, name: patch.displayName });
    return next;
  }

  createSession(playerId) {
    const token = crypto.randomBytes(32).toString('base64url');
    this.sessions.set(token, { playerId, expiresAt: Date.now() + 30 * 24 * 3600 * 1000 });
    return token;
  }
  resolveSession(token) {
    const s = token ? this.sessions.get(token) : null;
    if (!s || s.expiresAt < Date.now()) return null;
    return s.playerId;
  }

  destroySession(token) { this.sessions.delete(token); }

  // ---- matchmaking
  /** Returns 'queued' | 'pending' (already claimed, room being created) | 'matched' (has a live room). */
  async enqueue(playerId) {
    if (await this.findPlayerRoom(playerId)) throw new Error("You are already in an unfinished match.");
    const now = Date.now();
    const q = this.queue.get(playerId);
    if (q?.status === 'matched') {
      if (q.roomId) {
        const room = this.rooms.get(q.roomId);
        if (room && room.status !== 'finished') return 'matched';
      } else if (now - q.matchedAt < PENDING_MS) {
        return 'pending';
      }
    }
    this.queue.set(playerId, { status: 'waiting', at: now });
    return 'queued';
  }

  async claimOpponent(playerId) {
    const me = this.queue.get(playerId);
    if (!me || me.status !== 'waiting') return null;
    const now = Date.now();
    const candidate = [...this.queue.entries()]
      .filter(([id, q]) => id !== playerId && q.status === 'waiting' && now - q.at < QUEUE_FRESH_MS)
      .sort((a, b) => a[1].at - b[1].at)[0];
    if (!candidate) return null;
    const [opponentId] = candidate;
    for (const id of [playerId, opponentId]) this.queue.set(id, { status: 'matched', at: now, matchedAt: now, roomId: null });
    return opponentId;
  }

  async setMatchForPlayers(playerA, playerB, roomId) {
    for (const id of [playerA, playerB]) {
      const q = this.queue.get(id) || { status: 'matched', at: Date.now(), matchedAt: Date.now() };
      this.queue.set(id, { ...q, status: 'matched', roomId });
    }
  }

  /** Room id of the player's unfinished matchmade game, if any. */
  async findMatch(playerId) {
    const q = this.queue.get(playerId);
    if (q?.status === 'matched' && q.roomId) {
      const room = this.rooms.get(q.roomId);
      if (room && room.status !== 'finished') return q.roomId;
    }
    return null;
  }

  /** Undo a claim when room creation failed, so neither player is stuck. */
  async releaseMatch(playerIds) {
    for (const id of playerIds) {
      const q = this.queue.get(id);
      if (q?.status === 'matched' && !q.roomId) this.queue.set(id, { status: 'waiting', at: Date.now() });
    }
  }

  // ---- stats + progression
  async recordStats(playerId, win, solved, turns, duration) {
    return this.recordMatchProgression({ roomId: `legacy-${crypto.randomUUID()}`, playerId, win, solved, falseAccusation: false, turns, duration, honourDelta: win && solved ? 50 : 5 });
  }

  async recordMatchProgression({ roomId, playerId, win, solved, falseAccusation, turns, duration, honourDelta }) {
    const eventKey = `${roomId}:${playerId}`;
    if (this.progressionEvents.has(eventKey)) return this.getProgression(playerId);
    this.progressionEvents.add(eventKey);
    const s = this.stats.get(playerId) || emptyStats();
    s.matchesPlayed++; win ? s.wins++ : s.losses++; solved ? s.casesSolved++ : s.casesFailed++;
    s.totalTurns += turns || 0; s.totalDurationSeconds += duration || 0;
    this.stats.set(playerId, s);
    const pr = this.progression.get(playerId) || emptyProgression();
    pr.honour = Math.max(0, pr.honour + Number(honourDelta || 0));
    if (falseAccusation) pr.falseAccusations++;
    pr.currentWinStreak = win ? pr.currentWinStreak + 1 : 0;
    pr.longestWinStreak = Math.max(pr.longestWinStreak, pr.currentWinStreak);
    const earned = new Set(pr.achievements);
    if (s.casesSolved >= 1) earned.add('first-blood');
    if (s.casesSolved >= 10) earned.add('the-detective');
    if (s.matchesPlayed >= 25) earned.add('veteran-investigator');
    if (s.casesSolved >= 5 && pr.falseAccusations === 0) earned.add('clean-record');
    if (pr.longestWinStreak >= 5) earned.add('unstoppable');
    pr.achievements = [...earned];
    this.progression.set(playerId, pr);
    return { ...pr, achievements: [...pr.achievements] };
  }

  async hasSeenCaseFingerprint(playerId, fingerprint) {
    return Boolean(this.seenCaseFingerprints.get(playerId)?.has(fingerprint));
  }

  async recordCaseHistory(entry) {
    const { playerId, caseFingerprint } = entry;
    const seen = this.seenCaseFingerprints.get(playerId) || new Set();
    const firstAttempt = !seen.has(caseFingerprint);
    seen.add(caseFingerprint);
    this.seenCaseFingerprints.set(playerId, seen);
    const rows = this.caseHistory.get(playerId) || [];
    const existing = rows.find(r => r.roomId === entry.roomId);
    if (existing) return { firstAttempt: existing.firstAttempt };
    rows.unshift({ ...entry, honourDelta: firstAttempt ? Number(entry.honourDelta || 0) : 0, firstAttempt, id: crypto.randomUUID(), createdAt: Date.now() });
    this.caseHistory.set(playerId, rows);
    return { firstAttempt };
  }

  async getCaseHistory(playerId, { limit = 25, offset = 0, status = null } = {}) {
    const rows = this.caseHistory.get(playerId) || [];
    const filtered = status ? rows.filter(r => r.status === status) : rows;
    return { items: filtered.slice(offset, offset + limit), total: filtered.length, limit, offset };
  }

  async getStats(playerId) { return { ...(this.stats.get(playerId) || emptyStats()) }; }
  async getProgression(playerId) { const p = this.progression.get(playerId) || emptyProgression(); return { ...p, achievements: [...p.achievements] }; }
}
