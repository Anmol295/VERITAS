import crypto from "node:crypto";

export const ACTION_COST = {
  move: 1,
  investigate: 1,
  question: 1,
  observe: 2,
  analyze: 1,
  bluff: 1
};

function clone(x) {
  return structuredClone(x);
}

// Generated cases are not guaranteed to contain a location called "entrance".

function canonicalizeCase(value) {
  if (Array.isArray(value)) {
    const normalized = value.map(canonicalizeCase);
    if (normalized.every(item => item && typeof item === "object" && !Array.isArray(item) && typeof item.id === "string")) {
      return normalized.sort((a, b) => a.id.localeCompare(b.id));
    }
    if (normalized.every(item => Array.isArray(item) && item.length === 2 && item.every(x => typeof x === "string"))) {
      return normalized
        .map(edge => [...edge].sort())
        .sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
    }
    return normalized;
  }
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !["id", "external_id", "createdAt", "verifiedAt"].includes(key))
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, val]) => [key, canonicalizeCase(val)]));
}

function caseFingerprintFor(gameCase) {
  const payload = canonicalizeCase({
    subtitle: gameCase.subtitle, suspects: gameCase.suspects, locations: gameCase.locations,
    timeline: gameCase.timeline, evidence: gameCase.evidence, solution: gameCase.solution,
    logic: gameCase.logic, map: gameCase.map
  });
  return crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex');
}

function startLocation(gameCase) {
  const locations = gameCase?.locations || [];
  return locations.some(l => l.id === "entrance") ? "entrance" : (locations[0]?.id || "entrance");
}

export class GameEngine {
  constructor(repository, caseGenerator) {
    this.repository = repository;
    this.caseGenerator = caseGenerator;
  }

  async freshCaseForPlayers(playerIds = [], attempts = 5) {
    for (let attempt = 0; attempt < attempts; attempt++) {
      const gameCase = await this.caseGenerator();
      const fingerprint = caseFingerprintFor(gameCase);
      let seen = false;
      if (this.repository.hasSeenCaseFingerprint) {
        for (const playerId of playerIds.filter(Boolean)) {
          if (await this.repository.hasSeenCaseFingerprint(playerId, fingerprint)) { seen = true; break; }
        }
      }
      if (!seen) return gameCase;
    }
    throw new Error('No unseen case is currently available for this investigator. Please try again later.');
  }

  async createRoom(playerName = "Player 1", playerId = null) {
    if (playerId && this.repository.findPlayerRoom && await this.repository.findPlayerRoom(playerId)) {
      throw new Error("You are already in an unfinished match.");
    }
    const gameCase = await this.freshCaseForPlayers([playerId]);
    const id = crypto.randomBytes(3).toString("hex").toUpperCase();
    const room = {
      id,
      status: "waiting",
      createdAt: Date.now(),
      case: gameCase,
      turn: 0,
      activePlayer: 0,
      players: [
        {
          id: playerId || crypto.randomUUID(),
          name: playerName,
          index: 0,
          locationId: startLocation(gameCase),
          actionPoints: 3,
          evidence: [],
          notes: [],
          deductions: [],
          privateFindings: []
        }
      ],
      chat: [],
      publicEvents: [
        { id: crypto.randomUUID(), text: `${playerName} created the case room.`, at: Date.now() }
      ],
      winner: null,
      result: null,
      stateVersion: 0
    };
    return await this.repository.create(room);
  }

  async createMatchedRoom(playerA, playerB) {
    const existingA = playerA?.id && this.repository.findPlayerRoom ? await this.repository.findPlayerRoom(playerA.id) : null;
    const existingB = playerB?.id && this.repository.findPlayerRoom ? await this.repository.findPlayerRoom(playerB.id) : null;
    if (existingA || existingB) throw new Error("A matched player is already in an unfinished match.");
    const gameCase = await this.freshCaseForPlayers([playerA?.id, playerB?.id]);
    const id = crypto.randomBytes(3).toString("hex").toUpperCase();
    const make = (p, index) => ({
      id: p.id, name: p.name, index, locationId: startLocation(gameCase), actionPoints: 3,
      evidence: [], notes: [], deductions: [], privateFindings: []
    });
    const room = {
      id, status: "active", createdAt: Date.now(), case: gameCase, turn: 0, activePlayer: 0,
      players: [make(playerA,0), make(playerB,1)], chat: [], publicEvents: [
        {id:crypto.randomUUID(), text:`${playerA.name} and ${playerB.name} were matched.`, at:Date.now()}
      ], winner:null, result:null, stateVersion:0
    };
    return await this.repository.create(room);
  }

  async joinRoom(roomId, playerName = "Player 2", playerId = null) {
    const room = await this.repository.get(roomId);
    if (!room) throw new Error("Room not found.");
    // Re-joining a room you already belong to (refresh, second tab) is not an error.
    if (playerId && room.players.some(p => p.id === playerId)) return room;
    if (room.players.length >= 2) throw new Error("Room is full.");
    if (room.status === "finished") throw new Error("Room is finished.");
    if (playerId && this.repository.hasSeenCaseFingerprint && await this.repository.hasSeenCaseFingerprint(playerId, caseFingerprintFor(room.case))) {
      throw new Error("You have already completed this case. This room cannot be joined with a previously completed case.");
    }
    if (playerId && this.repository.findPlayerRoom && await this.repository.findPlayerRoom(playerId)) {
      throw new Error("You are already in another unfinished match.");
    }

    const player = {
      id: playerId || crypto.randomUUID(), name: playerName, index: 1, locationId: startLocation(room.case),
      actionPoints: 3, evidence: [], notes: [], deductions: [], privateFindings: []
    };
    if (this.repository.joinRoomAtomic) {
      const joined = await this.repository.joinRoomAtomic(roomId, player);
      if (!joined) throw new Error("Room was filled by another player. Try another room.");
      return await this.repository.get(roomId);
    }
    room.players.push(player);
    room.status = "active";
    room.publicEvents.push({ id: crypto.randomUUID(), text: `${playerName} joined the investigation.`, at: Date.now() });
    await this.repository.save(room, room.stateVersion);
    return room;
  }

  player(room, playerId) {
    const p = room.players.find(x => x.id === playerId);
    if (!p) throw new Error("Player is not part of this room.");
    return p;
  }

  assertTurn(room, player) {
    if (room.status !== "active") throw new Error("The match is not active.");
    if (room.activePlayer !== player.index) throw new Error("It is not your turn.");
  }

  publicState(room, viewerId) {
    const viewer = room.players.find(p => p.id === viewerId);
    return {
      id: room.id,
      status: room.status,
      turn: room.turn,
      activePlayer: room.activePlayer,
      winner: room.winner,
      result: room.result,
      case: {
        id: room.case.id,
        title: room.case.title,
        subtitle: room.case.subtitle,
        difficulty: room.case.difficulty,
        estimatedMinutes: room.case.estimatedMinutes,
        intro: room.case.intro,
        suspects: room.case.suspects.map(({ statement, ...publicSuspect }) => publicSuspect),
        locations: room.case.locations,
        map: room.case.map,
        timeline: room.case.timeline,
        evidenceCatalog: room.case.evidence.map(({ id, title, type, reliability }) => ({ id, title, type, reliability })),
        actions: room.case.actions
      },
      players: room.players.map(p => ({
        id: p.id,
        name: p.name,
        index: p.index,
        locationId: p.locationId,
        actionPoints: p.actionPoints,
        evidenceCount: p.evidence.length,
        noteCount: p.notes.length
      })),
      me: viewer ? {
        id: viewer.id,
        locationId: viewer.locationId,
        actionPoints: viewer.actionPoints,
        evidence: [
          ...viewer.evidence.map(id => room.case.evidence.find(e => e.id === id)).filter(Boolean),
          ...viewer.privateFindings
        ].map(e => clone(e)),
        notes: viewer.notes,
        deductions: viewer.deductions
      } : null,
      publicEvents: room.publicEvents.slice(-30),
      chat: room.chat.slice(-30)
    };
  }

  async perform(room, playerId, action, payload = {}) {
    const player = this.player(room, playerId);
    this.assertTurn(room, player);

    // Object.hasOwn: "constructor"/"toString" etc. must not resolve to inherited properties.
    const cost = Object.hasOwn(ACTION_COST, action) ? ACTION_COST[action] : 0;
    if (!cost) throw new Error("Unknown action.");
    if (player.actionPoints < cost) throw new Error("Not enough action points.");

    let message = "";
    let privateReveal = [];

    if (action === "move") {
      const target = payload.locationId;
      const valid = room.case.locations.some(l => l.id === target);
      if (!valid) throw new Error("Invalid location.");
      if (target === player.locationId) throw new Error("You are already at this location.");
      const edges = room.case.map?.nodes || [];
      if (edges.length) {
        const adjacent = edges.some(edge => Array.isArray(edge) && edge.length === 2 &&
          ((edge[0] === player.locationId && edge[1] === target) || (edge[1] === player.locationId && edge[0] === target)));
        if (!adjacent) throw new Error("That location is not connected to your current position.");
      }
      player.locationId = target;
      message = `${player.name} moved to ${room.case.locations.find(l => l.id === target).name}.`;
    }

    if (action === "investigate") {
      // Any evidence the player has not found yet is discoverable. (Requiring a `reveals` array
      // made every AI-generated case unplayable: the generation contract never asked for it.)
      const candidates = room.case.evidence.filter(e => !player.evidence.includes(e.id) && e.locationId === player.locationId);
      if (!candidates.length) throw new Error("You found nothing new here. Investigate another location.");
      const found = candidates[0];
      player.evidence.push(found.id);
      privateReveal = [found];
      message = `${player.name} investigated ${room.case.locations.find(l => l.id === player.locationId)?.name}.`;
    }

    if (action === "question") {
      const suspect = room.case.suspects.find(s => s.id === payload.suspectId);
      if (!suspect) throw new Error("Choose a suspect.");
      const statementText = suspect.statement || `${suspect.name} gave a statement.`;
      const ev = {
        id: `statement-${suspect.id}`,
        title: `${suspect.name}: interview`,
        type: "Interview",
        reliability: 0.72,
        description: statementText,
        reveals: [statementText]
      };
      const syntheticId = `question:${suspect.id}`;
      if (!player.evidence.includes(syntheticId)) {
        player.evidence.push(syntheticId);
        player.privateFindings.push(ev);
        privateReveal = [ev];
      } else {
        throw new Error("You already questioned this suspect.");
      }
      message = `${player.name} questioned ${suspect.name}.`;
    }

    if (action === "observe") {
      const other = room.players.find(p => p.id !== player.id);
      const observedLocation = other?.locationId || "unknown";
      privateReveal = [{
        id: `observation:${Date.now()}`,
        title: "Opponent observation",
        type: "Observation",
        reliability: 1,
        description: `${other?.name || "Opponent"} is currently at ${room.case.locations.find(l => l.id === observedLocation)?.name || observedLocation}.`,
        reveals: ["opponent location"]
      }];
      message = `${player.name} observed the investigation.`;
    }

    if (action === "analyze") {
      if (!player.evidence.length) throw new Error("Collect evidence before analyzing.");
      privateReveal = [{
        id: `analysis:${Date.now()}`,
        title: "Your analysis",
        type: "Analysis",
        reliability: 1,
        description: "Cross-reference the evidence you have collected. Compare timestamps, source reliability, and independent sources before drawing a conclusion.",
        reveals: ["compare timestamps", "compare independent sources"]
      }];
      message = `${player.name} analyzed their collected evidence.`;
    }

    if (action === "bluff") {
      message = `${player.name} made a deliberately ambiguous claim.`;
    }

    player.actionPoints -= cost;
    room.publicEvents.push({ id: crypto.randomUUID(), text: message, at: Date.now() });

    // Advance the turn in memory and persist ONCE. Two separate saves would let another
    // command slip in between them and leave the room half-updated.
    if (player.actionPoints === 0) this.advanceTurn(room);

    await this.repository.save(room);
    return { room, privateReveal };
  }

  advanceTurn(room) {
    room.activePlayer = room.activePlayer === 0 ? 1 : 0;
    room.turn += 1;
    const next = room.players[room.activePlayer];
    if (next) next.actionPoints = 3;
    room.publicEvents.push({
      id: crypto.randomUUID(),
      text: `${next?.name || "Next player"}'s turn began.`,
      at: Date.now()
    });
  }

  async endTurn(room) {
    this.advanceTurn(room);
    await this.repository.save(room);
  }

  async addNote(room, playerId, text) {
    const normalized = String(text ?? "").trim();
    if (!normalized) throw new Error("Note cannot be empty.");
    if (normalized.length > 1000) throw new Error("Note is too long.");
    const player = this.player(room, playerId);
    if (player.notes.length >= 100) throw new Error("You have reached the note limit for this case.");
    player.notes.push({ id: crypto.randomUUID(), text: normalized, at: Date.now() });
    await this.repository.save(room);
  }

  async setDeduction(room, playerId, deduction) {
    const player = this.player(room, playerId);
    if (!Array.isArray(deduction)) throw new Error("Deductions must be an array.");
    const normalized = [...new Set(deduction)]
      .filter(value => Number.isInteger(value) && value >= 0 && value < 6)
      .slice(0, 6);
    player.deductions = normalized;
    await this.repository.save(room);
  }

  async accuse(room, playerId, accusation) {
    const player = this.player(room, playerId);
    this.assertTurn(room, player);

    const accusationData = {
      suspectId: String(accusation?.suspectId ?? "").trim().slice(0, 100),
      locationId: String(accusation?.locationId ?? "").trim().slice(0, 100),
      method: String(accusation?.method ?? "").trim().slice(0, 500),
      time: String(accusation?.time ?? "").trim().slice(0, 32)
    };
    if (!accusationData.suspectId || !accusationData.locationId || !accusationData.method || !accusationData.time) {
      throw new Error("Complete the accusation before submitting it.");
    }
    if (!room.case.suspects.some(s => s.id === accusationData.suspectId)) throw new Error("Choose a valid suspect.");
    if (!room.case.locations.some(l => l.id === accusationData.locationId)) throw new Error("Choose a valid location.");

    const solution = room.case.solution;
    const correct =
      accusationData.suspectId === solution.suspectId &&
      accusationData.locationId === solution.locationId &&
      accusationData.time === solution.time &&
      accusationData.method.toLowerCase() === String(solution.method || "").trim().toLowerCase();

    room.status = "finished";
    room.winner = correct ? player.id : room.players.find(p => p.id !== player.id)?.id || null;
    room.result = {
      correct,
      accusedBy: player.id,
      accusation: accusationData,
      solution
    };

    room.publicEvents.push({
      id: crypto.randomUUID(),
      text: correct
        ? `${player.name} solved the case.`
        : `${player.name}'s accusation was incorrect. The case is over.`,
      at: Date.now()
    });

    await this.repository.save(room, room.stateVersion);
    const duration = Math.max(0, Math.floor((Date.now() - room.createdAt) / 1000));
    // Fingerprint the actual mystery content, not just its generated ID. This catches
    // duplicate content that a generator accidentally republishes under a new ID.
    const caseFingerprint = caseFingerprintFor(room.case);
    if (this.repository.recordMatchProgression) {
      for (const p of room.players) {
        const isWinner = p.id === room.winner;
        const isAccuser = p.id === player.id;
        const solved = correct && isAccuser;
        const falseAccusation = isAccuser && !correct;
        let honourDelta = correct ? (isWinner ? 50 : 5) : (isAccuser ? -10 : 15);
        let firstAttempt = true;
        if (this.repository.recordCaseHistory) {
          const history = await this.repository.recordCaseHistory({
            playerId: p.id, roomId: room.id, caseId: room.case.id, caseTitle: room.case.title,
            caseFingerprint, status: solved ? "solved" : "failed", won: isWinner, solved,
            turns: room.turn, duration, honourDelta
          });
          firstAttempt = history.firstAttempt;
          // Replaying the same mystery remains allowed, but it cannot be farmed for Honour.
          if (!firstAttempt) honourDelta = 0;
        }
        await this.repository.recordMatchProgression({
          roomId: room.id, playerId: p.id, win: isWinner,
          solved: solved && firstAttempt, falseAccusation, turns: room.turn,
          duration, honourDelta
        });
      }
    } else if (this.repository.recordStats) {
      for (const p of room.players) await this.repository.recordStats(p.id, p.id === room.winner, correct && p.id === player.id, room.turn, duration);
    }
    return room;
  }
}
