import crypto from "node:crypto";
import { demoCase } from "../data/demoCase.js";
import { validateGeneratedCase } from "./validator.js";
import { AIClient } from "./aiClient.js";
import { buildGenerationPrompt, buildVerifierPrompt, CASE_SCHEMA_VERSION } from "./caseSchema.js";

const profile = {
  difficulty: 5,
  targetPlayers: 2,
  estimatedMinutes: 18,
  suspectCount: "5-8",
  locationCount: "6-12",
  timelineEvents: "10-30",
  evidenceItems: "12-28",
  criticalReasoningChains: 2,
  alternativeHypotheses: 2,
  requiredReasoningTypes: ["timeline", "alibi", "physical_or_digital_evidence", "cross-checking_sources"],
  avoid: ["trivia", "guessing", "single-clue solutions", "arbitrary secrets", "unsignposted twists"]
};

function normalizedDemo() {
  const c = structuredClone(demoCase);
  c.schemaVersion = CASE_SCHEMA_VERSION;
  c.logic = {
    premises: [
      "The vault opened at 21:17.",
      "The credential recorded by the vault belonged to Daniel.",
      "Daniel's phone remained near security from 21:14 to 21:24.",
      "The corridor camera is four minutes slow.",
      "Sarah entered the corridor at the corrected time 21:15."
    ],
    inferences: [
      "Credential ownership does not prove physical use.",
      "Daniel had an alibi around the opening time.",
      "Sarah was near the vault immediately before it opened.",
      "The witness's exact 21:20 timing is weak evidence."
    ],
    redHerrings: [
      "Daniel's credential appears to implicate him.",
      "James signed the inventory and therefore had access."
    ],
    alternativeHypotheses: [
      "Daniel physically opened the vault.",
      "James stole the prototype during inventory."
    ]
  };
  c.solution.criticalEvidenceIds = ["ev-cctv", "ev-card", "ev-phone", "ev-statement"];
  const validation = validateGeneratedCase(c);
  if (!validation.valid) throw new Error(`Demo case failed validation: ${validation.errors.join(" | ")}`);
  return c;
}

export class CaseGenerator {
  constructor() {
    this.client = new AIClient({
      baseUrl: process.env.AI_BASE_URL,
      apiKey: process.env.AI_API_KEY,
      model: process.env.AI_MODEL
    });
    this.provider = process.env.AI_PROVIDER || "demo";
    this.maxAttempts = Number(process.env.AI_MAX_ATTEMPTS || 3);
  }

  async generate() {
    if (this.provider === "demo" || !this.client.configured) return normalizedDemo();

    let lastFailure = "unknown";
    for (let attempt = 1; attempt <= this.maxAttempts; attempt++) {
      try {
        const raw = await this.client.json(buildGenerationPrompt(profile), { temperature: 0.9 });
        raw.schemaVersion = CASE_SCHEMA_VERSION;
        raw.id = raw.id || `CASE-${crypto.randomInt(100000, 999999)}`;

        const structural = validateGeneratedCase(raw);
        if (!structural.valid) {
          lastFailure = `structural validation failed: ${structural.errors.join(" | ")}`;
          continue;
        }

        const verification = await this.client.json(buildVerifierPrompt(raw), { temperature: 0.15, maxTokens: 7000 });
        const cleanVerification = verification &&
          verification.pass === true &&
          verification.unique === true &&
          verification.outsideKnowledgeRequired === false &&
          Number.isFinite(Number(verification.score)) && Number(verification.score) >= 70 && Number(verification.score) <= 100 &&
          Number(verification.criticalChainCount) >= 2 &&
          Array.isArray(verification.unexplainedFacts) && verification.unexplainedFacts.length === 0 &&
          Array.isArray(verification.ambiguities) && verification.ambiguities.length === 0 &&
          Array.isArray(verification.hardnessProblems) && verification.hardnessProblems.length === 0;
        if (!cleanVerification) {
          lastFailure = `AI verification rejected case: ${JSON.stringify(verification).slice(0, 1600)}`;
          continue;
        }

        if (verification.derivedSolution?.suspectId !== raw.solution.suspectId ||
            verification.derivedSolution?.locationId !== raw.solution.locationId ||
            verification.derivedSolution?.time !== raw.solution.time ||
            String(verification.derivedSolution?.method || "").trim().toLowerCase() !== String(raw.solution.method || "").trim().toLowerCase()) {
          lastFailure = "independent verifier derived a different solution";
          continue;
        }

        raw.verification = {
          score: Number(verification.score),
          criticalChainCount: Number(verification.criticalChainCount),
          verifiedAt: new Date().toISOString()
        };
        return raw;
      } catch (error) {
        lastFailure = error.message;
      }
    }

    throw new Error(`No AI case passed verification after ${this.maxAttempts} attempts. Last failure: ${lastFailure}`);
  }
}

export async function generateValidatedCase() {
  return new CaseGenerator().generate();
}
