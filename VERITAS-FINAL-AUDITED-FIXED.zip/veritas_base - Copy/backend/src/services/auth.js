import crypto from 'node:crypto';

const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEYLEN = 64;

export function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

export function normalizeUsername(value) {
  return String(value || '').trim().toLowerCase();
}

export function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validateUsername(username) {
  return /^[a-z0-9_]{3,24}$/.test(username);
}

export function validatePassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 128;
}

export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = await new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, KEYLEN, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P, maxmem: 64 * 1024 * 1024 }, (error, key) => {
      if (error) reject(error); else resolve(key);
    });
  });
  return `scrypt$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${salt.toString('base64url')}$${derived.toString('base64url')}`;
}

export async function verifyPassword(password, encoded) {
  try {
    const [scheme, n, r, p, saltText, keyText] = String(encoded || '').split('$');
    if (scheme !== 'scrypt') return false;
    const salt = Buffer.from(saltText, 'base64url');
    const expected = Buffer.from(keyText, 'base64url');
    const actual = await new Promise((resolve, reject) => {
      crypto.scrypt(password, salt, expected.length, { N: Number(n), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024 }, (error, key) => {
        if (error) reject(error); else resolve(key);
      });
    });
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

export function publicProfile(account, player) {
  if (!account && !player) return null;
  return {
    playerId: account?.playerId || player?.id,
    username: account?.username || player?.name || 'Detective',
    displayName: player?.name || account?.username || 'Detective',
    email: account?.email || null,
    accountType: account?.accountType || 'guest',
    avatarUrl: account?.avatarUrl || null,
    bio: account?.bio || '',
    createdAt: account?.createdAt || null
  };
}
