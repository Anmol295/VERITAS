export class AIClient {
  constructor({ baseUrl, apiKey, model }) {
    this.baseUrl = (baseUrl || "").replace(/\/$/, "");
    this.apiKey = apiKey;
    this.model = model;
  }

  get configured() {
    return Boolean(this.baseUrl && this.apiKey && this.model);
  }

  async json(prompt, { temperature = 0.8, maxTokens = 12000 } = {}) {
    if (!this.configured) {
      throw new Error("AI provider is not configured. Set AI_BASE_URL, AI_API_KEY and AI_MODEL.");
    }

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: this.model,
        temperature,
        max_tokens: maxTokens,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "Return valid JSON only. No markdown fences." },
          { role: "user", content: prompt }
        ]
      })
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`AI provider returned ${response.status}: ${body.slice(0, 500)}`);
    }

    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) throw new Error("AI provider returned no message content.");

    try {
      return JSON.parse(content);
    } catch {
      const match = content.match(/\{[\s\S]*\}/);
      if (!match) throw new Error("AI response was not valid JSON.");
      return JSON.parse(match[0]);
    }
  }
}
