# VERITAS Phase 3 — AI Case Contract

Phase 3 changes the architecture from **AI writes a mystery** to **AI proposes a structured case that must survive verification**.

## Pipeline

```text
Case Profile
    ↓
Generator Model
    ↓
JSON / structural validation
    ↓
Independent verifier model
    ↓
Uniqueness + reasoning-chain checks
    ↓
APPROVED CASE
    ↓
Game Engine
```

## Fixed difficulty philosophy

There are no easy/medium/hard campaign levels. Every generated case targets the same five-star difficulty.
Complexity can vary while the intended reasoning depth remains comparable.

The generator targets:

- 5–8 suspects
- 6–12 locations
- 10–30 timeline events
- 12–28 evidence items
- at least 2 independent reasoning chains
- at least 2 plausible alternative hypotheses

## Human-solvability requirements

A case should be rejected if:

- the intended solution depends on one clue only;
- the player must guess a secret fact;
- the answer requires outside trivia;
- the timeline cannot physically happen;
- two solutions remain equally supported;
- a contradiction has no explainable cause;
- the culprit's decisive action has no inferable evidence;
- red herrings are merely random false statements.

## Important security rule

`solution`, `logic`, and verifier output are server-side data. They must never be included in `publicState()`.
Players receive only the evidence they legitimately discover.

## Provider

The included client uses an OpenAI-compatible chat-completions interface configured by:

```env
AI_BASE_URL=
AI_API_KEY=
AI_MODEL=
```

The game does not require an AI key to run: `AI_PROVIDER=demo` uses the built-in validated case.
