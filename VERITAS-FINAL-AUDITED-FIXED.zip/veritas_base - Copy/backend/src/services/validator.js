import { CASE_SCHEMA_VERSION } from "./caseSchema.js";

const unique = arr => new Set(arr).size === arr.length;
const ACTIONS = new Map([
  ["move", 1], ["investigate", 1], ["question", 1],
  ["observe", 2], ["analyze", 1], ["bluff", 1]
]);

function parseClock(value) {
  const match = /^(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(String(value ?? "").trim());
  if (!match) return null;
  const hour = Number(match[1]), minute = Number(match[2]), second = Number(match[3] || 0);
  if (hour > 23 || minute > 59 || second > 59) return null;
  return hour * 3600 + minute * 60 + second;
}

function validText(value, max = 5000) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= max;
}

function connectedMap(locations, edges) {
  if (!locations.length) return false;
  const graph = new Map(locations.map(l => [l.id, new Set()]));
  for (const edge of edges) {
    graph.get(edge[0]).add(edge[1]);
    graph.get(edge[1]).add(edge[0]);
  }
  const seen = new Set([locations[0].id]);
  const queue = [locations[0].id];
  while (queue.length) {
    for (const next of graph.get(queue.shift())) {
      if (!seen.has(next)) { seen.add(next); queue.push(next); }
    }
  }
  return seen.size === locations.length;
}

export function validateGeneratedCase(gameCase) {
  const errors = [];
  const warnings = [];

  if (!gameCase || typeof gameCase !== "object" || Array.isArray(gameCase)) {
    return { valid: false, errors: ["Case is not an object."], warnings };
  }
  if (gameCase.schemaVersion !== CASE_SCHEMA_VERSION) errors.push(`schemaVersion must be ${CASE_SCHEMA_VERSION}.`);
  if (!validText(gameCase.id, 120)) errors.push("Case ID is required.");
  if (!validText(gameCase.title, 200)) errors.push("Case title is required.");
  if (!validText(gameCase.subtitle, 1000)) errors.push("Case subtitle is required.");
  if (!validText(gameCase.intro, 5000)) errors.push("Case intro is required.");
  if (!Number.isInteger(gameCase.difficulty) || gameCase.difficulty !== 5) errors.push("Every generated case must use the fixed 5-star difficulty.");
  if (!Number.isInteger(gameCase.estimatedMinutes) || gameCase.estimatedMinutes < 10 || gameCase.estimatedMinutes > 30) errors.push("Estimated duration must be 10–30 minutes.");

  const suspects = Array.isArray(gameCase.suspects) ? gameCase.suspects : [];
  const locations = Array.isArray(gameCase.locations) ? gameCase.locations : [];
  const evidence = Array.isArray(gameCase.evidence) ? gameCase.evidence : [];
  const timeline = Array.isArray(gameCase.timeline) ? gameCase.timeline : [];
  const suspectIds = suspects.map(x => x?.id);
  const locationIds = locations.map(x => x?.id);
  const evidenceIds = evidence.map(x => x?.id);

  if (suspects.length < 5 || suspects.length > 8) errors.push("Suspect count must be 5–8.");
  if (locations.length < 6 || locations.length > 12) errors.push("Location count must be 6–12.");
  if (timeline.length < 10 || timeline.length > 30) errors.push("Timeline must contain 10–30 events.");
  if (evidence.length < 12 || evidence.length > 28) errors.push("Evidence must contain 12–28 items.");
  if (!unique(suspectIds) || suspectIds.some(id => !validText(id, 100))) errors.push("Suspect IDs must be unique and non-empty.");
  if (!unique(locationIds) || locationIds.some(id => !validText(id, 100))) errors.push("Location IDs must be unique and non-empty.");
  if (!unique(evidenceIds) || evidenceIds.some(id => !validText(id, 100))) errors.push("Evidence IDs must be unique and non-empty.");

  for (const s of suspects) {
    if (!s || !validText(s.id, 100) || !validText(s.name, 200) || !validText(s.role, 200) ||
        !validText(s.description, 2000) || !validText(s.statement, 2000)) {
      errors.push(`Malformed suspect: ${s?.id || "unknown"}. Suspects need a statement for questioning.`);
    }
  }

  for (const l of locations) {
    if (!l || !validText(l.id, 100) || !validText(l.name, 200)) errors.push(`Malformed location: ${l?.id || "unknown"}.`);
  }

  const cctvCameras = new Map();
  for (const e of evidence) {
    if (!e || !validText(e.id, 100) || !validText(e.title, 300) || !validText(e.type, 100) || !validText(e.description, 5000)) {
      errors.push(`Malformed evidence: ${e?.id || "unknown"}.`);
      continue;
    }
    if (typeof e.reliability !== "number" || !Number.isFinite(e.reliability) || e.reliability < 0 || e.reliability > 1) {
      errors.push(`Evidence ${e.id} has invalid reliability.`);
    }
    if (!validText(e.locationId, 100) || !locationIds.includes(e.locationId)) errors.push(`Evidence ${e.id} must reference a valid discovery location.`);
    if (!Array.isArray(e.reveals)) errors.push(`Evidence ${e.id} reveals must be an array.`);
    else if (e.reveals.length > 30 || e.reveals.some(x => typeof x !== "string" || x.length > 500)) errors.push(`Evidence ${e.id} contains malformed reveals.`);

    if (String(e.type).toLowerCase() === "cctv") {
      const c = e.cctv;
      if (!c || typeof c !== "object" || Array.isArray(c)) errors.push(`CCTV evidence ${e.id} needs cctv metadata.`);
      else {
        if (!validText(c.cameraId, 100) || !validText(c.cameraName, 200)) errors.push(`CCTV evidence ${e.id} needs cameraId and cameraName.`);
        else {
          const priorCamera = cctvCameras.get(c.cameraId);
          if (priorCamera && priorCamera !== c.cameraName) errors.push(`CCTV camera ${c.cameraId} has inconsistent names.`);
          cctvCameras.set(c.cameraId, c.cameraName);
        }
        if (parseClock(c.recordedAt) === null && !/^\d{4}-\d{2}-\d{2}T/.test(String(c.recordedAt || ""))) errors.push(`CCTV evidence ${e.id} needs a valid recordedAt.`);
        if (!Number.isFinite(Number(c.durationSeconds)) || Number(c.durationSeconds) <= 0 || Number(c.durationSeconds) > 3600) errors.push(`CCTV evidence ${e.id} needs a valid durationSeconds.`);
        if (c.clockOffsetSeconds !== undefined && (!Number.isFinite(Number(c.clockOffsetSeconds)) || Math.abs(Number(c.clockOffsetSeconds)) > 86400)) errors.push(`CCTV evidence ${e.id} has invalid clockOffsetSeconds.`);
        if (c.sceneNotes !== undefined && (!Array.isArray(c.sceneNotes) || c.sceneNotes.length > 50 || c.sceneNotes.some(x => typeof x !== "string" || x.length > 1000))) errors.push(`CCTV evidence ${e.id} sceneNotes must be an array of short strings.`);
      }
    }
  }

  const timelineTimes = [];
  for (const t of timeline) {
    const seconds = parseClock(t?.time);
    if (!t || !validText(t.id, 100) || !validText(t.time, 32) || !validText(t.text, 5000) || !validText(t.source, 300)) {
      errors.push(`Malformed timeline event: ${t?.id || "unknown"}.`);
    } else if (seconds === null) {
      errors.push(`Timeline event ${t.id} has an invalid time.`);
    } else {
      timelineTimes.push(seconds);
    }
  }
  for (let i = 1; i < timelineTimes.length; i++) {
    if (timelineTimes[i] < timelineTimes[i - 1]) {
      errors.push("Timeline events must be chronological.");
      break;
    }
  }

  const mapEdges = gameCase.map?.nodes;
  if (!Array.isArray(mapEdges) || !mapEdges.length) {
    errors.push("Case map must contain location edges.");
  } else {
    const seenEdges = new Set();
    for (const edge of mapEdges) {
      if (!Array.isArray(edge) || edge.length !== 2 || edge[0] === edge[1] ||
          !locationIds.includes(edge[0]) || !locationIds.includes(edge[1])) {
        errors.push("Map contains an invalid location edge.");
        continue;
      }
      const key = [...edge].sort().join("\u0000");
      if (seenEdges.has(key)) errors.push(`Map contains duplicate edge ${edge.join(" ↔ ")}.`);
      seenEdges.add(key);
    }
    if (!connectedMap(locations, mapEdges.filter(e => Array.isArray(e) && e.length === 2 && locationIds.includes(e[0]) && locationIds.includes(e[1]) && e[0] !== e[1]))) {
      errors.push("Map must connect every location.");
    }
  }

  const actions = Array.isArray(gameCase.actions) ? gameCase.actions : [];
  const actionIds = actions.map(x => x?.id);
  if (!unique(actionIds)) errors.push("Action IDs must be unique.");
  for (const [id, cost] of ACTIONS) {
    const action = actions.find(x => x?.id === id);
    if (!action) errors.push(`Required action ${id} is missing.`);
    else {
      if (action.cost !== cost) errors.push(`Action ${id} must cost ${cost}.`);
      if (!validText(action.label, 100)) errors.push(`Action ${id} needs a label.`);
    }
  }
  if (actions.some(x => x?.id && !ACTIONS.has(x.id))) warnings.push(`Unsupported action ${actions.find(x => x?.id && !ACTIONS.has(x.id))?.id} will not be usable by the server.`);

  const solution = gameCase.solution;
  if (!solution || typeof solution !== "object" || Array.isArray(solution)) errors.push("Missing hidden solution.");
  else {
    if (!suspectIds.includes(solution.suspectId)) errors.push("Solution references an unknown suspect.");
    if (!locationIds.includes(solution.locationId)) errors.push("Solution references an unknown location.");
    if (!validText(solution.method, 500) || parseClock(solution.time) === null) errors.push("Solution method/time is invalid.");
    if (!validText(solution.explanation, 5000)) errors.push("Solution explanation is incomplete.");
    if (!Array.isArray(solution.criticalEvidenceIds) || solution.criticalEvidenceIds.length < 4 ||
        !unique(solution.criticalEvidenceIds)) {
      errors.push("Solution needs at least four unique critical evidence IDs.");
    } else {
      for (const id of solution.criticalEvidenceIds) if (!evidenceIds.includes(id)) errors.push(`Critical evidence ${id} does not exist.`);
    }
  }

  const logic = gameCase.logic;
  if (!logic || typeof logic !== "object" || Array.isArray(logic)) errors.push("Missing hidden logic graph.");
  else {
    if (!Array.isArray(logic.premises) || logic.premises.length < 4 || logic.premises.some(x => typeof x !== "string" || x.length > 2000)) errors.push("Need at least four valid hidden premises.");
    if (!Array.isArray(logic.inferences) || logic.inferences.length < 4 || logic.inferences.some(x => typeof x !== "string" || x.length > 2000)) errors.push("Need at least four valid hidden inferences.");
    if (!Array.isArray(logic.redHerrings) || logic.redHerrings.length < 2 || logic.redHerrings.some(x => typeof x !== "string" || x.length > 2000)) errors.push("Need at least two valid red herrings.");
    if (!Array.isArray(logic.alternativeHypotheses) || logic.alternativeHypotheses.length < 2 || logic.alternativeHypotheses.some(x => typeof x !== "string" || x.length > 2000)) errors.push("Need at least two valid alternative hypotheses.");
  }

  return { valid: errors.length === 0, errors, warnings };
}
