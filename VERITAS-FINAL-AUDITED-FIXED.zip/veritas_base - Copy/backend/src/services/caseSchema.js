export const CASE_SCHEMA_VERSION = "3.0";

export const caseContract = {
  type: "object",
  required: ["schemaVersion","id","title","subtitle","difficulty","estimatedMinutes","intro","suspects","locations","timeline","evidence","actions","solution","logic"],
  properties: {
    schemaVersion: { type: "string" },
    id: { type: "string" },
    title: { type: "string" },
    subtitle: { type: "string" },
    difficulty: { type: "integer", minimum: 5, maximum: 5 },
    estimatedMinutes: { type: "integer", minimum: 10, maximum: 30 },
    intro: { type: "string" },
    suspects: { type: "array", minItems: 5, maxItems: 8 },
    locations: { type: "array", minItems: 6, maxItems: 12 },
    timeline: { type: "array", minItems: 10, maxItems: 30 },
    evidence: { type: "array", minItems: 12, maxItems: 28 },
    actions: { type: "array" },
    solution: {
      type: "object",
      required: ["suspectId","locationId","method","time","explanation","criticalEvidenceIds"]
    },
    logic: {
      type: "object",
      required: ["premises","inferences","redHerrings","alternativeHypotheses"]
    }
  }
};

export function buildGenerationPrompt(profile) {
  return `
You are the case architect for VERITAS, a competitive 2-player deduction game.
Generate ONE completely self-contained mystery as strict JSON. Do not output markdown.

GAME PHILOSOPHY
- Every case is a standalone 5-star case. There is no campaign progression.
- Difficulty must come from reasoning, conflicting-but-explainable evidence, temporal logic,
  alternative hypotheses, and information asymmetry — NOT from obscure trivia.
- The case must be humane: a careful human player can solve it using only the information in the case.
- There must be one intended solution. A player should be able to explain WHY alternatives fail.
- Never rely on "the culprit secretly did X" unless there is evidence from which X can be inferred.
- Never require knowledge outside the case.
- Do not use supernatural explanations unless the case explicitly establishes them.
- Do not make a clue meaningless just because it is a red herring; every clue should have a plausible interpretation.
- Include redundant evidence: critical conclusions should have at least two independent supporting chains.

TARGET PROFILE
${JSON.stringify(profile, null, 2)}

REQUIRED CASE STRUCTURE
- suspects: 5–8 people with distinct roles, motives/opportunities, and plausible alibis.
- locations: 6–12 connected locations.
- timeline: 10–30 chronologically coherent events with times.
- evidence: 12–28 items. Evidence may include CCTV, logs, statements, physical evidence,
  messages, access records, documents, environmental observations, etc.
  Every evidence item must have: id, title, type, description, reliability (number 0–1),
  locationId (the id of the location where a detective can find it), and reveals
  (array of short facts a player learns from it).
- CCTV evidence must additionally include cctv: { cameraId, cameraName, recordedAt, durationSeconds,
  clockOffsetSeconds, sceneNotes }. The footage must describe only events supported by the case timeline/evidence.
- every suspect additionally has a short "statement" (what they say when questioned).
- every timeline event has: id, time, text, source.
- top level also needs: subtitle, intro, and map: { nodes: [[locationId, locationId], ...] }
  connecting the locations, plus actions: the six actions move, investigate, question, observe, analyze, bluff.
- solution: one suspect, location, method, exact/near-exact time, explanation, and criticalEvidenceIds.
- logic: explicit hidden reasoning graph for the verifier. It must identify premises,
  inferences, plausible red herrings, and alternative hypotheses.

IMPORTANT
The hidden logic and solution are server-side only. They must be included in the JSON so the
server can verify the case, but they must NEVER be sent to players.
`;
}

export function buildVerifierPrompt(gameCase) {
  return `
You are an independent mystery verifier. You did NOT create this case.
Analyze the supplied VERITAS case as a skeptical human detective.

Your job is NOT to praise it. Try to BREAK it.

Return strict JSON only with:
{
  "pass": boolean,
  "score": 0-100,
  "derivedSolution": {"suspectId":string,"locationId":string,"method":string,"time":string},
  "unique": boolean,
  "criticalChainCount": number,
  "unexplainedFacts": [string],
  "ambiguities": [string],
  "outsideKnowledgeRequired": boolean,
  "hardnessProblems": [string],
  "reasoning": [string]
}

PASS CONDITIONS
1. The intended solution can be derived only from the supplied case.
2. The derived solution matches the hidden solution.
3. At least two materially independent reasoning chains support the key conclusion.
4. At least one plausible alternative hypothesis is explicitly defeated by evidence.
5. No critical fact is an unsupported secret.
6. Timeline and physical constraints are coherent.
7. A human can explain the solution without guessing.
8. The case is difficult because of reasoning, not missing information.

CASE:
${JSON.stringify(gameCase, null, 2)}
`;
}
