import "./env.js"; // must stay first: loads backend/.env before anything reads process.env
import express from "express";
import cors from "cors";
import http from "node:http";
import crypto from "node:crypto";
import { Server } from "socket.io";
import { createRepository } from "./db/repositoryFactory.js";
import { GameEngine } from "./game/engine.js";
import { generateValidatedCase } from "./services/caseGenerator.js";
import { hashPassword, verifyPassword, normalizeEmail, normalizeUsername, validateEmail, validateUsername, validatePassword, publicProfile } from "./services/auth.js";

const PORT = Number(process.env.PORT || 4000);

// FRONTEND_ORIGIN may be a comma-separated list. localhost and 127.0.0.1 are different
// origins to a browser, so both are allowed by default.
// Surrounding quotes/whitespace and a trailing slash in the .env value are tolerated, because
// a browser's Origin header never has them and a mismatch silently blocks every request.
const ALLOWED_ORIGINS = new Set(
  (process.env.FRONTEND_ORIGIN || "http://localhost:5173,http://127.0.0.1:5173,http://localhost:5500,http://127.0.0.1:5500")
    .split(",").map(s => s.trim().replace(/^["']|["']$/g, "").replace(/\/+$/, "")).filter(Boolean)
);
const warnedOrigins = new Set();
const corsOrigin = (origin, cb) => {
  const ok = !origin || ALLOWED_ORIGINS.has(origin);
  if (!ok && !warnedOrigins.has(origin)) {
    warnedOrigins.add(origin);
    console.warn(`[veritas] CORS: blocked origin "${origin}". Allowed: ${[...ALLOWED_ORIGINS].join(", ")}. Fix FRONTEND_ORIGIN in backend/.env and restart.`);
  }
  cb(null, ok);
};

const repository = createRepository();
const engine = new GameEngine(repository, () => generateValidatedCase());

const isConflict = e => String(e?.message || "").includes("ROOM_VERSION_CONFLICT");
const SAFE_ERRORS = [
  "Join a room first.", "Room not found.", "Room is full.", "Room is finished.",
  "The match is not active.", "It is not your turn.", "Unknown action.",
  "Not enough action points.", "Invalid location.", "You are already at this location.",
  "That location is not connected to your current position.", "You found nothing new here. Investigate another location.",
  "Choose a suspect.", "You already questioned this suspect.", "Collect evidence before analyzing.",
  "Note cannot be empty.", "Note is too long.", "You have reached the note limit for this case.",
  "Deductions must be an array.", "Complete the accusation before submitting it.",
  "Choose a valid suspect.", "Choose a valid location.",
  "You are already in an unfinished match.", "You are already in another unfinished match.",
  "A matched player is already in an unfinished match.",
  "You have already completed this case. This room cannot be joined with a previously completed case.",
  "Room was filled by another player. Try another room.", "Could not join this room.",
  "Player is not part of this room."
];
const errMsg = e => {
  const message = String(e?.message || "");
  if (isConflict(e)) return "The game state changed at the same moment. Please try again.";
  if (message === "CASE_ID_COLLISION") return "The generated case ID collided with a different stored mystery. Please try again.";
  if (SAFE_ERRORS.includes(message)) return message;
  if (/^(Sign in|Enter |Username must|Password must|Email is already|Username is already|Too many account|Invalid username|Email or username|Avatar URL)/.test(message)) return message;
  console.error("[veritas] internal error:", e);
  return "Unexpected server error.";
};
const cleanName = (v, fallback) => String(v || fallback).trim().slice(0, 40) || fallback;
const errorStatus = error => {
  const message = String(error?.message || "");
  if (isConflict(error) || /already in (another )?unfinished match|room is full|already completed this case|USERNAME_ALREADY_EXISTS|EMAIL_ALREADY_EXISTS/.test(message)) return 409;
  if (/not part of this room|not your turn|sign in to play|sign in to view|sign in to edit/.test(message)) return 403;
  if (/room not found/i.test(message)) return 404;
  if (SAFE_ERRORS.includes(message) || /^(Enter |Username must|Password must|Invalid username|Email is already|Username is already|Avatar URL)/.test(message)) return 400;
  return 500;
};

function requestToken(req) {
  const auth = String(req.headers.authorization || "");
  if (/^Bearer\s+/i.test(auth)) return auth.replace(/^Bearer\s+/i, "").trim();
  // Body tokens remain supported for POST compatibility. GET/query-string tokens are
  // intentionally rejected so credentials cannot leak through URLs, history, logs, or referrers.
  return String(req.body?.sessionToken || "").trim() || null;
}

const authRateBuckets = new Map();
function allowAuthRequest(req, limit = 12, windowMs = 60_000) {
  // Do not trust a client-supplied X-Forwarded-For header unless the deployment
  // explicitly configures Express proxy trust.
  const key = String(req.ip || "unknown").trim();
  const now = Date.now();
  const current = authRateBuckets.get(key) || [];
  const fresh = current.filter(t => now - t < windowMs);
  if (fresh.length >= limit) return false;
  fresh.push(now);
  authRateBuckets.set(key, fresh);
  if (authRateBuckets.size > 5000) {
    for (const [k, values] of authRateBuckets) if (!values.some(t => now - t < windowMs)) authRateBuckets.delete(k);
  }
  return true;
}

async function playerFromToken(token) {
  if (!token) return null;
  return await repository.resolveSession(String(token));
}

async function registeredPlayerFromToken(token) {
  const playerId = await playerFromToken(token);
  if (!playerId) return null;
  const account = await repository.getAccount(playerId);
  return account?.accountType === "registered" ? playerId : null;
}

// Writes to the same room are queued one after another inside this process, so ordinary
// simultaneous clicks/chat never contend. The database version check (optimistic
// concurrency) remains the safety net for multiple server instances.
const roomQueues = new Map();
function serialized(roomId, task) {
  const prev = roomQueues.get(roomId) || Promise.resolve();
  const run = prev.then(task);
  const tail = run.catch(() => {});
  roomQueues.set(roomId, tail);
  tail.then(() => { if (roomQueues.get(roomId) === tail) roomQueues.delete(roomId); });
  return run;
}

/**
 * Load the room, run `fn(room)` (which mutates and saves it), and retry on an optimistic
 * version conflict. Each retry re-reads fresh state, so turn/AP rules are re-validated
 * against whatever the other player just did.
 */
async function withRoom(roomId, fn, attempts = 4) {
  if (!roomId) throw new Error("Join a room first.");
  return serialized(roomId, async () => {
    for (let i = 0; i < attempts; i++) {
      const room = await repository.get(roomId);
      if (!room) throw new Error("Room not found.");
      try {
        const out = await fn(room);
        return { room, out };
      } catch (e) {
        if (isConflict(e) && i < attempts - 1) continue;
        throw e;
      }
    }
  });
}

const app = express();
app.use(cors({ origin: corsOrigin, credentials: true }));
app.use(express.json({ limit: "100kb" }));

app.get("/api/health", (req, res) => {
  const origin = req.headers.origin || null;
  res.json({
    ok: true,
    allowedOrigins: [...ALLOWED_ORIGINS],
    requestOrigin: origin,
    originAllowed: origin ? ALLOWED_ORIGINS.has(origin) : null,
    service: "veritas-backend",
    time: new Date().toISOString(),
    persistence: repository.constructor.name === "SupabaseRepository" ? "supabase" : "memory",
    aiProvider: process.env.AI_PROVIDER || "demo",
    aiConfigured: Boolean(process.env.AI_BASE_URL && process.env.AI_API_KEY && process.env.AI_MODEL)
  });
});

// Development/admin endpoint. In production protect this with authentication/rate limits.
app.post("/api/cases/generate", async (req, res) => {
  const adminToken = String(process.env.CASE_GENERATION_ADMIN_TOKEN || "").trim();
  const supplied = String(req.headers["x-veritas-admin-token"] || "").trim();
  if (!adminToken || supplied !== adminToken) return res.status(404).json({ error: "Not found." });
  try {
    const generated = await generateValidatedCase();
    // Never expose generated.solution or generated.logic to an ordinary client.
    res.json({
      id: generated.id, title: generated.title, subtitle: generated.subtitle,
      difficulty: generated.difficulty, estimatedMinutes: generated.estimatedMinutes,
      suspects: generated.suspects, locations: generated.locations,
      timeline: generated.timeline, evidence: generated.evidence,
      verification: generated.verification || null
    });
  } catch (error) {
    res.status(422).json({ error: error.message });
  }
});

app.post("/api/auth/guest", async (_req, res) => {
  res.status(403).json({ error: "Guest play is disabled. Create a VERITAS account or sign in to play." });
});

app.get("/api/public/config", (_req, res) => {
  res.json({ contactEmail: String(process.env.VERITAS_CONTACT_EMAIL || "").trim() || null });
});

app.post("/api/auth/register", async (req, res) => {
  if (!allowAuthRequest(req)) return res.status(429).json({ error: "Too many account requests. Please wait a minute and try again." });
  try {
    const email = normalizeEmail(req.body?.email);
    const username = normalizeUsername(req.body?.username);
    const password = req.body?.password;
    const displayName = cleanName(req.body?.displayName, username || "Detective");
    if (!validateEmail(email)) return res.status(400).json({ error: "Enter a valid email address." });
    if (!validateUsername(username)) return res.status(400).json({ error: "Username must be 3–24 characters using letters, numbers, or underscores." });
    if (!validatePassword(password)) return res.status(400).json({ error: "Password must be 8–128 characters." });
    const existing = await repository.getAccountByLogin(email) || await repository.getAccountByLogin(username);
    if (existing) return res.status(409).json({ error: existing.email === email ? "Email is already registered." : "Username is already taken." });
    const playerId = crypto.randomUUID();
    const passwordHash = await hashPassword(password);
    const account = await repository.registerAccount({ playerId, name: displayName, email, username, passwordHash });
    const sessionToken = await repository.createSession(playerId);
    res.status(201).json({ playerId, sessionToken, profile: publicProfile(account, { id: playerId, name: displayName }) });
  } catch (error) {
    const known = ["EMAIL_ALREADY_EXISTS", "USERNAME_ALREADY_EXISTS", "ACCOUNT_ALREADY_EXISTS"];
    res.status(known.includes(error.message) ? 409 : 500).json({ error: known.includes(error.message) ? "Email or username is already in use." : "Unexpected server error." });
    if (!known.includes(error.message)) console.error("[veritas] registration error:", error);
  }
});

app.post("/api/auth/login", async (req, res) => {
  if (!allowAuthRequest(req)) return res.status(429).json({ error: "Too many sign-in attempts. Please wait a minute and try again." });
  try {
    const login = String(req.body?.login || "").trim().toLowerCase();
    const password = req.body?.password;
    if (!login || !password) return res.status(400).json({ error: "Enter your username/email and password." });
    const account = await repository.getAccountByLogin(login);
    if (!account || !(await verifyPassword(password, account.passwordHash))) return res.status(401).json({ error: "Invalid username/email or password." });
    const player = await repository.getPlayer(account.playerId);
    const sessionToken = await repository.createSession(account.playerId);
    res.json({ playerId: account.playerId, sessionToken, profile: publicProfile(account, player) });
  } catch (error) { res.status(500).json({ error: errMsg(error) }); }
});

app.post("/api/auth/logout", async (req, res) => {
  try { await repository.destroySession(req.body?.sessionToken); res.json({ ok: true }); }
  catch (error) { console.error("[veritas] logout error:", error); res.status(500).json({ error: "Unexpected server error." }); }
});

app.post("/api/rooms", async (req, res) => {
  try {
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to play VERITAS. Guest play is disabled." });
    const account = await repository.getAccount(playerId);
    const playerName = cleanName(account?.username || req.body?.playerName, "Detective");
    const room = await engine.createRoom(playerName, playerId);
    res.json({ roomId: room.id, playerId });
  } catch (error) { res.status(errorStatus(error)).json({ error: errMsg(error) }); }
});

app.post("/api/rooms/:roomId/join", async (req, res) => {
  try {
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to play VERITAS. Guest play is disabled." });
    const roomId = req.params.roomId.toUpperCase();
    const name = cleanName(req.body?.playerName, "Player 2");
    const room = await engine.joinRoom(roomId, name, playerId);
    if (!room.players.some(p => p.id === playerId)) throw new Error("Could not join this room.");
    // Tell the player already waiting in the room that their opponent has arrived.
    broadcast(room);
    res.json({ roomId: room.id, playerId });
  } catch (error) { res.status(errorStatus(error)).json({ error: errMsg(error) }); }
});

app.post("/api/matchmaking/queue", async (req, res) => {
  let claimed = null;
  try {
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to play VERITAS. Guest play is disabled." });
    const activeRoom = await repository.findPlayerRoom?.(playerId);
    if (activeRoom) return res.status(409).json({ error: "You are already in an unfinished match." });
    const reply = roomId => res.json({ status: "matched", roomId, playerId });

    const existing = await repository.findMatch(playerId);
    if (existing) return reply(existing);

    // Polling doubles as a heartbeat: only recently-polled players are eligible to be matched.
    const queued = await repository.enqueue(playerId);
    if (queued === "matched") {
      const room = await repository.findMatch(playerId);
      if (room) return reply(room);
    }
    if (queued === "pending") return res.json({ status: "queued" });

    const opponentId = await repository.claimOpponent(playerId);
    if (!opponentId) return res.json({ status: "queued" });
    claimed = [playerId, opponentId];

    const opponentName = (await repository.getPlayer(opponentId))?.name || "Opponent";
    const myName = (await repository.getPlayer(playerId))?.name || cleanName(req.body?.playerName, "Detective");
    const room = await engine.createMatchedRoom({ id: playerId, name: myName }, { id: opponentId, name: opponentName });
    await repository.setMatchForPlayers(playerId, opponentId, room.id);
    claimed = null;
    reply(room.id);
  } catch (error) {
    // If a pair was claimed but the room could not be created (e.g. AI generation failed),
    // put both players back in the queue instead of leaving them stuck.
    if (claimed) { try { await repository.releaseMatch(claimed); } catch {} }
    res.status(errorStatus(error)).json({ error: errMsg(error) });
  }
});

app.get("/api/rooms/:roomId", async (req, res) => {
  try {
    const room = await repository.get(req.params.roomId.toUpperCase());
    if (!room) return res.status(404).json({ error: "Room not found." });
    // A bare playerId is not a credential (it is visible to the opponent): session token only.
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to play VERITAS. Guest play is disabled." });
    if (!room.players.some(p => p.id === playerId)) return res.status(403).json({ error: "You are not part of this room." });
    res.json(engine.publicState(room, playerId));
  } catch (error) { res.status(errorStatus(error)).json({ error: errMsg(error) }); }
});

app.get("/api/me/stats", async (req, res) => {
  try {
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to view your statistics." });
    res.json(await repository.getStats(playerId));
  } catch (error) { res.status(500).json({ error: errMsg(error) }); }
});

app.get("/api/me/case-history", async (req, res) => {
  try {
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to view your case archive." });
    const limit = Math.min(50, Math.max(1, Number.parseInt(req.query.limit || "25", 10) || 25));
    const offset = Math.max(0, Number.parseInt(req.query.offset || "0", 10) || 0);
    const status = ["solved", "failed"].includes(req.query.status) ? req.query.status : null;
    res.json(await repository.getCaseHistory(playerId, { limit, offset, status }));
  } catch (error) { res.status(500).json({ error: errMsg(error) }); }
});

app.get("/api/me/profile", async (req, res) => {
  try {
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to view your profile." });
    const [account, player, stats, progression] = await Promise.all([repository.getAccount(playerId), repository.getPlayer(playerId), repository.getStats(playerId), repository.getProgression(playerId)]);
    res.json({ profile: publicProfile(account, player), stats, progression });
  } catch (error) { res.status(500).json({ error: errMsg(error) }); }
});

app.patch("/api/me/profile", async (req, res) => {
  try {
    const playerId = await registeredPlayerFromToken(requestToken(req));
    if (!playerId) return res.status(401).json({ error: "Sign in to edit your profile." });
    const patch = {};
    if (req.body?.username !== undefined) {
      const username = normalizeUsername(req.body.username);
      if (!validateUsername(username)) return res.status(400).json({ error: "Username must be 3–24 characters using letters, numbers, or underscores." });
      patch.username = username;
    }
    if (req.body?.displayName !== undefined) patch.displayName = cleanName(req.body.displayName, "Detective");
    if (req.body?.bio !== undefined) patch.bio = String(req.body.bio).trim().slice(0, 160);
    if (req.body?.avatarUrl !== undefined) {
      const avatar = String(req.body.avatarUrl || "").trim();
      if (avatar && !/^https?:\/\//i.test(avatar)) return res.status(400).json({ error: "Avatar URL must start with http:// or https://." });
      patch.avatarUrl = avatar || null;
    }
    const account = await repository.updateAccount(playerId, patch);
    const player = await repository.getPlayer(playerId);
    res.json({ profile: publicProfile(account, player) });
  } catch (error) {
    if (error.message === "USERNAME_ALREADY_EXISTS") return res.status(409).json({ error: "Username is already taken." });
    res.status(500).json({ error: error.message });
  }
});

// Malformed JSON etc. -> JSON error instead of an HTML stack trace.
app.use((err, _req, res, _next) => {
  if (err?.type === "entity.parse.failed") return res.status(400).json({ error: "Invalid JSON body." });
  console.error("[veritas] unhandled request error:", err);
  res.status(err?.status && err.status < 500 ? err.status : 500).json({ error: "Unexpected server error." });
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: corsOrigin, methods: ["GET", "POST"] } });

// Every socket for a player sits in its own Socket.IO room, so a player with two tabs
// (or a reconnect) receives their personal, private view of the state.
const playerChannel = id => `player:${id}`;

function broadcast(room) {
  for (const p of room.players) {
    io.to(playerChannel(p.id)).emit("state", engine.publicState(room, p.id));
  }
}

io.on("connection", socket => {
  const safe = handler => async (...args) => {
    try { await handler(...args); }
    catch (error) { socket.emit("error-message", errMsg(error)); }
  };

  socket.on("join-room", safe(async ({ roomId, sessionToken } = {}) => {
    const playerId = await registeredPlayerFromToken(sessionToken);
    if (!playerId) throw new Error("Sign in to play VERITAS. Guest play is disabled.");
    const room = await repository.get(String(roomId || "").toUpperCase());
    if (!room) throw new Error("Room not found.");
    engine.player(room, playerId); // throws if this player is not in the room

    if (socket.data.playerId && socket.data.playerId !== playerId) socket.leave(playerChannel(socket.data.playerId));
    socket.join(playerChannel(playerId));
    socket.data.roomId = room.id;
    socket.data.playerId = playerId;
    socket.emit("state", engine.publicState(room, playerId));
    broadcast(room);
  }));

  socket.on("action", safe(async ({ action, payload } = {}) => {
    const { room, out } = await withRoom(socket.data.roomId, r => engine.perform(r, socket.data.playerId, action, payload || {}));
    socket.emit("private-reveal", out.privateReveal);
    broadcast(room);
  }));

  socket.on("end-turn", safe(async () => {
    const { room } = await withRoom(socket.data.roomId, async r => {
      const player = engine.player(r, socket.data.playerId);
      engine.assertTurn(r, player);
      await engine.endTurn(r);
    });
    broadcast(room);
  }));

  socket.on("add-note", safe(async ({ text } = {}) => {
    const { room } = await withRoom(socket.data.roomId, r => engine.addNote(r, socket.data.playerId, text));
    broadcast(room);
  }));

  socket.on("set-deductions", safe(async ({ deductions } = {}) => {
    const { room } = await withRoom(socket.data.roomId, r => engine.setDeduction(r, socket.data.playerId, deductions));
    broadcast(room);
  }));

  socket.on("chat", safe(async ({ text } = {}) => {
    const message = String(text || "").trim().slice(0, 500);
    if (!message) return;
    const { room } = await withRoom(socket.data.roomId, async r => {
      const player = engine.player(r, socket.data.playerId);
      r.chat.push({ id: crypto.randomUUID(), playerId: player.id, playerName: player.name, text: message, at: Date.now() });
      await repository.save(r);
    });
    broadcast(room);
  }));

  socket.on("accuse", safe(async ({ accusation } = {}) => {
    const { room } = await withRoom(socket.data.roomId, r => engine.accuse(r, socket.data.playerId, accusation));
    broadcast(room);
  }));
});

process.on("unhandledRejection", reason => console.error("[veritas] unhandled rejection:", reason));

server.listen(PORT, () => {
  console.log(`VERITAS backend running on http://localhost:${PORT}`);
  console.log(`  persistence: ${repository.constructor.name === "SupabaseRepository" ? "supabase" : "memory"}, allowed origins: ${[...ALLOWED_ORIGINS].join(", ")}`);
});
