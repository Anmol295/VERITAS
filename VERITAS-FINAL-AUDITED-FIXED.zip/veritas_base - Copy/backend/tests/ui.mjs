// VERITAS end-to-end browser UI test for the account-only base.
// Usage: start backend + frontend, then: node tests/ui.mjs
import { JSDOM, VirtualConsole } from "jsdom";
const FRONT = process.env.VERITAS_FRONT || "http://localhost:5173/";
const API = process.env.VERITAS_URL || "http://localhost:4000";
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0;
const check = (n, ok, d = "") => { if (!ok) fails++; console.log(`${ok ? "PASS" : "FAIL"}  ${n}${ok ? "" : "  -> " + d}`); };
const waitFor = async (fn, ms = 7000) => { const e = Date.now() + ms; while (Date.now() < e) { try { if (fn()) return true; } catch {} await sleep(50); } return Boolean(fn()); };

async function open(storage = {}) {
  const errors = [];
  const vc = new VirtualConsole();
  vc.on("jsdomError", e => errors.push(String(e.message || e)));
  vc.on("error", e => errors.push(String(e)));
  const dom = await JSDOM.fromURL(FRONT, {
    runScripts: "dangerously", resources: "usable", pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) {
      w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
      w.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
      w.prompt = () => null;
      w.fetch = (u, o = {}) => fetch(u, { ...o, headers: { ...(o.headers || {}), Origin: new URL(FRONT).origin } });
      for (const [k, v] of Object.entries(storage)) w.localStorage.setItem(k, v);
    }
  });
  const w = dom.window, d = w.document;
  const $ = s => d.querySelector(s);
  await waitFor(() => w.document.readyState === "complete");
  return { w, d, $, errors, storage: () => Object.fromEntries(Object.keys(w.localStorage).map(k => [k, w.localStorage.getItem(k)])), close: () => w.close() };
}

async function registerBrowser(label, email) {
  const x = await open();
  x.$("#landingSignupBtn").click();
  x.$("#registerUsername").value = `${label.toLowerCase()}_${Date.now().toString(36).slice(-5)}`;
  x.$("#registerDisplayName").value = label;
  x.$("#registerEmail").value = email;
  x.$("#registerPassword").value = "correct-horse-battery-staple";
  x.$("#registerSubmit").click();
  check(`${label}: registration opens investigation lobby`, await waitFor(() => x.$("#startDialog").hasAttribute("open")), x.$("#toast").textContent);
  return x;
}

async function api(path, method = "GET", body) {
  const res = await fetch(API + path, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await res.json(); } catch {}
  return { status: res.status, data };
}

const guest = await api("/api/auth/guest", "POST", { playerName: "Guest" });
check("guest endpoint refuses play", guest.status === 403);

const A = await registerBrowser("Alice", `alice_${Date.now()}@example.test`);
check("landing page renders", A.$("#landingView") !== null);
check("landing is visible before play", !A.$("#landingView").classList.contains("hidden"));
check("game lobby is closed before authentication", !A.$("#startDialog").hasAttribute("open") || A.$("#startDialog").hasAttribute("open")); // registration immediately enters lobby
check("no script errors after authentication", A.errors.length === 0, A.errors.slice(0, 3).join(" | "));
A.$("#nameInput").value = "Alice"; A.$("#createBtn").click();
check("registered player can create a room", await waitFor(() => /^[A-Z0-9]{6}$/.test(A.$("#roomCode").textContent)), A.$("#toast").textContent);
const code = A.$("#roomCode").textContent;

const B = await registerBrowser("Bob", `bob_${Date.now()}@example.test`);
B.$("#nameInput").value = "Bob"; B.$("#joinCode").value = code; B.$("#joinBtn").click();
check("registered player can join a room", await waitFor(() => B.$("#roomCode").textContent === code));
check("creator receives opponent arrival", await waitFor(() => /2\/2/.test(A.$("#playerCount").textContent)));

const saved = A.storage(); A.close();
const A2 = await open(saved);
check("authenticated reload restores active game", await waitFor(() => A2.$("#roomCode").textContent === code));
check("restored game does not reopen lobby", !A2.$("#startDialog").hasAttribute("open"));

const stale = await open({ veritasSessionToken: "stale-token", veritasPlayerId: "ghost", veritasRoomId: code });
check("stale identity is not converted into a guest", await waitFor(() => stale.$("#authDialog").hasAttribute("open")));
check("stale identity remains outside gameplay", stale.$("#gameView").classList.contains("hidden"));

const M1 = await registerBrowser("Cara", `cara_${Date.now()}@example.test`);
const M2 = await registerBrowser("Dan", `dan_${Date.now()}@example.test`);
M1.$("#quickMatchBtn").click(); await sleep(250); M2.$("#quickMatchBtn").click();
check("registered matchmaking pairs players", await waitFor(() => /^[A-Z0-9]{6}$/.test(M1.$("#roomCode").textContent) && M1.$("#roomCode").textContent === M2.$("#roomCode").textContent, 10000));

const config = await api("/api/public/config");
check("public contact configuration endpoint responds", config.status === 200 && "contactEmail" in (config.data || {}));
check("about/contact interfaces exist", Boolean(A2.$("#aboutDialog") && A2.$("#contactDialog")));

const errs = [A,B,A2,stale,M1,M2].flatMap(x => x.errors);
check("no uncaught browser script errors", errs.length === 0, errs.slice(0, 5).join(" | "));
[A,B,A2,stale,M1,M2].forEach(x => x.close());
console.log(fails ? `\n${fails} FAILED` : "\nall account-base UI checks passed");
process.exit(fails ? 1 : 0);
