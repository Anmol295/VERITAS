-- Behavioural test of the Phase 5 SQL functions. Run against a SCRATCH database after migrations 001-003
-- (it inserts and edits rows):  psql "$DATABASE_URL" -f tests/sql_functions.sql
\set ON_ERROR_STOP off
\pset pager off
insert into cases(external_id,title,difficulty,public_data,secret_solution) values('C1','t',5,'{}','{}');
insert into players(id,display_name) values
 ('00000000-0000-0000-0000-00000000000a','A'),('00000000-0000-0000-0000-00000000000b','B'),('00000000-0000-0000-0000-00000000000c','C');
insert into game_rooms(id,case_id,status) select 'ROOM01', id, 'active' from cases limit 1;

\echo '--- claim_room_version: correct expected version succeeds (expect 1)'
select claim_room_version('ROOM01', 0);
\echo '--- stale expected version must raise ROOM_VERSION_CONFLICT'
select claim_room_version('ROOM01', 0);

\echo '--- matchmaking lifecycle'
select 'A enqueue', enqueue_matchmaking('00000000-0000-0000-0000-00000000000a');
select 'A claim alone (expect null)', claim_matchmaking_player('00000000-0000-0000-0000-00000000000a');
select 'B enqueue', enqueue_matchmaking('00000000-0000-0000-0000-00000000000b');
select 'B claim (expect A)', claim_matchmaking_player('00000000-0000-0000-0000-00000000000b');
select 'A polls while room is being created (expect pending, NOT reset)', enqueue_matchmaking('00000000-0000-0000-0000-00000000000a');
select player_id, status, room_id, matched_at is not null as has_matched_at from matchmaking_queue order by player_id;
update matchmaking_queue set room_id='ROOM01' where player_id in ('00000000-0000-0000-0000-00000000000a','00000000-0000-0000-0000-00000000000b');
select 'A polls with live room (expect matched)', enqueue_matchmaking('00000000-0000-0000-0000-00000000000a');
update game_rooms set status='finished' where id='ROOM01';
select 'A polls after room finished (expect queued = can play again)', enqueue_matchmaking('00000000-0000-0000-0000-00000000000a');
select player_id, status, room_id from matchmaking_queue where player_id='00000000-0000-0000-0000-00000000000a';

\echo '--- stale waiting players are not matched'
update matchmaking_queue set status='waiting', room_id=null, queued_at=now()-interval '5 minutes' where player_id='00000000-0000-0000-0000-00000000000b';
select 'C enqueue', enqueue_matchmaking('00000000-0000-0000-0000-00000000000c');
select 'C claim with only a stale opponent + A waiting', claim_matchmaking_player('00000000-0000-0000-0000-00000000000c');
\echo '--- caller not in waiting state cannot claim (expect null)'
update matchmaking_queue set status='matched' where player_id='00000000-0000-0000-0000-00000000000c';
select claim_matchmaking_player('00000000-0000-0000-0000-00000000000c');

\echo '--- permissions'
set role anon;
select claim_room_version('ROOM01', 1);
select record_match_stat('00000000-0000-0000-0000-00000000000a', true,true,1,1);
reset role;
set role service_role;
select 'service_role can call record_match_stat' as ok, record_match_stat('00000000-0000-0000-0000-00000000000a', true,true,1,1);
reset role;
