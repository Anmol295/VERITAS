import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const dir = fileURLToPath(new URL('../supabase/migrations/', import.meta.url));
const files = fs.readdirSync(dir).filter(x => /^\d+_.*\.sql$/.test(x)).sort();
if (files.length !== 7) throw new Error(`Expected 7 ordered migrations, found ${files.length}.`);
for (let i = 1; i <= 7; i++) {
  if (!files[i - 1].startsWith(String(i).padStart(3, '0') + '_')) throw new Error(`Migration ${i} is missing or out of order.`);
}
const sql = files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n');
for (const needle of [
  'alter table public.cases enable row level security',
  'alter table public.room_players enable row level security',
  'revoke all on function public.record_match_progression',
  'revoke all on function public.record_player_case_history',
  'create or replace function public.save_room_state',
  'create or replace function public.prevent_multiple_unfinished_rooms',
  'grant execute on function public.save_room_state(jsonb,bigint) to service_role'
]) {
  if (!sql.includes(needle)) throw new Error(`Missing SQL hardening contract: ${needle}`);
}
console.log('SQL CONTRACT TEST: PASS');
