// Mock OpenAI-compatible provider + AI case pipeline test.
// Start the backend first:
//   PERSISTENCE=memory PORT=4131 AI_PROVIDER=openai AI_BASE_URL=http://localhost:4130 AI_API_KEY=x AI_MODEL=m AI_MAX_ATTEMPTS=1 node src/server.js
import http from "node:http";
import { io } from "socket.io-client";
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const check = (n, ok, d = "") => { if (!ok) fails++; console.log(`${ok ? "PASS" : "FAIL"}  ${n}${ok ? "" : "  -> " + d}`); };
let failGeneration = false, calls = 0;

const mkCase = () => ({
  schemaVersion: "3.0", id: "CASE-" + Math.floor(Math.random() * 900000 + 100000), title: "Mock Mystery", subtitle: "sub", difficulty: 5, estimatedMinutes: 18, intro: "intro <b>bold</b>",
  suspects: Array.from({ length: 5 }, (_, i) => ({ id: `s${i + 1}`, name: `Suspect ${i + 1}`, role: "Role", description: "d", statement: `Suspect ${i + 1} says something.` })),
  locations: Array.from({ length: 6 }, (_, i) => ({ id: `l${i + 1}`, name: `Place ${i + 1}` })),
  map: { nodes: [["l1", "l2"], ["l2", "l3"], ["l3", "l4"], ["l4", "l5"], ["l5", "l6"]] },
  timeline: Array.from({ length: 10 }, (_, i) => ({ id: `t${i}`, time: `21:${10 + i}`, text: `event ${i}`, source: "log" })),
  evidence: Array.from({ length: 12 }, (_, i) => ({ id: `e${i + 1}`, title: `Evidence ${i + 1}`, type: "Log", description: `desc ${i + 1}`, reliability: 0.8, locationId: `l${(i % 6) + 1}`, reveals: [`fact ${i + 1}`] })),
  actions: ["move", "investigate", "question", "observe", "analyze", "bluff"].map(id => ({ id, label: id, cost: 1, public: true })),
  solution: { suspectId: "s2", locationId: "l3", method: "Poison", time: "21:17", explanation: "because", criticalEvidenceIds: ["e1", "e2", "e3", "e4"] },
  logic: { premises: ["a", "b", "c", "d"], inferences: ["a", "b", "c", "d"], redHerrings: ["x", "y"], alternativeHypotheses: ["x", "y"] }
});
const ai = http.createServer((req, res) => {
  let b = ""; req.on("data", c => b += c); req.on("end", () => {
    calls++;
    const prompt = JSON.parse(b).messages[1].content;
    res.setHeader("Content-Type", "application/json");
    if (failGeneration) { res.statusCode = 500; return res.end("boom"); }
    let out;
    if (prompt.includes("independent mystery verifier")) out = { pass: true, unique: true, outsideKnowledgeRequired: false, score: 90, criticalChainCount: 2,
      unexplainedFacts: [], ambiguities: [], hardnessProblems: [],
      derivedSolution: { suspectId: "s2", locationId: "l3", method: "Poison", time: "21:17" } };
    else out = mkCase();
    res.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify(out) } }] }));
  });
}).listen(4130);

const BASE = "http://localhost:4131";
const api = async (p, m = "GET", body) => { const r = await fetch(BASE + p, { method: m, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined }); return { status: r.status, data: await r.json().catch(() => null) }; };
const register = async n => (await api("/api/auth/register", "POST", { username: `ai_${n.toLowerCase()}_${Date.now().toString(36).slice(-4)}`, displayName: n, email: `ai_${n.toLowerCase()}_${Date.now().toString(36).slice(-4)}@example.test`, password: "correct-horse-battery-staple" })).data;
const client = () => new Promise(r => { const s = io(BASE, { transports: ["websocket"], reconnection: false }); s.last = null; s.reveals = []; s.errs = []; s.on("state", x => s.last = x); s.on("private-reveal", x => s.reveals.push(x)); s.on("error-message", m => s.errs.push(m)); s.on("connect", () => r(s)); });
const waitFor = async (fn, ms = 3000) => { const e = Date.now() + ms; while (Date.now() < e) { if (fn()) return true; await sleep(40); } return false; };

const h = (await api("/api/health")).data;
check("server reports AI configured", h.aiConfigured === true && h.aiProvider === "openai");

const A = await register("A"), B = await register("B");
const cr = await api("/api/rooms", "POST", { playerName: "A", sessionToken: A.sessionToken });
check("room created from an AI-generated case", cr.status === 200, JSON.stringify(cr.data));
await api(`/api/rooms/${cr.data.roomId}/join`, "POST", { playerName: "B", sessionToken: B.sessionToken });
const sa = await client(), sb = await client();
sa.emit("join-room", { roomId: cr.data.roomId, sessionToken: A.sessionToken });
sb.emit("join-room", { roomId: cr.data.roomId, sessionToken: B.sessionToken });
await waitFor(() => sa.last?.status === "active" && sb.last);
check("players start on a location that exists in the generated case", ["l1","l2","l3","l4","l5","l6"].includes(sa.last.me.locationId), sa.last.me.locationId);
const act = sa.last.activePlayer === 0 ? sa : sb;
act.emit("action", { action: "investigate", payload: {} });
check("investigate works on evidence without a 'reveals' field", await waitFor(() => act.reveals.length > 0), JSON.stringify(act.errs));
act.emit("action", { action: "question", payload: { suspectId: "s1" } });
check("question uses the generated suspect's statement", await waitFor(() => act.reveals.some(r => /Suspect 1 says something/.test(r?.[0]?.description || ""))), JSON.stringify(act.errs));
act.emit("action", { action: "constructor", payload: {} });
check("inherited property names are not accepted as actions", await waitFor(() => act.errs.some(e => /Unknown action/.test(e))), JSON.stringify(act.errs));
act.emit("accuse", { accusation: { suspectId: "s2", locationId: "l3", method: "poison", time: "21:17" } });
check("correct accusation wins the case", await waitFor(() => sa.last?.status === "finished" && sa.last.result?.correct === true && sa.last.winner === (act === sa ? A.playerId : B.playerId)));

// matchmaking + generation failure -> nobody stranded
failGeneration = true;
const C = await register("C"), D = await register("D");
await api("/api/matchmaking/queue", "POST", { sessionToken: C.sessionToken });
const bad = await api("/api/matchmaking/queue", "POST", { sessionToken: D.sessionToken });
check("failed generation is reported as an error (not silently ignored)", bad.status === 500, JSON.stringify(bad));
failGeneration = false;
const r1 = await api("/api/matchmaking/queue", "POST", { sessionToken: D.sessionToken });
const r2 = await api("/api/matchmaking/queue", "POST", { sessionToken: C.sessionToken });
const statuses = [r1.data?.status, r2.data?.status];
check("after the failure both players are released and can be matched on retry", statuses.includes("matched"), JSON.stringify([r1, r2]));
const r3 = await api("/api/matchmaking/queue", "POST", { sessionToken: C.sessionToken });
const r4 = await api("/api/matchmaking/queue", "POST", { sessionToken: D.sessionToken });
check("both players end up in the SAME room", [r1, r2, r3, r4].map(r => r.data?.roomId).filter(Boolean).every((v, _, a) => v === a[0]) && [r1, r2, r3, r4].some(r => r.data?.roomId), JSON.stringify([r1, r2, r3, r4].map(r => r.data)));

sa.close(); sb.close(); ai.close();
console.log(fails ? `\n${fails} FAILED` : "\nall AI-path checks passed");
process.exit(fails ? 1 : 0);
