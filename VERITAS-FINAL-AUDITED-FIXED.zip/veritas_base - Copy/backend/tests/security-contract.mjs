import assert from 'node:assert/strict';
import { demoCase } from '../src/data/demoCase.js';
import { MemoryRepository } from '../src/game/repository.js';
import { GameEngine } from '../src/game/engine.js';
import { validateGeneratedCase } from '../src/services/validator.js';

const repo = new MemoryRepository();
const engine = new GameEngine(repo, async () => structuredClone(demoCase));
const A = 'security-a';
const B = 'security-b';

const created = await engine.createRoom('A', A);
assert.equal(created.status, 'waiting');
assert.equal(created.players[0].id, A);
await assert.rejects(() => engine.createRoom('A-again', A), /already in an unfinished match/);

const joined = await engine.joinRoom(created.id, 'B', B);
assert.equal(joined.players.length, 2);
const publicForA = engine.publicState(joined, A);
assert.equal(publicForA.case.suspects.some(s => 'statement' in s), false, 'suspect statements must never be public room state');
assert.equal('solution' in publicForA.case, false, 'hidden solution must never be public before resolution');
assert.equal(publicForA.result, null, 'unfinished matches must not expose a result');
assert.equal(publicForA.me.evidence.length, 0);

// Private evidence belongs only to the discovering player.
const reveal = await engine.perform(joined, A, 'move', { locationId: 'hall' });
assert.equal(reveal.privateReveal.length, 0);
const investigation = await engine.perform(joined, A, 'investigate');
assert.equal(investigation.privateReveal.length, 1);
const privateForA = engine.publicState(joined, A);
const privateForB = engine.publicState(joined, B);
assert.equal(privateForA.me.evidence.length, 1);
assert.equal(privateForB.me.evidence.length, 0);

// Input hardening: unbounded notes and arbitrary deduction values are rejected/normalized.
await assert.rejects(() => engine.addNote(joined, A, 'x'.repeat(1001)), /too long/);
await engine.setDeduction(joined, A, [0, 0, 1, 99, -1, '2']);
assert.deepEqual(joined.players.find(p => p.id === A).deductions, [0, 1]);

// Accusations cannot invent a suspect/location or inject an oversized result.
await assert.rejects(() => engine.accuse(joined, A, { suspectId: 'fake', locationId: 'vault', method: 'x', time: '21:17' }), /valid suspect/);
await assert.rejects(() => engine.accuse(joined, A, { suspectId: 'sarah', locationId: 'fake', method: 'x', time: '21:17' }), /valid location/);

// Structural case validation rejects the classes of malformed cases that previously could pass.
const malformed = structuredClone(demoCase);
malformed.timeline = [malformed.timeline[1], malformed.timeline[0], ...malformed.timeline.slice(2)];
assert.equal(validateGeneratedCase(malformed).valid, false);
const disconnected = structuredClone(demoCase);
disconnected.map.nodes = disconnected.map.nodes.slice(0, 1);
assert.equal(validateGeneratedCase(disconnected).valid, false);
const duplicateCritical = structuredClone(demoCase);
duplicateCritical.solution.criticalEvidenceIds = ['ev-cctv', 'ev-cctv', 'ev-card', 'ev-phone'];
assert.equal(validateGeneratedCase(duplicateCritical).valid, false);

console.log('SECURITY CONTRACT TEST: PASS');
