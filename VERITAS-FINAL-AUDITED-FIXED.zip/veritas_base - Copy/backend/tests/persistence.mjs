// Persistence / multi-instance checks. Usage: node tests/persistence.mjs <url1> [<url2>]
// With a second URL (another server process on the SAME database) it also exercises
// optimistic-concurrency conflicts between instances.
import { io } from "socket.io-client";
const [U1, U2] = [process.argv[2] || "http://localhost:4000", process.argv[3]];
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0;
const check = (n, ok, d = "") => { if (!ok) fails++; console.log(`${ok ? "PASS" : "FAIL"}  ${n}${ok ? "" : "  -> " + d}`); };
const api = async (base, path, method = "GET", body, authToken = null) => {
  const r = await fetch(base + path, { method, headers: { "Content-Type": "application/json", ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, data: await r.json().catch(() => null) };
};
const waitFor = async (fn, ms = 4000) => { const e = Date.now() + ms; while (Date.now() < e) { if (await fn()) return true; await sleep(40); } return false; };
const sock = base => { const s = io(base, { transports: ["websocket"], reconnection: false }); s.last = null; s.errs = []; s.on("state", x => s.last = x); s.on("error-message", m => s.errs.push(m)); return new Promise(r => s.on("connect", () => r(s))); };

const register = async n => (await api(U1, "/api/auth/register", "POST", { username: `persist_${n.toLowerCase()}_${Date.now().toString(36).slice(-4)}`, displayName: n, email: `persist_${n.toLowerCase()}_${Date.now().toString(36).slice(-4)}@example.test`, password: "correct-horse-battery-staple" })).data;
const A = await register("A");
const B = await register("B");
const roomId = (await api(U1, "/api/rooms", "POST", { playerName: "A", sessionToken: A.sessionToken })).data.roomId;
await api(U1, `/api/rooms/${roomId}/join`, "POST", { playerName: "B", sessionToken: B.sessionToken });
const sa = await sock(U1); const sb = await sock(U2 || U1);
sa.emit("join-room", { roomId, sessionToken: A.sessionToken });
sb.emit("join-room", { roomId, sessionToken: B.sessionToken });
await waitFor(() => sa.last && sb.last);

// 1. more than 100 chat messages: the newest must still be visible (log must not freeze at the oldest 100)
for (let i = 1; i <= 120; i++) sa.emit("chat", { text: `m${i}` });
await waitFor(async () => (await api(U1, `/api/rooms/${roomId}`, "GET", undefined, A.sessionToken)).data?.chat?.some(m => m.text === "m120"), 15000);
const g = (await api(U1, `/api/rooms/${roomId}`, "GET", undefined, A.sessionToken)).data;
check("after 120 chat messages the newest one is visible on a fresh read", g.chat.some(m => m.text === "m120"), g.chat.slice(-1)[0]?.text);
check("chat window is chronological (oldest -> newest)", g.chat.map(m => Number(m.text.slice(1))).every((v, i, a) => i === 0 || v > a[i - 1]));

// 2. more than 100 public events
for (let i = 0; i < 110; i++) {
  const st = (await api(U1, `/api/rooms/${roomId}`, "GET", undefined, A.sessionToken)).data;
  const active = st.players.find(p => p.index === st.activePlayer).id === A.playerId ? sa : sb;
  active.emit("end-turn");
  await waitFor(async () => (await api(U1, `/api/rooms/${roomId}`, "GET", undefined, A.sessionToken)).data.turn > st.turn, 4000);
}
const g2 = (await api(U1, `/api/rooms/${roomId}`, "GET", undefined, A.sessionToken)).data;
check("turn counter kept advancing past 100 events", g2.turn >= 110, g2.turn);
check("latest event is a recent 'turn began' entry (log not frozen)", /turn began/.test(g2.publicEvents.slice(-1)[0]?.text || "") && g2.publicEvents.length > 20);

// 3. two server instances on one database, both players hammering the same room
if (U2) {
  const before = (await api(U1, `/api/rooms/${roomId}`, "GET", undefined, A.sessionToken)).data.chat.length;
  const N = 10;
  for (let i = 0; i < N; i++) { sa.emit("chat", { text: `x-a${i}` }); sb.emit("chat", { text: `x-b${i}` }); }
  await sleep(6000);
  const g3 = (await api(U1, `/api/rooms/${roomId}`, "GET", undefined, A.sessionToken)).data;
  const got = g3.chat.filter(m => m.text.startsWith("x-")).length;
  const conflictErrs = [...sa.errs, ...sb.errs].filter(e => /same moment/.test(e)).length;
  console.log(`  cross-instance: ${got}/${2 * N} messages persisted, ${conflictErrs} surfaced 'state changed' errors (client can retry)`);
  check("cross-instance conflicts never corrupt state: every persisted+error accounts for each send", got + conflictErrs >= 2 * N - 0, `${got}+${conflictErrs}`);
  check("most cross-instance writes succeed via retry", got >= N, got);
}
sa.close(); sb.close();
console.log(fails ? `\n${fails} FAILED` : "\nall persistence checks passed");
process.exit(fails ? 1 : 0);
