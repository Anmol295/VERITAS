import crypto from 'node:crypto';
import { hashPassword, verifyPassword } from '../src/services/auth.js';
import { MemoryRepository } from '../src/game/repository.js';

const password = 'correct horse battery staple';
const hash = await hashPassword(password);
if (!await verifyPassword(password, hash)) throw new Error('Password verification failed.');
if (await verifyPassword('wrong password', hash)) throw new Error('Wrong password was accepted.');

const repo = new MemoryRepository();
const playerId = crypto.randomUUID();
await repo.registerAccount({
  playerId,
  name: 'ShadowMind',
  email: 'test@veritas.local',
  username: 'shadowmind',
  passwordHash: hash
});

const account = await repo.getAccountByLogin('shadowmind');
if (!account || account.playerId !== playerId) throw new Error('Account lookup failed.');
const token = await repo.createSession(playerId);
if (await repo.resolveSession(token) !== playerId) throw new Error('Account session lookup failed.');
await repo.destroySession(token);
if (await repo.resolveSession(token) !== null) throw new Error('Session logout failed.');

if ((await repo.getAccount(playerId))?.accountType !== 'registered') throw new Error('Registered account type missing.');
if (repo.createGuestPlayer) {
  const guestId = crypto.randomUUID();
  const guestToken = await repo.createGuestPlayer(guestId, 'Guest');
  if (!guestToken || !(await repo.resolveSession(guestToken))) throw new Error('Repository guest compatibility check failed.');
}
console.log('auth test: PASS');
