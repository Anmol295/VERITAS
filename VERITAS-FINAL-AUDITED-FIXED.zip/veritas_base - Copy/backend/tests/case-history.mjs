import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { MemoryRepository } from '../src/game/repository.js';
import { GameEngine } from '../src/game/engine.js';

const repo = new MemoryRepository();
const player = 'investigator-1';
const caseId = 'CASE-ALPHA';
const fingerprint = 'fingerprint-alpha';

assert.equal(await repo.hasSeenCaseFingerprint(player, fingerprint), false);
await repo.recordCaseHistory({ playerId:player, roomId:'ROOM01', caseId, caseTitle:'The Alpha File', caseFingerprint:fingerprint, status:'solved', won:true, solved:true, turns:12, duration:900, honourDelta:50 });
assert.equal(await repo.hasSeenCaseFingerprint(player, fingerprint), true);
const history = await repo.getCaseHistory(player, {limit:25,offset:0});
assert.equal(history.total, 1);
assert.equal(history.items[0].caseId, caseId);
assert.equal(history.items[0].firstAttempt, true);

// A second completion of the same mystery is recorded as a replay and cannot carry Honour.
const replay = await repo.recordCaseHistory({ playerId:player, roomId:'ROOM02', caseId, caseTitle:'The Alpha File', caseFingerprint:fingerprint, status:'solved', won:true, solved:true, turns:8, duration:500, honourDelta:50 });
assert.equal(replay.firstAttempt, false);
const history2 = await repo.getCaseHistory(player, {limit:25,offset:0});
assert.equal(history2.total, 2);
assert.equal(history2.items[0].honourDelta, 0);


const gameCase = { id:'CASE-ALPHA', title:'The Alpha File', suspects:[], locations:[{id:'entrance',name:'Entrance'}], timeline:[], evidence:[], solution:{suspectId:'x',locationId:'entrance',method:'x',time:'00:00'}, actions:[] };
const canonicalize = value => Array.isArray(value) ? value.map(canonicalize) : (!value || typeof value !== 'object' ? value : Object.fromEntries(Object.entries(value).filter(([k]) => !['id','external_id','createdAt','verifiedAt'].includes(k)).sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => [k, canonicalize(v)])));
const fingerprintFor = c => crypto.createHash('sha256').update(JSON.stringify(canonicalize({ subtitle:c.subtitle, suspects:c.suspects, locations:c.locations, timeline:c.timeline, evidence:c.evidence, solution:c.solution, logic:c.logic, map:c.map }))).digest('hex');
await repo.recordCaseHistory({ playerId:player, roomId:'ROOM03', caseId:gameCase.id, caseTitle:gameCase.title, caseFingerprint:fingerprintFor(gameCase), status:'solved', won:true, solved:true, turns:10, duration:700, honourDelta:50 });
const engine = new GameEngine(repo, async () => structuredClone(gameCase));
await assert.rejects(() => engine.createRoom('Detective', player), /No unseen case/);
console.log('CASE HISTORY TEST: PASS');
