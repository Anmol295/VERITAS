import assert from 'node:assert/strict';
import { demoCase } from '../src/data/demoCase.js';
import { MemoryRepository } from '../src/game/repository.js';
import { GameEngine } from '../src/game/engine.js';
import { validateGeneratedCase } from '../src/services/validator.js';

const cctv = demoCase.evidence.find(e => String(e.type).toLowerCase() === 'cctv');
assert.ok(cctv, 'demo case must contain CCTV evidence');
assert.equal(cctv.cctv.cameraId, 'CAM-02');
assert.equal(cctv.cctv.cameraName, 'North Corridor');
assert.equal(cctv.cctv.durationSeconds, 36);
assert.equal(cctv.cctv.clockOffsetSeconds, 240);
assert.ok(Array.isArray(cctv.cctv.sceneNotes));

const bad = structuredClone(demoCase);
bad.schemaVersion = '3.0';
bad.evidence = bad.evidence.map(e => e.type === 'CCTV' ? {...e, cctv: undefined} : e);
const badResult = validateGeneratedCase(bad);
assert.equal(badResult.valid, false);
assert.ok(badResult.errors.some(e => /CCTV evidence ev-cctv needs cctv metadata/.test(e)));

const repo = new MemoryRepository();
const engine = new GameEngine(repo, async () => structuredClone(demoCase));
const room = await engine.createMatchedRoom({id:'player-cctv', name:'Detective'}, {id:'player-two', name:'Partner'});
const before = engine.publicState(room, 'player-cctv');
assert.ok(before.case.evidenceCatalog.every(e => !('cctv' in e)), 'catalog must not leak CCTV metadata');
await engine.perform(room, 'player-cctv', 'move', {locationId: 'hall'});
const result = await engine.perform(room, 'player-cctv', 'investigate');
assert.equal(result.privateReveal[0].id, 'ev-cctv');
assert.equal(result.privateReveal[0].cctv.cameraId, 'CAM-02');
assert.equal(result.privateReveal[0].cctv.durationSeconds, 36);

const after = engine.publicState(room, 'player-cctv');
const owned = after.me.evidence.find(e => e.id === 'ev-cctv');
assert.ok(owned);
assert.equal(owned.cctv.clockOffsetSeconds, 240);
assert.ok(!('solution' in owned));
console.log('EVIDENCE / CCTV TEST: PASS');
