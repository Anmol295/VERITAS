import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../..', import.meta.url));
const html = fs.readFileSync(root + '/frontend/index.html', 'utf8');
const app = fs.readFileSync(root + '/frontend/app.js', 'utf8');
const server = fs.readFileSync(root + '/backend/src/server.js', 'utf8');
const engine = fs.readFileSync(root + '/backend/src/game/engine.js', 'utf8');
const required = [
  ['landingView', html.includes('id="landingView"')],
  ['login CTA', html.includes('id="landingLoginBtn"')],
  ['signup CTA', html.includes('id="landingSignupBtn"')],
  ['about interface', html.includes('id="aboutDialog"')],
  ['contact interface', html.includes('id="contactDialog"')],
  ['auth interface', html.includes('id="authDialog"')],
  ['game starts hidden', html.includes('id="gameView" class="game-view hidden"')],
  ['play requires registered session', app.includes('requireRegisteredSession')],
  ['guest endpoint disabled', server.includes('Guest play is disabled. Create a VERITAS account or sign in to play.')],
  ['room creation is registered-only', server.includes('registeredPlayerFromToken(requestToken(req))')],
  ['public contact config', server.includes('/api/public/config')],
  ['generated landing artwork', fs.existsSync(root + '/frontend/assets/veritas-landing-concept.png')],
  ['case archive interface', html.includes('id="caseArchiveList"')],
  ['case history endpoint', server.includes('/api/me/case-history')],
  ['case replay protection', server.includes('hasSeenCaseFingerprint') || engine.includes('hasSeenCaseFingerprint')],
  ['query-string session tokens rejected', server.includes('credentials cannot leak through URLs')],
  ['public state strips suspect statements', engine.includes('map(({ statement, ...publicSuspect }) => publicSuspect)')],
  ['single unfinished match guard', engine.includes('findPlayerRoom')],
  ['atomic Supabase room save', fs.existsSync(root + '/backend/supabase/migrations/007_veritas_atomic_state_and_room_guard.sql')],
  ['server errors are sanitized', server.includes('Unexpected server error.')]
];
let failed = 0;
for (const [name, ok] of required) { console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`); if (!ok) failed++; }
console.log(failed ? `\n${failed} contract checks failed` : '\nbase contract checks passed');
process.exit(failed ? 1 : 0);
