import assert from 'node:assert/strict';
import { MemoryRepository } from '../src/game/repository.js';

const repo = new MemoryRepository();
const id = 'player-1';

await repo.recordMatchProgression({ roomId:'room-1', playerId:id, win:true, solved:true, falseAccusation:false, turns:8, duration:120, honourDelta:50 });
let p = await repo.getProgression(id);
let s = await repo.getStats(id);
assert.equal(p.honour, 50);
assert.deepEqual(p.achievements, ['first-blood']);
assert.equal(s.matchesPlayed, 1);

// The same room/player result must never be counted twice.
await repo.recordMatchProgression({ roomId:'room-1', playerId:id, win:true, solved:true, falseAccusation:false, turns:8, duration:120, honourDelta:50 });
p = await repo.getProgression(id);
s = await repo.getStats(id);
assert.equal(p.honour, 50);
assert.equal(s.matchesPlayed, 1);

for (let i = 2; i <= 10; i++) {
  await repo.recordMatchProgression({ roomId:`room-${i}`, playerId:id, win:true, solved:true, falseAccusation:false, turns:5, duration:60, honourDelta:50 });
}
p = await repo.getProgression(id);
s = await repo.getStats(id);
assert.equal(s.casesSolved, 10);
assert.equal(p.currentWinStreak, 10);
assert.equal(p.longestWinStreak, 10);
assert.ok(p.achievements.includes('the-detective'));
assert.ok(p.achievements.includes('clean-record'));
assert.ok(p.achievements.includes('unstoppable'));

await repo.recordMatchProgression({ roomId:'room-11', playerId:id, win:false, solved:false, falseAccusation:true, turns:3, duration:30, honourDelta:-10 });
p = await repo.getProgression(id);
assert.equal(p.honour, 490);
assert.equal(p.falseAccusations, 1);
assert.equal(p.currentWinStreak, 0);
assert.equal(p.longestWinStreak, 10);

console.log('PROGRESSION TEST: PASS');
