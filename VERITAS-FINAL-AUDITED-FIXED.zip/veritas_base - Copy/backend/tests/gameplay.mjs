import assert from 'node:assert/strict';
import { demoCase } from '../src/data/demoCase.js';
import { MemoryRepository } from '../src/game/repository.js';
import { GameEngine } from '../src/game/engine.js';

const repo = new MemoryRepository();
const engine = new GameEngine(repo, async () => structuredClone(demoCase));
const room = await engine.createMatchedRoom({id:'gp-a',name:'A'}, {id:'gp-b',name:'B'});

await assert.rejects(
  () => engine.perform(room, 'gp-a', 'move', {locationId:'vault'}),
  /not connected/
);
await engine.perform(room, 'gp-a', 'move', {locationId:'hall'});
assert.equal(room.players[0].locationId, 'hall');
const q = await engine.perform(room, 'gp-a', 'question', {suspectId:'sarah'});
assert.match(q.privateReveal[0].description, /library|vault/i);
const a = await engine.perform(room, 'gp-a', 'analyze');
assert.match(a.privateReveal[0].description, /timestamps|reliability|independent sources/i);
console.log('GAMEPLAY CONTRACT TEST: PASS');
