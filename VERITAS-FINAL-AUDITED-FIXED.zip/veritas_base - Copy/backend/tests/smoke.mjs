// VERITAS end-to-end smoke test.
// Usage: (server running)  node tests/smoke.mjs [baseUrl]
import { io } from "socket.io-client";

const BASE = process.argv[2] || process.env.VERITAS_URL || "http://localhost:4000";
const results = [];
const sleep = ms => new Promise(r => setTimeout(r, ms));

function check(name, ok, detail = "") {
  results.push({ name, ok: Boolean(ok) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${ok ? "" : detail ? "  -> " + detail : ""}`);
}

async function api(path, method = "GET", body, extraHeaders = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: { "Content-Type": "application/json", ...extraHeaders },
    body: body ? JSON.stringify(body) : undefined
  });
  let data = null;
  try { data = await res.json(); } catch {}
  return { status: res.status, data };
}

function client(label) {
  const socket = io(BASE, { transports: ["websocket"], reconnection: false });
  const c = { label, socket, states: [], errors: [], reveals: [] };
  socket.on("state", s => c.states.push(s));
  socket.on("error-message", m => c.errors.push(m));
  socket.on("private-reveal", r => c.reveals.push(r));
  c.last = () => c.states[c.states.length - 1];
  c.connected = new Promise((res, rej) => { socket.on("connect", res); socket.on("connect_error", rej); });
  return c;
}

async function waitFor(fn, ms = 2500, step = 50) {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (fn()) return true; await sleep(step); }
  return Boolean(fn());
}

async function register(name, suffix = name.toLowerCase()) {
  const r = await api("/api/auth/register", "POST", {
    username: suffix.replace(/[^a-z0-9_]/g, "").slice(0, 18) || "detective",
    displayName: name,
    email: `${suffix.replace(/[^a-z0-9_]/g, "")}@example.test`,
    password: "correct-horse-battery-staple"
  });
  return r.data;
}

async function main() {
  const health = await api("/api/health");
  check("health endpoint responds", health.status === 200 && health.data?.ok);

  const guestAttempt = await api("/api/auth/guest", "POST", { playerName: "Guest" });
  check("guest play is disabled", guestAttempt.status === 403, JSON.stringify(guestAttempt.data));
  const A = await register("Alice", "alice_smoke");
  const B = await register("Bob", "bob_smoke");
  check("registered sessions issued", A?.sessionToken && B?.sessionToken && A.playerId !== B.playerId);

  const created = await api("/api/rooms", "POST", { playerName: "Alice", sessionToken: A.sessionToken });
  check("room created", created.status === 200 && /^[A-Z0-9]{6}$/.test(created.data?.roomId || ""), JSON.stringify(created.data));
  const roomId = created.data.roomId;

  const ca = client("A"); await ca.connected;
  ca.socket.emit("join-room", { roomId, sessionToken: A.sessionToken });
  check("creator receives waiting state over socket", await waitFor(() => ca.last()?.status === "waiting"), JSON.stringify(ca.errors));

  const joined = await api(`/api/rooms/${roomId}/join`, "POST", { playerName: "Bob", sessionToken: B.sessionToken });
  check("second player joins via REST", joined.status === 200, JSON.stringify(joined.data));

  const cb = client("B"); await cb.connected;
  cb.socket.emit("join-room", { roomId, sessionToken: B.sessionToken });
  check("joiner receives active state", await waitFor(() => cb.last()?.status === "active"), JSON.stringify(cb.errors));
  check("creator is pushed the 'opponent joined' state without acting", await waitFor(() => ca.last()?.status === "active" && ca.last()?.players.length === 2));

  const third = await register("Eve", "eve_smoke");
  const full = await api(`/api/rooms/${roomId}/join`, "POST", { playerName: "Eve", sessionToken: third.sessionToken });
  check("third player is rejected (room full)", full.status >= 400, JSON.stringify(full));

  // security
  const noAuth = await api(`/api/rooms/${roomId}`);
  check("GET room without session does not expose private state", noAuth.status === 401 || noAuth.data?.me == null, JSON.stringify(noAuth.data?.me));
  const spoof = await api(`/api/rooms/${roomId}?playerId=${A.playerId}`);
  check("raw playerId cannot impersonate a player", spoof.status === 401 || spoof.data?.me == null, JSON.stringify(spoof.data?.me));
  const sa = await api(`/api/rooms/${roomId}`, "GET", undefined, { Authorization: `Bearer ${A.sessionToken}` });
  check("GET room with valid session returns 'me'", sa.status === 200 && sa.data?.me?.id === A.playerId);
  check("solution not present in public state", !JSON.stringify(sa.data).includes('"criticalEvidenceIds"') && !sa.data?.case?.solution);

  const cs = client("spoof"); await cs.connected;
  cs.socket.emit("join-room", { roomId, playerId: A.playerId });
  await sleep(300);
  check("socket join by raw playerId is refused", cs.states.length === 0 && cs.errors.length > 0);
  cs.socket.close();

  // gameplay
  const first = ca.last().activePlayer === 0 ? ca : cb;
  const second = first === ca ? cb : ca;
  second.errors.length = 0;
  second.socket.emit("action", { action: "investigate", payload: {} });
  check("out-of-turn action is rejected", await waitFor(() => second.errors.some(e => /turn/i.test(e))), JSON.stringify(second.errors));

  first.socket.emit("action", { action: "investigate", payload: {} });
  check("active player investigates and gets private reveal", await waitFor(() => first.reveals.length > 0), JSON.stringify(first.errors));
  check("opponent receives updated public state with no private evidence", await waitFor(() => second.last()?.publicEvents?.some(e => /investigated/i.test(e.text))) && (second.last()?.me?.evidence?.length ?? 0) === 0);
  check("investigator's state contains the evidence", (first.last()?.me?.evidence?.length ?? 0) === 1);

  first.socket.emit("action", { action: "bluff", payload: {} });
  first.socket.emit("action", { action: "bluff", payload: {} });
  check("turn passes automatically at 0 AP", await waitFor(() => second.last()?.activePlayer === (first === ca ? 1 : 0) && second.last()?.me?.actionPoints === 3), JSON.stringify(second.last()?.me));

  // chat + notes
  ca.socket.emit("chat", { text: "hello from A" });
  check("chat reaches opponent", await waitFor(() => cb.last()?.chat?.some(m => m.text === "hello from A")));
  ca.socket.emit("add-note", { text: "private note" });
  check("private note stored and visible to author only", await waitFor(() => ca.last()?.me?.notes?.length === 1) && (cb.last()?.me?.notes?.length ?? 0) === 0);

  // concurrent writes from both players must not lose messages
  const N = 8;
  for (let i = 0; i < N; i++) { ca.socket.emit("chat", { text: `a${i}` }); cb.socket.emit("chat", { text: `b${i}` }); }
  const chatOk = await waitFor(() => {
    const texts = (ca.last()?.chat || []).map(m => m.text);
    return Array.from({ length: N }, (_, i) => `a${i}`).every(t => texts.includes(t)) &&
           Array.from({ length: N }, (_, i) => `b${i}`).every(t => texts.includes(t));
  }, 4000);
  check("concurrent chat from both players: no message lost", chatOk, JSON.stringify((ca.last()?.chat || []).length));

  // reconnect with session token
  cb.socket.close();
  const cb2 = client("B2"); await cb2.connected;
  cb2.socket.emit("join-room", { roomId, sessionToken: B.sessionToken });
  check("reconnect with session token restores state", await waitFor(() => cb2.last()?.me?.id === B.playerId), JSON.stringify(cb2.errors));
  ca.socket.emit("chat", { text: "after reconnect" });
  check("reconnected socket keeps receiving broadcasts", await waitFor(() => cb2.last()?.chat?.some(m => m.text === "after reconnect")));

  // accusation ends the match & stats
  const active = ca.last().activePlayer === 0 ? ca : cb2;
  active.errors.length = 0;
  active.socket.emit("accuse", { accusation: { suspectId: "daniel", locationId: "vault", method: "wrong", time: "00:00" } });
  check("wrong accusation finishes the match", await waitFor(() => ca.last()?.status === "finished" && cb2.last()?.status === "finished"), JSON.stringify(active.errors));
  check("loser recorded, winner is the opponent", ca.last()?.winner && ca.last().winner !== (active === ca ? A.playerId : B.playerId));
  const statsA = await api(`/api/me/stats`, "GET", undefined, { Authorization: `Bearer ${A.sessionToken}` });
  const played = statsA.data?.matchesPlayed ?? statsA.data?.matches_played;
  check("stats recorded after finished match", played === 1, JSON.stringify(statsA.data));
  const persisted = await api(`/api/rooms/${roomId}`, "GET", undefined, { Authorization: `Bearer ${A.sessionToken}` });
  check("finished status survives a fresh read from the repository", persisted.data?.status === "finished");
  cb2.socket.emit("action", { action: "bluff", payload: {} });
  check("no actions after match end", await waitFor(() => cb2.errors.length > 0));

  // matchmaking
  const C = await register("Cara", "cara_smoke"), D = await register("Dan", "dan_smoke");
  const q1 = await api("/api/matchmaking/queue", "POST", { sessionToken: C.sessionToken });
  check("first queued player waits", q1.data?.status === "queued", JSON.stringify(q1));
  const q2 = await api("/api/matchmaking/queue", "POST", { sessionToken: D.sessionToken });
  check("second player is matched instantly", q2.data?.status === "matched" && q2.data?.roomId, JSON.stringify(q2));
  const q1b = await api("/api/matchmaking/queue", "POST", { sessionToken: C.sessionToken });
  check("first player learns of the match on next poll", q1b.data?.status === "matched" && q1b.data?.roomId === q2.data?.roomId, JSON.stringify(q1b));
  const mroom = await api(`/api/rooms/${q2.data.roomId}`, "GET", undefined, { Authorization: `Bearer ${C.sessionToken}` });
  check("matched room is active with both players", mroom.data?.status === "active" && mroom.data?.players?.length === 2);

  // a player finishing one match must be able to queue again
  const cc = client("C"), cd = client("D"); await cc.connected; await cd.connected;
  cc.socket.emit("join-room", { roomId: q2.data.roomId, sessionToken: C.sessionToken });
  cd.socket.emit("join-room", { roomId: q2.data.roomId, sessionToken: D.sessionToken });
  await waitFor(() => cc.last() && cd.last());
  const act = cc.last().activePlayer === cc.last().players.find(p => p.id === C.playerId).index ? cc : cd;
  act.socket.emit("accuse", { accusation: { suspectId: "x", locationId: "x", method: "x", time: "x" } });
  await waitFor(() => cc.last()?.status === "finished");
  const q3 = await api("/api/matchmaking/queue", "POST", { sessionToken: C.sessionToken });
  check("after a finished match the player can queue for a new one", q3.data?.status === "queued", JSON.stringify(q3));

  // invalid session
  const bad = await api("/api/rooms/ABCDEF/join", "POST", { sessionToken: "nope" });
  check("invalid session token gets 401", bad.status === 401);

  [ca, cb2, cc, cd].forEach(c => c.socket.close());
  const failed = results.filter(r => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
  process.exit(failed.length ? 1 : 0);
}

main().catch(e => { console.error("Smoke test crashed:", e); process.exit(2); });
