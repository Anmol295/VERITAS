# VERITAS — Base Completion (Phase 6)

Phase 5 hardens the multiplayer core for real-world use while keeping the frontend/backend separated.

## What changed

### 1. Optimistic concurrency
Every room has a `state_version`.

A command reads version N and saves only if the database still contains version N. The successful writer advances it to N+1.

If two commands arrive at the same time, one succeeds and the other receives `ROOM_VERSION_CONFLICT` rather than silently overwriting the first command.

This is the bridge from a prototype game loop to a server-authoritative multiplayer loop.

### 2. Account identity / reconnect
Registered accounts use persistent session tokens. Only the SHA-256 hash is stored in the database. Guest play is disabled.

The token is used to recover the player identity after:
- page refresh
- websocket reconnect
- browser restart while the session remains valid

The frontend never treats a raw player ID as authentication.

### 3. Atomic room joining
Supabase uses `join_room_atomic(...)` so two people cannot both claim seat 2 because they happened to click Join at the same time.

### 4. Matchmaking foundation
A player can enter a matchmaking queue. PostgreSQL locks the candidate row with `FOR UPDATE SKIP LOCKED`, allowing concurrent queue workers to claim different opponents safely.

Once matched, both players receive the same room assignment.

### 5. Player statistics
Persistent statistics are recorded after a finished match:

- matches played
- wins / losses
- cases solved / failed
- total turns
- total investigation time

Endpoint:

`GET /api/me/stats` with `Authorization: Bearer <sessionToken>`

### 6. Backend remains authoritative
The browser cannot decide:
- whose turn it is
- whether an action costs AP
- whether an accusation is correct
- who won
- what private evidence another player owns

## Supabase migration

Run all migrations in order in the Supabase SQL editor:

```text
backend/supabase/migrations/001_veritas_phase4.sql
backend/supabase/migrations/002_veritas_phase5.sql
backend/supabase/migrations/003_veritas_phase5_fixes.sql
backend/supabase/migrations/004_veritas_identity.sql
backend/supabase/migrations/005_veritas_progression.sql
backend/supabase/migrations/006_veritas_case_history.sql
backend/supabase/migrations/007_veritas_atomic_state_and_room_guard.sql
```

## Environment

```env
PORT=4000
FRONTEND_ORIGIN=http://localhost:5173,http://127.0.0.1:5173
PERSISTENCE=supabase
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVER_ONLY_KEY
AI_PROVIDER=demo
```

For local development without Supabase:

```env
PERSISTENCE=memory
```

The memory repository also implements sessions, matchmaking, optimistic versioning, and statistics so the frontend can be developed without a database.

## New API surface

```text
POST /api/auth/guest       # 403 — guest play disabled
POST /api/auth/register
POST /api/auth/login
POST /api/auth/logout
GET  /api/public/config
POST /api/rooms
POST /api/rooms/:roomId/join
POST /api/matchmaking/queue
GET  /api/rooms/:roomId  (Authorization: Bearer <sessionToken>)
GET  /api/me/stats  (Authorization: Bearer <sessionToken>)
```

Socket.IO `join-room` accepts:

```json
{
  "roomId": "ABC123",
  "sessionToken": "..."
}
```

## Phase 6 base boundary

Phase 6C adds server-authoritative Honour, achievements, win streaks, false-accusation tracking, and idempotent match progression. Phase 6D adds a persistent case archive, content fingerprints, and first-attempt-only Honour/unique-solve credit. CCTV generation remains a separate phase.

## Running it

```bash
cd backend
cp .env.example .env      # PERSISTENCE=memory works with no database
npm install
npm start                 # API + Socket.IO on :4000
npm run frontend          # static server for ../frontend on :5173 (second terminal)
```

Open http://localhost:5173. The public landing page is the entry point. A registered account is required before Create Match, Join Match, or Find Opponent can be used.

## Tests

```bash
npm run test:smoke        # REST + 2 sockets, needs `npm start` running
npm run test:persistence  # needs Supabase mode; pass 2 server URLs to test multi-instance
npm run test:ui           # needs `npm start` and `npm run frontend`
npm run test:ai           # mock AI provider; see header of tests/ai-path.mjs
```

`tests/sql_functions.sql` exercises the SQL functions on a scratch Postgres database.

## Phase 5 repair notes

Fixed after the original Phase 5 drop: socket broadcasts never reached players; Supabase saves did not persist turn/status/winner; the event/chat log froze after 100 rows; a player ID was accepted as a credential; matchmaking could deadlock, strand players, or block re-queueing after a finished match; SQL functions were callable with the public key (migration 003); AI-generated cases were unplayable (`reveals` was never requested); the frontend got stuck on stale sessions. Matchmaking treats a player as available only if they polled within the last 10 seconds.

Known limits: Socket.IO pushes do not cross server instances (add a Socket.IO adapter to scale out). The core movement engine now enforces case map adjacency; the frontend map illustration is still a generic layout when a generated case has more locations than its compact display can place.

## Phase 6 — Base completion

The base is now structured around a public product entry point and account-only gameplay.

### Public interface
- Cinematic VERITAS landing page based on the generated visual direction in `frontend/assets/`.
- Home, About, and Contact interfaces.
- Login and Sign Up are separate account interfaces.
- Contact uses `GET /api/public/config` and a configurable `VERITAS_CONTACT_EMAIL`; no fake address is hard-coded.

### Account gate
- Guest play is disabled at the API boundary.
- Room creation, room joining, matchmaking, room reads, and Socket.IO room joins require a registered account.
- Expired sessions return the player to authentication instead of silently creating a guest identity.
- The existing profile screen remains available for authenticated investigators.

### Generated artwork
The landing visual assets were created specifically for VERITAS and live in:

```text
frontend/assets/veritas-landing-concept.png
frontend/assets/veritas-landing-reference.png
```

### Validation
Dependency-free checks:

```bash
npm run test:auth
npm run test:base-contract
```

Full browser/HTTP validation requires `npm install` to complete successfully, then:

```bash
npm start
npm run frontend
npm run test:smoke
npm run test:ui
```

The development container used for this checkpoint could not complete dependency installation, so a live HTTP/browser run was not claimed as passed here.


## Phase 6C — Honour + Progression

- Honour is calculated by the server at case completion; correct solves award +50, a non-accusing opponent receives +5 on a correct solve, an opponent who defeats an incorrect accusation receives +15, and the player making the false accusation receives -10 (Honour never falls below 0).
- Progression writes are idempotent per `room_id + player_id`, so retries cannot duplicate Honour or statistics.
- Tracks matches, wins/losses, cases solved/failed, turns, investigation time, false accusations, current win streak, and longest win streak.
- Achievements currently include First Blood, The Detective, Veteran Investigator, Clean Record, and Unstoppable.
- The profile now displays live Honour, achievement state, false accusations, and streaks.

### Phase 6C migration
Run `backend/supabase/migrations/005_veritas_progression.sql` after migration 004.

### Progression test
```bash
npm run test:progression
```


## Phase 6D — Case archive + replay rules

- Every completed match creates a per-player case-history record with case title/ID, result, win/loss, turns, duration, Honour delta, and whether it was the player's first encounter with that mystery.
- The profile's Case Archive loads real history from `GET /api/me/case-history` with pagination and an optional `status=solved|failed` filter.
- Mystery fingerprints hash the case title, suspects, locations, timeline, evidence, and hidden solution. Re-published identical content is treated as the same mystery even if it receives a new generated ID.
- A previously completed mystery is not offered to that investigator again. The content fingerprint ignores generated IDs and presentation-only metadata, so the same underlying mystery cannot bypass this rule simply by being regenerated under a new case ID or title. Different investigators may still receive the same mystery.
- Archive writes are idempotent per match/player; first-attempt detection is protected by a database unique key and SQL RPC.

### Phase 6D migration
Run `backend/supabase/migrations/006_veritas_case_history.sql` after migration 005. In memory mode, archive data lasts only until the backend restarts; Supabase mode is required for permanent production history.

### Phase 6D test
```bash
npm run test:case-history
```

## Phase 6E — CCTV & Advanced Evidence

Phase 6E adds a structured evidence layer for CCTV. AI-generated cases can define CCTV metadata (`cameraId`, `cameraName`, `recordedAt`, `durationSeconds`, `clockOffsetSeconds`, and `sceneNotes`). Structural validation rejects CCTV evidence missing this metadata.

The game client now opens discovered evidence in a dedicated Evidence Viewer. CCTV uses a case-authored reconstruction visual with scanlines, camera/timestamp overlays, metadata, observed facts, and a playback timeline. The visual is explicitly presentation-only; the authoritative facts come from the server's evidence record. No hidden solution is exposed through the viewer.

Run the new dependency-free regression test with:

```bash
cd backend
node tests/evidence.mjs
```

The existing profile, progression, case-history, and base-contract tests also pass in this checkpoint.


## Audit hardening before manual testing

- Player self-service endpoints require a registered account; legacy guest sessions cannot access profile, statistics, or case history.
- Authenticated frontend API calls use `Authorization: Bearer <sessionToken>` instead of putting session tokens in URLs.
- Case generation is admin-only through `CASE_GENERATION_ADMIN_TOKEN`; it is not a public player endpoint.
- Registration and login have a lightweight per-IP request limit.
- AI-generated suspects must provide their own statements, and evidence must specify a discovery location.
- The demo case is validated against the same 5-star structural contract used for AI cases.
- Investigation no longer falls back to discovering arbitrary evidence from unrelated locations.
- Suspect questioning uses the case-generated statement rather than hard-coded suspect IDs.
- Logging out disconnects the realtime socket so a signed-out browser cannot continue receiving a previous room's private channel updates.

For the browser UI test, use a Node version compatible with the installed `jsdom` release (the current lockfile uses jsdom 30, which requires a newer Node 22 minor than some older Node 22 installations).


## Phase 7 — Final hardening

- Public room state strips suspect interview statements; those are revealed only through the private questioning action.
- A registered investigator cannot create/join/queue into multiple unfinished matches.
- Notes, deductions, and accusation inputs have server-side bounds and type validation.
- Supabase room saves use one transaction through `save_room_state`, eliminating partial writes caused by optimistic-version claims followed by separate room/player/event writes.
- Supabase prevents concurrent insertion of a player into multiple unfinished rooms with a transaction-scoped advisory lock.
- Generated cases now undergo stricter deterministic validation for chronological timelines, connected maps, required actions/costs, unique critical evidence, bounded fields, and valid timestamps.
- AI verification must report no unexplained facts, ambiguities, or hardness problems, at least two independent reasoning chains, a score of at least 70, and the exact intended method/time/suspect/location.
- The security regression suite is `npm run test:security`.
- `npm run test:all` runs the dependency-free contract suites. Full HTTP/Socket.IO/browser suites still require installed dependencies and a running backend/frontend.
