// Backend URL. Override by defining window.VERITAS_API before app.js loads (see index.html).
const API = window.VERITAS_API || "http://localhost:4000";

const socket = typeof io === "function" ? io(API, { autoConnect: true }) : null;

let state = null;
let playerId = localStorage.getItem("veritasPlayerId");
let sessionToken = localStorage.getItem("veritasSessionToken");
let roomId = localStorage.getItem("veritasRoomId");
let selectedAction = null;
let finishedToastFor = null;
let matchPoll = null;

const $ = s => document.querySelector(s);
const toast = msg => {
  const el = $("#toast"); el.textContent = msg; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
};

async function api(path, options={}) {
  let res;
  try {
    res = await fetch(API + path, { headers: {"Content-Type":"application/json"}, ...options });
  } catch (networkError) {
    // fetch() rejects (no status, no body) when the server is down OR the browser blocked the
    // response because of CORS. Say both, and log what the browser can't show in the UI.
    console.error("[veritas] network/CORS failure calling", API + path, "from", location.origin, networkError);
    throw new Error(`Cannot reach ${API}${path} from ${location.origin}. Backend down, or this origin is not in FRONTEND_ORIGIN (backend/.env).`);
  }
  const raw = await res.text();
  let data = {};
  try { data = raw ? JSON.parse(raw) : {}; } catch { /* non-JSON body */ }
  if (!res.ok) {
    // Authentication failures are surfaced to the UI so identity never fails silently.
    (res.status === 401 ? console.warn : console.error)("[veritas] API error", res.status, path, raw);
    const err = new Error(data.error || `Request failed: HTTP ${res.status} ${res.statusText}${raw && !data.error ? " - " + raw.slice(0, 120) : ""}`);
    err.status = res.status; err.body = raw;
    throw err;
  }
  return data;
}

function saveSession() {
  // Never write the string "null"/"undefined" into storage.
  const put = (k, v) => v ? localStorage.setItem(k, v) : localStorage.removeItem(k);
  put("veritasPlayerId", playerId);
  put("veritasSessionToken", sessionToken);
  put("veritasRoomId", roomId);
}

function clearRoom() { roomId = null; state = null; saveSession(); }
function clearSession() { playerId = null; sessionToken = null; roomId = null; saveSession(); }

// Session-authenticated POST. Expired or invalid identity always returns to account login;
// VERITAS never silently converts an investigator into a guest.
async function authedPost(path, extra = {}) {
  await requireRegisteredSession();
  return await api(path, { method: "POST", headers: { Authorization: `Bearer ${sessionToken}` }, body: JSON.stringify(extra) });
}

async function getProfile() {
  await ensureSession();
  try {
    return await api("/api/me/profile", { headers: { Authorization: `Bearer ${sessionToken}` } });
  } catch (e) {
    if (e.status === 401) {
      clearSession();
      updateLandingAccount();
      openAuth("login");
    }
    throw e;
  }
}

function openAuth(mode = "login") {
  if (state?.status === "active") return toast("Finish the current investigation before changing identity.");
  setAuthTab(mode);
  $("#authDialog").showModal();
}

function setAuthTab(mode) {
  document.querySelectorAll(".auth-tab").forEach(tab => tab.classList.toggle("active", tab.dataset.authTab === mode));
  $("#loginForm").classList.toggle("hidden", mode !== "login");
  $("#registerForm").classList.toggle("hidden", mode !== "register");
}

function initials(profile) {
  const name = String(profile?.displayName || profile?.username || "V").trim();
  return name.split(/\s+/).slice(0,2).map(x => x[0]).join("").toUpperCase() || "V";
}

function setProfileAvatar(el, profile) {
  if (!el) return;
  const url = profile?.avatarUrl;
  el.textContent = url ? "" : initials(profile);
  el.style.backgroundImage = "";
  if (url) {
    const image = new Image();
    image.onload = () => { el.style.backgroundImage = `url(${JSON.stringify(url)})`; };
    image.src = url;
  }
}

const ACHIEVEMENTS = {
  "first-blood": {icon:"◈", name:"First Blood", desc:"Solve your first case", honour:"First solved case"},
  "the-detective": {icon:"✦", name:"The Detective", desc:"Solve 10 cases", honour:"10 solved cases"},
  "veteran-investigator": {icon:"◇", name:"Veteran Investigator", desc:"Complete 25 matches", honour:"25 completed matches"},
  "clean-record": {icon:"⬡", name:"Clean Record", desc:"Solve 5 cases without a false accusation", honour:"5 clean solves"},
  "unstoppable": {icon:"⚑", name:"Unstoppable", desc:"Win 5 matches in a row", honour:"5-win streak"}
};
function renderAchievements(earned) {
  const holder = $("#achievementsList");
  if (!holder) return;
  holder.innerHTML = Object.entries(ACHIEVEMENTS).map(([id,a]) => {
    const active = earned.includes(id);
    return `<div class="achievement ${active ? "earned" : "locked"}"><b>${a.icon}</b><strong>${a.name}</strong><small>${a.desc}</small><em>${active ? "EARNED" : "LOCKED"}</em></div>`;
  }).join("");
  const count = earned.length;
  $("#achievementCount").textContent = `${count}/${Object.keys(ACHIEVEMENTS).length} earned`;
}

let caseArchiveOffset = 0;
let caseArchiveTotal = 0;
function renderCaseArchive(items, append = false) {
  const holder = $("#caseArchiveList");
  if (!holder) return;
  if (!append) holder.innerHTML = "";
  if (!items.length && !append) holder.innerHTML = '<div class="empty-archive">No completed investigations yet. Your first case record will appear here.</div>';
  for (const item of items) {
    const row = document.createElement("article");
    row.className = "case-archive-row";
    const status = item.status === "solved" ? "SOLVED" : "FAILED";
    const reward = Number(item.honourDelta || 0);
    const date = item.createdAt ? new Date(item.createdAt).toLocaleDateString([], {year:"numeric",month:"short",day:"numeric"}) : "—";
    row.innerHTML = `<div class="archive-case-mark">${item.status === "solved" ? "✓" : "×"}</div><div class="archive-case-main"><strong></strong><small></small><span></span></div><div class="archive-case-meta"><b class="${item.won ? "archive-win" : "archive-loss"}">${item.won ? "VICTORY" : "DEFEAT"}</b><small></small></div>`;
    row.querySelector(".archive-case-main strong").textContent = item.caseTitle || `Case ${item.caseId || "—"}`;
    row.querySelector(".archive-case-main small").textContent = `CASE ${item.caseId || "—"} · ${date}`;
    row.querySelector(".archive-case-main span").textContent = `${status} · ${item.turns || 0} turns · ${Math.round(Number(item.durationSeconds || 0) / 60)} min`;
    row.querySelector(".archive-case-meta small").textContent = `${reward > 0 ? "+" : ""}${reward} Honour${item.firstAttempt ? "" : " · replay"}`;
    holder.append(row);
  }
  $("#caseArchiveCount").textContent = `${caseArchiveTotal} RECORD${caseArchiveTotal === 1 ? "" : "S"}`;
  $("#caseArchiveMore").hidden = caseArchiveOffset >= caseArchiveTotal;
}
async function loadCaseArchive(append = false) {
  if (!sessionToken) return;
  if (!append) caseArchiveOffset = 0;
  const data = await api(`/api/me/case-history?limit=8&offset=${caseArchiveOffset}`, { headers: { Authorization: `Bearer ${sessionToken}` } });
  caseArchiveTotal = Number(data.total || 0);
  renderCaseArchive(data.items || [], append);
  caseArchiveOffset += (data.items || []).length;
}

async function openProfile() {
  try {
    const data = await getProfile();
    const profile = data.profile || {};
    const stats = data.stats || {};
    const progression = data.progression || {};
    $("#profileDisplayName").textContent = profile.displayName || profile.username || "Detective";
    $("#profileUsername").textContent = `@${profile.username || "investigator"}`;
    $("#profileBio").textContent = profile.bio || "Every case leaves a trail.";
    $("#profileHonour").textContent = Number(progression.honour || 0).toLocaleString();
    $("#profileHonourMeta").textContent = `${Number(progression.falseAccusations || 0)} false accusation${Number(progression.falseAccusations || 0) === 1 ? "" : "s"}`;
    $("#profileAccountType").textContent = profile.accountType === "registered" ? "REGISTERED" : "SIGNED OUT";
    $("#profileIdentityStatus").textContent = profile.accountType === "registered" ? "Permanent account" : "Signed-out preview";
    $("#profileCreated").textContent = profile.createdAt ? new Date(profile.createdAt).toLocaleDateString([], {year:"numeric",month:"short",day:"numeric"}) : "—";
    $("#statSolved").textContent = Number(stats.casesSolved || 0);
    $("#statMatches").textContent = Number(stats.matchesPlayed || 0);
    $("#statWins").textContent = Number(stats.wins || 0);
    $("#statLosses").textContent = Number(stats.losses || 0);
    $("#statTurns").textContent = Number(stats.totalTurns || 0);
    const seconds = Number(stats.totalDurationSeconds || 0);
    $("#statTime").textContent = seconds >= 3600 ? `${(seconds/3600).toFixed(1)}h` : `${Math.round(seconds/60)}m`;
    const matches = Number(stats.matchesPlayed || 0);
    $("#statInvestigated").textContent = matches;
    $("#statWinRate").textContent = `${matches ? Math.round((Number(stats.wins || 0) / matches) * 100) : 0}%`;
    $("#statCurrentStreak").textContent = Number(progression.currentWinStreak || 0);
    $("#statLongestStreak").textContent = Number(progression.longestWinStreak || 0);
    renderAchievements(progression.achievements || []);
    try { await loadCaseArchive(false); } catch (archiveError) { console.warn("Could not load case archive", archiveError); }
    setProfileAvatar($("#profileAvatar"), profile);
    const registered = profile.accountType === "registered";
    $("#guestProfileActions").classList.toggle("hidden", registered);
    $("#registeredProfileActions").classList.toggle("hidden", !registered);
    $("#profileDialog").showModal();
  } catch (e) { toast(e.message); }
}

function closeAuth() { $("#authDialog").close(); }

async function login() {
  const loginValue = $("#loginInput").value.trim();
  const password = $("#loginPassword").value;
  if (!loginValue || !password) return toast("Enter your username/email and password.");
  try {
    const data = await api("/api/auth/login", {method:"POST", body:JSON.stringify({login:loginValue,password})});
    clearRoom();
    playerId = data.playerId; sessionToken = data.sessionToken; saveSession();
    if (socket && !socket.connected) socket.connect();
    closeAuth();
    updateLandingAccount(data.profile);
    $("#nameInput").value = data.profile?.displayName || data.profile?.username || "Detective";
    toast(`Welcome back, ${data.profile?.displayName || data.profile?.username || "Detective"}.`);
    if (!state) showGameLobby();
  } catch (e) { toast(e.message); }
}

async function register() {
  const username = $("#registerUsername").value.trim();
  const displayName = $("#registerDisplayName").value.trim() || username;
  const email = $("#registerEmail").value.trim();
  const password = $("#registerPassword").value;
  if (!username || !email || !password) return toast("Complete the required account fields.");
  try {
    const data = await api("/api/auth/register", {method:"POST", body:JSON.stringify({username,displayName,email,password})});
    clearRoom();
    playerId = data.playerId; sessionToken = data.sessionToken; saveSession();
    if (socket && !socket.connected) socket.connect();
    closeAuth();
    updateLandingAccount(data.profile);
    $("#nameInput").value = data.profile?.displayName || username;
    toast(`Account created. Welcome, ${data.profile?.displayName || username}.`);
    if (!state) showGameLobby();
  } catch (e) { toast(e.message); }
}

async function logout() {
  if (state?.status === "active") return toast("Finish the current investigation before signing out.");
  try { await api("/api/auth/logout", {method:"POST",body:JSON.stringify({sessionToken})}); } catch {}
  clearSession();
  socket?.disconnect();
  $("#profileDialog").close();
  updateLandingAccount();
  showLanding();
  toast("Signed out. Sign in again to enter an investigation.");
}

function openEditProfile() {
  if (state?.status === "active") return toast("Finish the current investigation before editing your identity.");
  getProfile().then(({profile}) => {
    $("#editUsername").value = profile?.username || "";
    $("#editDisplayName").value = profile?.displayName || "";
    $("#editBio").value = profile?.bio || "";
    $("#editAvatarUrl").value = profile?.avatarUrl || "";
    $("#editProfileDialog").showModal();
  }).catch(e => toast(e.message));
}

async function saveProfile() {
  try {
    const data = await api("/api/me/profile", {method:"PATCH",body:JSON.stringify({
      sessionToken, username:$("#editUsername").value.trim(), displayName:$("#editDisplayName").value.trim(),
      bio:$("#editBio").value.trim(), avatarUrl:$("#editAvatarUrl").value.trim()
    })});
    $("#editProfileDialog").close();
    toast("Profile updated.");
    await openProfile();
    if (state?.me) render();
  } catch (e) { toast(e.message); }
}

function render() {
  if (!state) return;
  $("#caseId").textContent = state.case.id;
  $("#playerCount").textContent = `Players: ${state.players.length}/2`;
  $("#difficulty").textContent = "★★★★★";
  $("#caseTitle").textContent = state.case.title;
  $("#caseIntro").textContent = state.case.intro;
  $("#roomCode").textContent = state.id;
  $("#myName").textContent = state.me ? (state.players.find(p=>p.id===state.me.id)?.name || "You") : "You";
  $("#myAP").textContent = `${state.me?.actionPoints ?? 0}/3`;

  const opponent = state.players.find(p => p.id !== state.me?.id);
  $("#opponentName").textContent = opponent?.name || "Waiting for opponent";
  $("#opponentAP").textContent = opponent ? "•••" : "—";

  const mine = state.activePlayer === state.players.find(p=>p.id===state.me?.id)?.index;
  $("#turnText").textContent = state.status === "waiting" ? "Waiting for another detective…" :
    state.status === "finished" ? "Case finished." : mine ? "It is your turn." : "Opponent's turn.";
  $("#turnAction").disabled = !mine;

  renderMap();
  renderSuspects();
  renderTimeline();
  renderLocations();
  renderEvidence();
  renderNotes();
  renderDeductions();
  renderEvents();
  renderChat();

document.querySelectorAll(".action-list button").forEach(btn => {
    btn.classList.toggle("active", selectedAction === btn.dataset.action);
    const cost = Number(btn.querySelector("em")?.textContent || 1);
    btn.disabled = !mine || state.me.actionPoints < cost || state.status !== "active";
  });

  if (state.status === "finished" && state.result && finishedToastFor !== state.id) {
    finishedToastFor = state.id;
    toast(state.result.correct ? "CASE SOLVED — you found the truth." : "Accusation failed. The case has ended.");
    // The match is over: don't restore this room on the next page load.
    localStorage.removeItem("veritasRoomId");
  }
}

function renderMap() {
  const grid = $("#mapGrid"); grid.innerHTML = "";
  const positions = {
    library:"1 / 1", security:"1 / 2", office:"1 / 3",
    staff:"2 / 1", hall:"2 / 2", vault:"2 / 3",
    entrance:"3 / 2", parking:"3 / 3"
  };
  state.case.locations.forEach(loc => {
    const node = document.createElement("div");
    node.className = "map-node";
    node.style.gridArea = positions[loc.id] || "auto";
    node.innerHTML = `<span>${escapeHtml(loc.name)}</span>`;
    state.players.forEach((p,i) => {
      if (p.locationId === loc.id) {
        const token = document.createElement("div");
        token.className = "token " + (i === 1 ? "opponent" : "");
        token.textContent = i === 0 ? "●" : "◆";
        node.appendChild(token);
      }
    });
    grid.appendChild(node);
  });
}

function renderSuspects() {
  $("#suspects").innerHTML = state.case.suspects.map((s,i) =>
    `<div class="suspect"><div class="portrait">${["👩🏻‍💼","👨🏻‍✈️","👩🏻‍💼","👨🏻‍🔬","👩🏻","👨🏻‍💻"][i % 6]}</div><div><strong>${escapeHtml(s.name)}</strong><small>${escapeHtml(s.role)}</small></div></div>`
  ).join("");
}

function renderTimeline() {
  $("#timeline").innerHTML = state.case.timeline.map(e =>
    `<div class="timeline-row"><time>${escapeHtml(e.time)}</time><span>${escapeHtml(e.text)}<em>${escapeHtml(e.source || "")}</em></span></div>`
  ).join("");
}

function renderLocations() {
  $("#locations").innerHTML = state.case.locations.map(l =>
    `<button class="location ${state.me?.locationId===l.id?"selected":""}" data-location="${escapeHtml(l.id)}">${escapeHtml(l.name)}</button>`
  ).join("");
  $("#locations").querySelectorAll("button").forEach(b => b.onclick = () => chooseLocation(b.dataset.location));
}

function renderEvidence() {
  const owned = state.me?.evidence || [];
  $("#evidence").innerHTML = owned.length ? owned.map((e, index) => {
    const cctv = String(e.type || "").toLowerCase() === "cctv";
    return `<article class="evidence-card ${cctv ? "evidence-cctv" : ""}" data-evidence-index="${index}">
      <div class="evidence-card-top"><span class="evidence-type">${escapeHtml(e.type || "Evidence")}</span>${cctv ? '<span class="evidence-open">OPEN FOOTAGE</span>' : ""}</div>
      <h4>${escapeHtml(e.title)}</h4><p>${escapeHtml(e.description)}</p>
      <small>Reliability ${(Number(e.reliability||0)*100).toFixed(0)}%</small>
    </article>`;
  }).join("") : `<div style="color:#71858e;font-size:11px">No private evidence yet. Investigate or question someone.</div>`;
  $("#evidence").querySelectorAll(".evidence-card").forEach(card => {
    card.onclick = () => openEvidenceViewer(owned[Number(card.dataset.evidenceIndex)]);
  });
}

let evidencePlaybackTimer = null;
function openEvidenceViewer(evidence) {
  if (!evidence) return;
  const isCctv = String(evidence.type || "").toLowerCase() === "cctv";
  $("#evidenceViewerTitle").textContent = evidence.title || "Evidence";
  $("#evidenceViewerType").textContent = evidence.type || "Evidence";
  $("#evidenceViewerDescription").textContent = evidence.description || "";
  $("#evidenceViewerReliability").textContent = `${Math.round(Number(evidence.reliability || 0) * 100)}%`;
  const meta = evidence.cctv || {};
  $("#cctvMeta").innerHTML = isCctv ? [
    ["Camera", meta.cameraName || meta.cameraId || "—"],
    ["Recorded", meta.recordedAt || "—"],
    ["Duration", `${Number(meta.durationSeconds || 0)} seconds`],
    ["Clock offset", `${Number(meta.clockOffsetSeconds || 0) > 0 ? "+" : ""}${Number(meta.clockOffsetSeconds || 0)}s`]
  ].map(([k,v]) => `<div><span>${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join("") : `<div class="evidence-non-cctv"><p>${escapeHtml(evidence.description || "")}</p></div>`;
  $("#cctvNotes").innerHTML = isCctv && Array.isArray(meta.sceneNotes) ? meta.sceneNotes.map(n => `<li>${escapeHtml(n)}</li>`).join("") : (Array.isArray(evidence.reveals) ? evidence.reveals.map(n => `<li>${escapeHtml(n)}</li>`).join("") : "");
  $("#cctvVisual").classList.toggle("hidden", !isCctv);
  $("#cctvMeta").classList.toggle("hidden", !isCctv);
  $("#evidenceGenericMeta").classList.toggle("hidden", isCctv);
  const duration = Number(meta.durationSeconds || 38);
  $("#evidenceViewer").dataset.duration = String(duration);
  if (isCctv) startEvidencePlayback(duration);
  else stopEvidencePlayback();
  $("#evidenceViewer").showModal();
}

function startEvidencePlayback(duration) {
  stopEvidencePlayback();
  let seconds = 0;
  const bar = $("#cctvProgress");
  const time = $("#cctvTime");
  const tick = () => {
    seconds = seconds >= duration ? 0 : seconds + 1;
    bar.value = Math.round((seconds / duration) * 100);
    time.textContent = `${String(Math.floor(seconds / 60)).padStart(2,"0")}:${String(seconds % 60).padStart(2,"0")} / ${String(Math.floor(duration / 60)).padStart(2,"0")}:${String(duration % 60).padStart(2,"0")}`;
  };
  evidencePlaybackTimer = setInterval(tick, 1000);
  tick();
}
function stopEvidencePlayback() {
  if (evidencePlaybackTimer) clearInterval(evidencePlaybackTimer);
  evidencePlaybackTimer = null;
}


function renderNotes() {
  $("#notes").innerHTML = (state.me?.notes || []).slice(-6).map(n =>
    `<div class="note">${escapeHtml(n.text)}</div>`
  ).join("") || `<span style="color:#71858e;font-size:11px">No notes yet.</span>`;
}

function renderDeductions() {
  const items = [
    "Check whether the timeline is internally consistent.",
    "Separate direct evidence from assumptions.",
    "Compare source reliability before trusting a contradiction.",
    "Try to defeat at least one plausible alternative hypothesis."
  ];
  $("#deductions").innerHTML = items.map((x,i) =>
    `<label><input type="checkbox" data-deduction="${i}" ${state.me?.deductions?.includes(i)?"checked":""}>${x}</label>`
  ).join("");
  $("#deductions").querySelectorAll("input").forEach(inp => inp.onchange = () => {
    const values = [...$("#deductions").querySelectorAll("input:checked")].map(x=>Number(x.dataset.deduction));
    socket?.emit("set-deductions",{deductions:values});
  });
}

function renderChat() {
  const log = document.querySelector(".chat-log");
  if (!log) return;
  log.innerHTML = (state.chat || []).map(m => {
    const mine = m.playerId === state.me?.id;
    return `<div class="bubble ${mine ? "mine" : "theirs"}">${escapeHtml(m.text)}<small>${escapeHtml(mine ? "you" : m.playerName)}</small></div>`;
  }).join("") || `<div style="color:#71858e;font-size:11px">No messages yet.</div>`;
  log.scrollTop = log.scrollHeight;
}

function renderEvents() {
  $("#events").innerHTML = state.publicEvents.slice().reverse().map(e =>
    `<div class="event"><time>${new Date(e.at).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</time>${escapeHtml(e.text)}</div>`
  ).join("");
}

function chooseLocation(id) {
  selectedAction = "move";
  socket?.emit("action", {action:"move", payload:{locationId:id}});
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

async function requireRegisteredSession() {
  if (!sessionToken || !playerId) {
    openAuth("login");
    throw new Error("You must be signed in to play VERITAS.");
  }
  try {
    const data = await api("/api/me/profile", { headers: { Authorization: `Bearer ${sessionToken}` } });
    if (data.profile?.accountType !== "registered") throw new Error("You must be signed in to play VERITAS.");
    return data.profile;
  } catch (e) {
    if (e.status === 401 || /must be signed in/i.test(e.message)) { clearSession(); updateLandingAccount(); openAuth("login"); }
    throw e;
  }
}

async function ensureSession() {
  return requireRegisteredSession();
}

function showGameLobby() {
  $("#landingView").classList.add("hidden");
  $("#gameView").classList.remove("hidden");
  $("#startDialog").showModal();
}

function showLanding() {
  if ($("#startDialog").open) $("#startDialog").close();
  $("#landingView").classList.remove("hidden");
  $("#gameView").classList.add("hidden");
}

function updateLandingAccount(profile = null) {
  const registered = profile?.accountType === "registered" || Boolean(sessionToken && playerId);
  $("#landingLoginBtn").classList.toggle("hidden", registered);
  $("#landingSignupBtn").classList.toggle("hidden", registered);
  $(".account-question").classList.toggle("hidden", registered);
  $("#landingProfileBtn").classList.toggle("hidden", !registered);
}

async function playNow() {
  try {
    const profile = await requireRegisteredSession();
    $("#nameInput").value = profile.displayName || profile.username || "Detective";
    showGameLobby();
  } catch (e) {
    if (!/must be signed in/i.test(e.message)) toast(e.message);
  }
}

async function loadLandingIdentity() {
  if (!sessionToken || !playerId) return updateLandingAccount();
  try {
    const { profile } = await api("/api/me/profile", { headers: { Authorization: `Bearer ${sessionToken}` } });
    if (profile?.accountType !== "registered") clearSession();
    else { updateLandingAccount(profile); $("#nameInput").value = profile.displayName || profile.username || "Detective"; }
  } catch { clearSession(); }
  updateLandingAccount();
}

async function openContact() {
  $("#contactDialog").showModal();
  try {
    const data = await api("/api/public/config");
    const email = data.contactEmail || "";
    $("#contactEmailLabel").textContent = email || "Contact email is not configured yet.";
    $("#contactEmailHint").textContent = email ? "Messages will open in your default email application." : "Set VERITAS_CONTACT_EMAIL in backend/.env to activate the direct email link.";
    $("#sendContactBtn").disabled = !email;
    $("#sendContactBtn").dataset.email = email;
  } catch (e) { toast(e.message); }
}

function sendContact() {
  const to = $("#sendContactBtn").dataset.email;
  if (!to) return toast("The VERITAS contact email has not been configured yet.");
  const from = $("#contactFrom").value.trim();
  const message = $("#contactMessage").value.trim();
  const subject = encodeURIComponent("VERITAS enquiry");
  const body = encodeURIComponent(`${message}${from ? `\n\nReply to: ${from}` : ""}`);
  location.href = `mailto:${to}?subject=${subject}&body=${body}`;
}

function enterRoom(data) {
  stopMatchPoll();
  finishedToastFor = null;
  roomId = data.roomId; playerId = data.playerId || playerId; sessionToken = data.sessionToken || sessionToken; saveSession();
  if ($("#startDialog").open) $("#startDialog").close();
  if (!socket) return toast("The VERITAS realtime server is unavailable.");
  socket?.emit("join-room", {roomId, sessionToken});
}

const playerName = () => $("#nameInput").value.trim() || "Detective";

async function createMatch() {
  try { enterRoom(await authedPost("/api/rooms", {playerName: playerName()})); }
  catch(e) { toast(e.message); }
}

async function joinMatch() {
  try {
    const code = $("#joinCode").value.trim().toUpperCase();
    if (!code) return toast("Enter a room code.");
    enterRoom(await authedPost(`/api/rooms/${encodeURIComponent(code)}/join`, {playerName: playerName()}));
  } catch(e) { toast(e.message); }
}

function attemptAction(action) {
  selectedAction = action;
  if (action === "move") { toast("Choose a location on the map."); render(); return; }
  if (action === "question") {
    const name = prompt("Enter suspect name: " + state.case.suspects.map(s=>s.name).join(", "));
    const suspect = state.case.suspects.find(s => s.name.toLowerCase() === name?.toLowerCase());
    if (!suspect) return toast("Suspect not found.");
    socket?.emit("action",{action,payload:{suspectId:suspect.id}});
    return;
  }
  socket?.emit("action",{action,payload:{}});
}

function stopMatchPoll() { if (matchPoll) { clearInterval(matchPoll); matchPoll = null; } }

async function quickMatch() {
  stopMatchPoll();
  try {
    const first = await authedPost("/api/matchmaking/queue", {playerName: playerName()});
    if (first.status === "matched") return enterRoom(first);

    toast("You're in the matchmaking queue. Searching…");
    // Each poll also tells the server we're still here; players who stop polling are skipped.
    const startedAt = Date.now();
    let failures = 0;
    matchPoll = setInterval(async () => {
      if (Date.now() - startedAt > 120000) { stopMatchPoll(); return toast("No opponent found. Try again in a moment."); }
      try {
        const next = await authedPost("/api/matchmaking/queue", {playerName: playerName()});
        failures = 0;
        if (next.status === "matched") enterRoom(next);
      } catch(e) {
        if (++failures >= 3) { stopMatchPoll(); toast(e.message); }
      }
    }, 3000);
  } catch(e) { toast(e.message); }
}

document.querySelectorAll(".action-list button").forEach(btn => btn.onclick = () => attemptAction(btn.dataset.action));
$("#createBtn").onclick = createMatch;
$("#joinBtn").onclick = joinMatch;
$("#quickMatchBtn").onclick = quickMatch;
$("#endTurnBtn").onclick = () => socket?.emit("end-turn");
$("#turnAction").onclick = () => socket?.emit("end-turn");

$("#addNoteBtn").onclick = () => {
  const text = prompt("Write a private deduction/note:");
  if (text?.trim()) socket?.emit("add-note",{text});
};

$("#accuseBtn").onclick = () => {
  if (!state) return;
  $("#accuseSuspect").innerHTML = state.case.suspects.map(s=>`<option value="${escapeHtml(s.id)}">${escapeHtml(s.name)}</option>`).join("");
  $("#accuseLocation").innerHTML = state.case.locations.map(l=>`<option value="${escapeHtml(l.id)}">${escapeHtml(l.name)}</option>`).join("");
  $("#accuseDialog").showModal();
};
$("#cancelAccuse").onclick = () => $("#accuseDialog").close();
$("#submitAccuse").onclick = () => {
  socket?.emit("accuse",{accusation:{
    suspectId:$("#accuseSuspect").value,
    locationId:$("#accuseLocation").value,
    method:$("#accuseMethod").value,
    time:$("#accuseTime").value
  }});
  $("#accuseDialog").close();
};

document.querySelector(".chat-input button").onclick = sendChat;
document.querySelector("#chatInput").addEventListener("keydown", e => { if (e.key === "Enter") sendChat(); });
function sendChat() {
  const input = $("#chatInput");
  const text = input.value.trim();
  if (!text) return;
  socket?.emit("chat", { text });
  input.value = "";
}

socket?.on("state", data => {
  const firstState = !state;
  state = data;
  // Close the lobby only when a game first appears (e.g. restored after a refresh);
  // later broadcasts must not dismiss a lobby the player opened on purpose.
  if (firstState && $("#startDialog").open) $("#startDialog").close();
  render();
});
socket?.on("private-reveal", reveals => {
  if (reveals?.length) toast(`New private information: ${reveals[0].title}`);
});
socket?.on("error-message", msg => {
  toast(msg);
  // While restoring a saved game, a rejection means the saved room/session is gone
  // (server restarted, session expired). Fall back to the start screen.
  if (!state && /session|not part of|not found/i.test(msg)) {
    clearRoom();
    if (!$("#startDialog").open) $("#startDialog").showModal();
  }
});

// (Re)join the room on every socket connect: covers first load, network drops and server restarts.
socket?.on("connect", () => {
  if (roomId && sessionToken) socket?.emit("join-room", {roomId, sessionToken});
});

$("#profileBtn").onclick = openProfile;
$("#caseArchiveMore")?.addEventListener("click", async () => { try { await loadCaseArchive(true); } catch (e) { toast(e.message); } });
$("#settingsBtn").onclick = () => { if (!state) showGameLobby(); else if (!$("#startDialog").open) $("#startDialog").showModal(); };
$("#closeProfile").onclick = () => $("#profileDialog").close();
$("#closeAuth").onclick = closeAuth;
$("#closeEditProfile").onclick = () => $("#editProfileDialog").close();
$("#cancelEditProfile").onclick = () => $("#editProfileDialog").close();
$("#saveEditProfile").onclick = saveProfile;
$("#profileCreateAccount").onclick = () => { $("#profileDialog").close(); openAuth("register"); };
$("#profileSignIn").onclick = () => { $("#profileDialog").close(); openAuth("login"); };
$("#editProfileBtn").onclick = openEditProfile;
$("#logoutBtn").onclick = logout;
$("#loginSubmit").onclick = login;
$("#registerSubmit").onclick = register;
document.querySelectorAll(".auth-tab").forEach(tab => tab.onclick = () => setAuthTab(tab.dataset.authTab));
$("#openLoginBtn").onclick = () => openAuth("login");
$("#openRegisterBtn").onclick = () => openAuth("register");


$("#landingHomeBtn").onclick = showLanding;
$("#landingHomeNavBtn").onclick = showLanding;
$("#playNowBtn").onclick = playNow;
$("#heroLearnBtn").onclick = () => $("#whyVeritas").scrollIntoView({behavior:"smooth"});
$("#landingLoginBtn").onclick = () => openAuth("login");
$("#landingSignupBtn").onclick = () => openAuth("register");
$("#landingProfileBtn").onclick = openProfile;
$("#aboutBtn").onclick = () => $("#aboutDialog").showModal();
$("#footerAbout").onclick = () => $("#aboutDialog").showModal();
$("#aboutPlayBtn").onclick = () => { $("#aboutDialog").close(); playNow(); };
$("#contactBtn").onclick = openContact;
$("#footerContact").onclick = openContact;
$("#footerLogin").onclick = () => openAuth("login");
$("#closeAbout").onclick = () => $("#aboutDialog").close();
$("#closeContact").onclick = () => $("#contactDialog").close();
$("#sendContactBtn").onclick = sendContact;
$("#cctvPlayBtn")?.addEventListener("click", () => startEvidencePlayback(Number($("#evidenceViewer").dataset.duration || 38)));
$("#closeEvidenceViewer").onclick = () => { stopEvidencePlayback(); $("#evidenceViewer").close(); };
$("#cctvProgress").oninput = e => {
  const duration = Number($("#evidenceViewer").dataset.duration || 38);
  const seconds = Math.round((Number(e.target.value) / 100) * duration);
  $("#cctvTime").textContent = `${String(Math.floor(seconds / 60)).padStart(2,"0")}:${String(seconds % 60).padStart(2,"0")} / ${String(Math.floor(duration / 60)).padStart(2,"0")}:${String(duration % 60).padStart(2,"0")}`;
};

window.addEventListener("load", async () => {
  showLanding();
  await loadLandingIdentity();
  if (roomId && sessionToken) {
    try {
      const profile = await requireRegisteredSession();
      $("#nameInput").value = profile.displayName || profile.username || "Detective";
      $("#landingView").classList.add("hidden");
      $("#gameView").classList.remove("hidden");
    } catch {
      clearRoom();
      showLanding();
    }
  }
});
